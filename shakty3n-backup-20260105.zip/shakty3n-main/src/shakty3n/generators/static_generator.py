"""
Static HTML/CSS Generator for simple web pages
"""
from typing import Dict
from .base import CodeGenerator


class StaticHTMLGenerator(CodeGenerator):
    """Generator for static HTML/CSS pages - uses AI for all generation"""
    
    def __init__(self, ai_provider, output_dir: str):
        super().__init__(ai_provider, output_dir)
    
    def generate_project(self, description: str, requirements: Dict) -> Dict:
        """Generate a static HTML project from description"""
        
        # Generate HTML using AI with explicit instructions
        html_content = self._generate_html(description, requirements)
        self.create_file("index.html", html_content)
        
        return {
            "type": "static",
            "files": self.generated_files,
            "tests_generated": False
        }
    
    def _generate_html(self, description: str, requirements: Dict) -> str:
        """Generate HTML content using AI with detailed prompts"""
        
        # Comprehensive prompt that forces AI to follow the description
        system_prompt = """You are an expert web developer. Generate COMPLETE, PRODUCTION-READY HTML5 code.

CRITICAL RULES:
1. Generate ONLY the raw HTML code - no explanations, no markdown
2. Follow the user's description EXACTLY - use their company name, colors, theme
3. Include ALL CSS inline in a <style> tag
4. Make it modern, professional, and visually impressive
5. Use the EXACT colors, company names, and themes the user specified
6. Include proper sections: navigation, hero, features, footer
7. Use modern CSS: flexbox, grid, gradients, animations
8. Make it responsive with media queries"""

        prompt = f"""Create a COMPLETE HTML5 website for this exact request:

"{description}"

REQUIREMENTS:
- Extract and use the EXACT company/brand name from the description
- Use the EXACT colors mentioned (e.g., "neon green" = #00ff88)
- Match the industry/theme mentioned (e.g., electric car, tech, etc.)
- Create professional, modern design with smooth animations
- Include: navigation bar, hero section with headline, features/services, call-to-action, footer
- All CSS must be inline in <style> tag
- Must be mobile-responsive

Generate the COMPLETE HTML code now. Start with <!DOCTYPE html>"""

        try:
            response = self.ai_provider.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.4,  # Slightly higher for creativity
                max_tokens=4000   # More tokens for complete output
            )
            
            html = self._extract_html(response)
            
            # Validate we got actual HTML
            if "<!doctype" in html.lower() or "<html" in html.lower():
                return html
            
            # If AI returned partial content, wrap it
            if "<div" in html.lower() or "<section" in html.lower():
                return self._wrap_in_html(html, description)
            
            # Fallback if AI completely failed
            raise Exception("AI did not return valid HTML")
            
        except Exception as e:
            print(f"HTML generation error: {e}")
            raise  # Let the error propagate - don't hide failures
    
    def _extract_html(self, response: str) -> str:
        """Extract HTML from AI response, removing markdown if present"""
        import html
        
        text = response.strip()
        
        # Remove markdown code fences
        if text.startswith("```"):
            lines = text.split('\n')
            lines = lines[1:]  # Remove opening fence
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]  # Remove closing fence
            text = '\n'.join(lines)
        
        # Decode HTML entities (fixes &lt; -> <, &amp; -> &, etc.)
        # Some models produce escaped HTML which breaks rendering
        text = html.unescape(text)
        
        return text.strip()
    
    def _wrap_in_html(self, content: str, description: str) -> str:
        """Wrap partial content in HTML document"""
        title = description[:60] if len(description) > 60 else description
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: system-ui, sans-serif; }}
    </style>
</head>
<body>
{content}
</body>
</html>'''

