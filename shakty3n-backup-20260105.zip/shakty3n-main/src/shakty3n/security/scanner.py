"""
Security Scanner Module
Implements OWASP checks, secrets detection, and dependency vulnerability scanning.
"""
import re
import os
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Set
from enum import Enum
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class Severity(Enum):
    """Security finding severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"
    
    def __lt__(self, other):
        order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]
        return order.index(self) > order.index(other)


@dataclass
class SecurityFinding:
    """A security issue found during scanning"""
    rule_id: str
    severity: Severity
    file_path: str
    line_number: Optional[int]
    description: str
    recommendation: str
    cwe_id: Optional[str] = None  # Common Weakness Enumeration
    code_snippet: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "rule_id": self.rule_id,
            "severity": self.severity.value,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "description": self.description,
            "recommendation": self.recommendation,
            "cwe_id": self.cwe_id,
            "code_snippet": self.code_snippet
        }


# OWASP Top 10 2021 patterns
OWASP_RULES = {
    # A01:2021 - Broken Access Control
    "A01_HARDCODED_ADMIN": {
        "pattern": r"(admin|root|superuser)\s*[=:]\s*['\"]?(true|1|yes)",
        "severity": Severity.HIGH,
        "description": "Hardcoded admin/root privileges detected",
        "recommendation": "Use role-based access control with proper authentication",
        "cwe": "CWE-269"
    },
    "A01_INSECURE_CORS": {
        "pattern": r"Access-Control-Allow-Origin['\"]?\s*[:=]\s*['\"]?\*",
        "severity": Severity.MEDIUM,
        "description": "Overly permissive CORS configuration (allow all origins)",
        "recommendation": "Restrict CORS to specific trusted origins",
        "cwe": "CWE-942"
    },
    
    # A02:2021 - Cryptographic Failures
    "A02_WEAK_HASH": {
        "pattern": r"\b(md5|sha1)\s*\(|hashlib\.(md5|sha1)",
        "severity": Severity.MEDIUM,
        "description": "Weak hashing algorithm detected (MD5/SHA1)",
        "recommendation": "Use SHA-256 or stronger for security-sensitive operations",
        "cwe": "CWE-328"
    },
    "A02_HARDCODED_KEY": {
        "pattern": r"(encryption|secret|private)_?key\s*[=:]\s*['\"][a-zA-Z0-9+/=]{16,}['\"]",
        "severity": Severity.CRITICAL,
        "description": "Hardcoded encryption key detected",
        "recommendation": "Use environment variables or key management service",
        "cwe": "CWE-321"
    },
    
    # A03:2021 - Injection
    "A03_SQL_INJECTION": {
        "pattern": r"(execute|query|cursor)\s*\([^)]*['\"].*\%s.*\+|\bf['\"].*\{.*\}.*['\"].*\.(execute|query)",
        "severity": Severity.CRITICAL,
        "description": "Potential SQL injection vulnerability",
        "recommendation": "Use parameterized queries or ORM",
        "cwe": "CWE-89"
    },
    "A03_COMMAND_INJECTION": {
        "pattern": r"(os\.system|subprocess\.call|subprocess\.run|eval|exec)\s*\([^)]*\+|shell\s*=\s*True",
        "severity": Severity.CRITICAL,
        "description": "Potential command injection vulnerability",
        "recommendation": "Avoid shell=True, sanitize all user input",
        "cwe": "CWE-78"
    },
    "A03_XSS": {
        "pattern": r"innerHTML\s*=|document\.write\s*\(|dangerouslySetInnerHTML",
        "severity": Severity.HIGH,
        "description": "Potential XSS vulnerability",
        "recommendation": "Use safe DOM manipulation methods, escape user input",
        "cwe": "CWE-79"
    },
    
    # A05:2021 - Security Misconfiguration
    "A05_DEBUG_ENABLED": {
        "pattern": r"DEBUG\s*[=:]\s*['\"]?(True|true|1)['\"]?|debug\s*:\s*true",
        "severity": Severity.MEDIUM,
        "description": "Debug mode enabled in configuration",
        "recommendation": "Disable debug mode in production",
        "cwe": "CWE-489"
    },
    "A05_INSECURE_COOKIE": {
        "pattern": r"(secure|httponly)\s*[=:]\s*['\"]?(False|false|0)['\"]?",
        "severity": Severity.MEDIUM,
        "description": "Insecure cookie configuration",
        "recommendation": "Enable Secure and HttpOnly flags for cookies",
        "cwe": "CWE-614"
    },
    
    # A07:2021 - Identification and Authentication Failures
    "A07_WEAK_PASSWORD": {
        "pattern": r"password\s*[=:]\s*['\"][a-zA-Z0-9]{1,8}['\"]|min_?length\s*[=:]\s*[1-5]\b",
        "severity": Severity.HIGH,
        "description": "Weak password or short minimum length",
        "recommendation": "Enforce strong password policies (min 12 chars)",
        "cwe": "CWE-521"
    },
    "A07_PLAINTEXT_PASSWORD": {
        "pattern": r"password\s*[=:]\s*['\"][^'\"]{4,}['\"](?!.*hash|encrypt)",
        "severity": Severity.CRITICAL,
        "description": "Plaintext password in code",
        "recommendation": "Never store plaintext passwords, use proper hashing",
        "cwe": "CWE-256"
    },
    
    # A04:2021 - Insecure Design (added patterns)
    "A04_NO_RATE_LIMIT": {
        "pattern": r"@app\.(route|get|post|put|delete)\s*\([^)]+\)\s*\n(?!.*rate_limit|throttle|RateLimit)",
        "severity": Severity.MEDIUM,
        "description": "API endpoint without rate limiting",
        "recommendation": "Add rate limiting to prevent abuse",
        "cwe": "CWE-770"
    },
    "A04_MISSING_AUTH": {
        "pattern": r"@app\.(route|get|post|put|delete)\s*\([^)]+\)\s*\n(?!.*@login_required|@auth|@jwt|@requires_auth)",
        "severity": Severity.HIGH,
        "description": "API endpoint without authentication check",
        "recommendation": "Add authentication decorators to protected endpoints",
        "cwe": "CWE-306"
    },
    
    # A08:2021 - Software and Data Integrity Failures
    "A08_UNSAFE_DESERIALIZATION": {
        "pattern": r"pickle\.loads|yaml\.load\s*\([^)]*(?!Loader)",
        "severity": Severity.CRITICAL,
        "description": "Unsafe deserialization detected",
        "recommendation": "Use safe_load for YAML, avoid pickle for untrusted data",
        "cwe": "CWE-502"
    },
    
    # Path Traversal
    "A01_PATH_TRAVERSAL": {
        "pattern": r"(open|read|write)\s*\([^)]*\+\s*['\"]|os\.path\.join\s*\([^)]*request\.",
        "severity": Severity.HIGH,
        "description": "Potential path traversal vulnerability",
        "recommendation": "Validate and sanitize file paths, use os.path.realpath",
        "cwe": "CWE-22"
    },
    
    # CSRF
    "A05_CSRF_DISABLED": {
        "pattern": r"csrf_protect\s*=\s*False|WTF_CSRF_ENABLED\s*=\s*False|@csrf_exempt",
        "severity": Severity.HIGH,
        "description": "CSRF protection disabled",
        "recommendation": "Enable CSRF protection for all state-changing operations",
        "cwe": "CWE-352"
    },
    
    # JWT Issues
    "A02_JWT_NONE_ALG": {
        "pattern": r"algorithm\s*[=:]\s*['\"]none['\"]|alg['\"]?\s*:\s*['\"]?none",
        "severity": Severity.CRITICAL,
        "description": "JWT 'none' algorithm vulnerability",
        "recommendation": "Never allow 'none' algorithm, enforce strong algorithms",
        "cwe": "CWE-327"
    },
}

# Secret detection patterns
SECRET_PATTERNS = {
    "AWS_KEY": {
        "pattern": r"AKIA[0-9A-Z]{16}",
        "severity": Severity.CRITICAL,
        "description": "AWS Access Key ID detected"
    },
    "AWS_SECRET": {
        "pattern": r"(?i)aws[_-]?secret[_-]?access[_-]?key\s*[=:]\s*['\"]?[A-Za-z0-9/+=]{40}",
        "severity": Severity.CRITICAL,
        "description": "AWS Secret Access Key detected"
    },
    "GITHUB_TOKEN": {
        "pattern": r"gh[ops]_[A-Za-z0-9_]{36,}",
        "severity": Severity.CRITICAL,
        "description": "GitHub token detected"
    },
    "GENERIC_API_KEY": {
        "pattern": r"(?i)(api[_-]?key|apikey)\s*[=:]\s*['\"]?[a-zA-Z0-9]{20,}['\"]?",
        "severity": Severity.HIGH,
        "description": "Generic API key detected"
    },
    "GENERIC_SECRET": {
        "pattern": r"(?i)(secret|token|password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{8,}['\"]",
        "severity": Severity.HIGH,
        "description": "Potential secret/password in code"
    },
    "PRIVATE_KEY": {
        "pattern": r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----",
        "severity": Severity.CRITICAL,
        "description": "Private key detected"
    },
    "JWT_TOKEN": {
        "pattern": r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+",
        "severity": Severity.HIGH,
        "description": "JWT token detected in code"
    },
    "DATABASE_URL": {
        "pattern": r"(?i)(postgres|mysql|mongodb|redis)://[^\s'\"]+:[^\s'\"]+@",
        "severity": Severity.CRITICAL,
        "description": "Database connection string with credentials"
    },
}

# Known vulnerable dependencies (simplified - real implementation would use CVE database)
KNOWN_VULNERABLE_DEPS = {
    "python": {
        "requests": {"below": "2.31.0", "cve": "CVE-2023-32681", "severity": Severity.MEDIUM},
        "django": {"below": "4.2.0", "cve": "Multiple", "severity": Severity.HIGH},
        "flask": {"below": "2.3.0", "cve": "CVE-2023-30861", "severity": Severity.HIGH},
        "pyyaml": {"below": "6.0.0", "cve": "CVE-2020-14343", "severity": Severity.CRITICAL},
    },
    "javascript": {
        "lodash": {"below": "4.17.21", "cve": "CVE-2021-23337", "severity": Severity.HIGH},
        "axios": {"below": "1.6.0", "cve": "CVE-2023-45857", "severity": Severity.MEDIUM},
        "express": {"below": "4.18.0", "cve": "Multiple", "severity": Severity.HIGH},
        "jsonwebtoken": {"below": "9.0.0", "cve": "CVE-2022-23529", "severity": Severity.HIGH},
    }
}


class SecurityScanner:
    """
    Security scanner for generated code.
    
    Scans for:
    - OWASP Top 10 vulnerabilities
    - Hardcoded secrets
    - Vulnerable dependencies
    """
    
    # File extensions to scan
    SCAN_EXTENSIONS = {
        ".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".kt",
        ".go", ".rb", ".php", ".cs", ".swift", ".dart",
        ".html", ".vue", ".svelte",
        ".json", ".yaml", ".yml", ".toml", ".ini", ".env",
        ".sql", ".sh", ".bash"
    }
    
    # Files/directories to skip
    IGNORE_PATTERNS = {
        "node_modules", "venv", ".venv", "__pycache__", ".git",
        "build", "dist", ".next", "vendor", "target",
        "*.min.js", "*.min.css", "*.map"
    }
    
    def __init__(self):
        self.findings: List[SecurityFinding] = []
    
    def scan_project(self, project_dir: str) -> List[SecurityFinding]:
        """
        Perform full security scan of a project.
        
        Args:
            project_dir: Path to project directory
            
        Returns:
            List of SecurityFinding objects
        """
        self.findings = []
        project_path = Path(project_dir)
        
        if not project_path.exists():
            logger.warning(f"Project directory does not exist: {project_dir}")
            return []
        
        # Scan all relevant files
        for file_path in project_path.rglob("*"):
            if not file_path.is_file():
                continue
            
            # Skip ignored paths
            if self._should_ignore(file_path):
                continue
            
            # Check extension
            if file_path.suffix.lower() not in self.SCAN_EXTENSIONS:
                continue
            
            try:
                content = file_path.read_text(encoding="utf-8", errors="ignore")
                relative_path = str(file_path.relative_to(project_path))
                
                # Scan for different issue types
                self._scan_file(relative_path, content)
                
            except Exception as e:
                logger.debug(f"Error scanning {file_path}: {e}")
        
        # Check dependencies
        self._scan_dependencies(project_path)
        
        # Sort by severity
        self.findings.sort(key=lambda f: f.severity)
        
        return self.findings
    
    def _should_ignore(self, file_path: Path) -> bool:
        """Check if a file should be ignored"""
        for part in file_path.parts:
            if part in self.IGNORE_PATTERNS:
                return True
            for pattern in self.IGNORE_PATTERNS:
                if "*" in pattern and file_path.match(pattern):
                    return True
        return False
    
    def _scan_file(self, file_path: str, content: str) -> None:
        """Scan a single file for security issues"""
        lines = content.split("\n")
        
        # OWASP checks
        for rule_id, rule in OWASP_RULES.items():
            for i, line in enumerate(lines, 1):
                if re.search(rule["pattern"], line, re.IGNORECASE):
                    self.findings.append(SecurityFinding(
                        rule_id=rule_id,
                        severity=rule["severity"],
                        file_path=file_path,
                        line_number=i,
                        description=rule["description"],
                        recommendation=rule["recommendation"],
                        cwe_id=rule.get("cwe"),
                        code_snippet=line.strip()[:100]
                    ))
        
        # Secret detection
        for secret_id, secret in SECRET_PATTERNS.items():
            for i, line in enumerate(lines, 1):
                # Skip comments
                stripped = line.strip()
                if stripped.startswith(("#", "//", "*", "/*")):
                    continue
                
                if re.search(secret["pattern"], line):
                    self.findings.append(SecurityFinding(
                        rule_id=f"SECRET_{secret_id}",
                        severity=secret["severity"],
                        file_path=file_path,
                        line_number=i,
                        description=secret["description"],
                        recommendation="Remove secrets from code, use environment variables or secret management",
                        code_snippet=self._redact_secret(line.strip()[:100])
                    ))
    
    def _redact_secret(self, text: str) -> str:
        """Redact potential secrets from code snippets"""
        # Replace potential secret values with [REDACTED]
        patterns = [
            (r'(["\'])([^"\']{8,})(["\'])', r'\1[REDACTED]\3'),
            (r'(=\s*)([^\s"\']{8,})(\s|$)', r'\1[REDACTED]\3'),
        ]
        result = text
        for pattern, replacement in patterns:
            result = re.sub(pattern, replacement, result)
        return result
    
    def _scan_dependencies(self, project_path: Path) -> None:
        """Scan dependencies for known vulnerabilities"""
        # Check Python requirements
        req_files = ["requirements.txt", "Pipfile", "pyproject.toml"]
        for req_file in req_files:
            req_path = project_path / req_file
            if req_path.exists():
                self._check_python_deps(req_path)
        
        # Check JavaScript dependencies
        pkg_json = project_path / "package.json"
        if pkg_json.exists():
            self._check_js_deps(pkg_json)
    
    def _check_python_deps(self, requirements_path: Path) -> None:
        """Check Python dependencies for vulnerabilities"""
        try:
            content = requirements_path.read_text()
            for dep, vuln_info in KNOWN_VULNERABLE_DEPS["python"].items():
                # Simple pattern matching for requirements.txt style
                pattern = rf"{dep}[=<>~!]*([0-9.]+)"
                match = re.search(pattern, content, re.IGNORECASE)
                if match:
                    version = match.group(1)
                    if self._is_version_below(version, vuln_info["below"]):
                        self.findings.append(SecurityFinding(
                            rule_id=f"DEP_VULN_{dep.upper()}",
                            severity=vuln_info["severity"],
                            file_path=str(requirements_path.name),
                            line_number=None,
                            description=f"Vulnerable dependency: {dep} {version} (CVE: {vuln_info['cve']})",
                            recommendation=f"Update {dep} to version {vuln_info['below']} or higher"
                        ))
        except Exception as e:
            logger.debug(f"Error checking Python deps: {e}")
    
    def _check_js_deps(self, package_json_path: Path) -> None:
        """Check JavaScript dependencies for vulnerabilities"""
        try:
            content = json.loads(package_json_path.read_text())
            all_deps = {
                **content.get("dependencies", {}),
                **content.get("devDependencies", {})
            }
            
            for dep, vuln_info in KNOWN_VULNERABLE_DEPS["javascript"].items():
                if dep in all_deps:
                    version = all_deps[dep].lstrip("^~>=<")
                    if self._is_version_below(version, vuln_info["below"]):
                        self.findings.append(SecurityFinding(
                            rule_id=f"DEP_VULN_{dep.upper()}",
                            severity=vuln_info["severity"],
                            file_path="package.json",
                            line_number=None,
                            description=f"Vulnerable dependency: {dep} {version} (CVE: {vuln_info['cve']})",
                            recommendation=f"Update {dep} to version {vuln_info['below']} or higher"
                        ))
        except Exception as e:
            logger.debug(f"Error checking JS deps: {e}")
    
    def _is_version_below(self, version: str, threshold: str) -> bool:
        """Compare semantic versions"""
        try:
            v_parts = [int(x) for x in version.split(".")[:3]]
            t_parts = [int(x) for x in threshold.split(".")[:3]]
            
            # Pad with zeros
            while len(v_parts) < 3:
                v_parts.append(0)
            while len(t_parts) < 3:
                t_parts.append(0)
            
            return v_parts < t_parts
        except:
            return False  # Can't compare, assume OK
    
    def get_security_score(self, findings: List[SecurityFinding] = None) -> int:
        """
        Calculate a security score (0-100) based on findings.
        
        Higher score = more secure
        """
        if findings is None:
            findings = self.findings
        
        if not findings:
            return 100
        
        # Deductions by severity
        deductions = {
            Severity.CRITICAL: 25,
            Severity.HIGH: 15,
            Severity.MEDIUM: 8,
            Severity.LOW: 3,
            Severity.INFO: 1
        }
        
        total_deduction = sum(
            deductions.get(f.severity, 0) for f in findings
        )
        
        return max(0, 100 - total_deduction)
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of security scan"""
        severity_counts = {}
        for f in self.findings:
            sev = f.severity.value
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        
        return {
            "total_findings": len(self.findings),
            "by_severity": severity_counts,
            "security_score": self.get_security_score(),
            "critical_count": severity_counts.get("critical", 0),
            "high_count": severity_counts.get("high", 0)
        }
    
    def get_report(self) -> str:
        """Generate a human-readable security report"""
        lines = [
            "=" * 60,
            "SECURITY SCAN REPORT",
            "=" * 60,
            ""
        ]
        
        summary = self.get_summary()
        lines.append(f"Security Score: {summary['security_score']}/100")
        lines.append(f"Total Findings: {summary['total_findings']}")
        lines.append("")
        
        if not self.findings:
            lines.append("✓ No security issues found!")
        else:
            # Group by severity
            for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
                sev_findings = [f for f in self.findings if f.severity == severity]
                if sev_findings:
                    lines.append(f"\n{severity.value.upper()} ({len(sev_findings)}):")
                    for f in sev_findings[:5]:  # Limit per severity
                        loc = f"{f.file_path}:{f.line_number}" if f.line_number else f.file_path
                        lines.append(f"  [{f.rule_id}] {loc}")
                        lines.append(f"    {f.description}")
                        lines.append(f"    → {f.recommendation}")
        
        lines.append("\n" + "=" * 60)
        return "\n".join(lines)


__all__ = ['SecurityScanner', 'SecurityFinding', 'Severity']
