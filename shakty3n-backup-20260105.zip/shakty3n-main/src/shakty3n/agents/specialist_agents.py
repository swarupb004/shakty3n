"""
Multi-Agent Collaboration Framework
Specialist agents with domain expertise that work together to complete tasks.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
import time
import asyncio
import logging

logger = logging.getLogger(__name__)


class AgentRole(Enum):
    """Specialist agent roles"""
    ARCHITECT = "architect"
    BACKEND = "backend"
    FRONTEND = "frontend"
    QA = "qa"
    SECURITY = "security"
    DEVOPS = "devops"
    GENERAL = "general"


@dataclass
class AgentContext:
    """Context passed to agents for task execution"""
    project_description: str
    project_type: str
    current_files: Dict[str, str] = field(default_factory=dict)
    conversation_history: List[Dict] = field(default_factory=list)
    decisions: List[Dict] = field(default_factory=list)
    preferences: Dict[str, str] = field(default_factory=dict)


@dataclass
class AgentResult:
    """Result from an agent's task execution"""
    success: bool
    output: Any
    files_created: List[str] = field(default_factory=list)
    files_modified: List[str] = field(default_factory=list)
    decisions_made: List[Dict] = field(default_factory=list)
    duration_seconds: float = 0.0
    error: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "success": self.success,
            "output": str(self.output)[:500] if self.output else None,
            "files_created": self.files_created,
            "files_modified": self.files_modified,
            "decisions_made": self.decisions_made,
            "duration_seconds": self.duration_seconds,
            "error": self.error
        }


class SpecialistAgent(ABC):
    """
    Base class for specialist agents.
    
    Each specialist has domain expertise and a tailored system prompt.
    """
    
    def __init__(self, ai_provider, workspace=None, memory=None):
        """
        Args:
            ai_provider: AI provider for generation
            workspace: AgentWorkspace for file/terminal operations
            memory: LongTermMemory for context
        """
        self.ai = ai_provider
        self.workspace = workspace
        self.memory = memory
        self.role = self.get_role()
        self._tools = self._get_tools()
    
    @abstractmethod
    def get_role(self) -> AgentRole:
        """Return the agent's role"""
        pass
    
    @abstractmethod
    def get_system_prompt(self) -> str:
        """Return the role-specific system prompt"""
        pass
    
    @abstractmethod
    def get_expertise_keywords(self) -> List[str]:
        """Return keywords that indicate this agent's expertise"""
        pass
    
    def can_handle_task(self, task: Dict) -> bool:
        """Check if this agent can handle the given task"""
        task_text = f"{task.get('title', '')} {task.get('description', '')}".lower()
        keywords = self.get_expertise_keywords()
        return any(kw in task_text for kw in keywords)
    
    def _get_tools(self) -> Dict[str, Callable]:
        """Get available tools for this agent"""
        if self.workspace:
            return {
                "read_file": self.workspace.open_file,
                "write_file": self.workspace.save_file,
                "list_dir": lambda p=".": str(list(self.workspace._resolve_path(p).iterdir())),
                "run_command": self.workspace.run_terminal_command,
            }
        return {}
    
    def execute_task(self, task: Dict, context: AgentContext) -> AgentResult:
        """
        Execute a task using ReAct loop with role-specific prompts.
        
        Args:
            task: Task dict with id, title, description
            context: AgentContext with project info
            
        Returns:
            AgentResult with execution outcome
        """
        start_time = time.time()
        
        # Build the full prompt
        system_prompt = self.get_system_prompt()
        
        # Add memory context if available
        memory_context = ""
        if self.memory:
            memory_context = self.memory.get_context_for_prompt(
                context.project_description[:50]
            )
        
        prompt = self._build_task_prompt(task, context, memory_context)
        
        try:
            # ReAct loop with limited iterations
            history = []
            max_steps = 10
            files_created = []
            files_modified = []
            decisions = []
            
            for i in range(max_steps):
                # Generate next step
                full_prompt = "\n".join(history) + "\n\nYour turn:\nThought:" if history else prompt + "\n\nThought:"
                
                response = self.ai.generate(
                    prompt=full_prompt,
                    system_prompt=system_prompt,
                    stop=["Observation:"],
                    temperature=0.3
                )
                
                if "Thought:" not in response:
                    response = "Thought: " + response
                
                logger.debug(f"[{self.role.value}] Step {i+1}: {response[:100]}...")
                history.append(response)
                
                # Check for finish
                if "finish()" in response.lower() or "task complete" in response.lower():
                    break
                
                # Extract and execute tool calls
                tool_code = self._extract_tool_code(response)
                if tool_code:
                    observation = self._execute_tool(tool_code)
                    history.append(f"Observation: {observation}")
                    
                    # Track file operations
                    if "write_file" in tool_code:
                        # Extract filename from tool call
                        import re
                        match = re.search(r'write_file\s*\(\s*["\']([^"\']+)["\']', tool_code)
                        if match:
                            filename = match.group(1)
                            if filename not in files_created:
                                files_created.append(filename)
            
            duration = time.time() - start_time
            
            return AgentResult(
                success=True,
                output="\n".join(history),
                files_created=files_created,
                files_modified=files_modified,
                decisions_made=decisions,
                duration_seconds=duration
            )
            
        except Exception as e:
            logger.error(f"[{self.role.value}] Task execution failed: {e}")
            return AgentResult(
                success=False,
                output=None,
                error=str(e),
                duration_seconds=time.time() - start_time
            )
    
    def _build_task_prompt(self, task: Dict, context: AgentContext, memory_context: str) -> str:
        """Build the task execution prompt"""
        return f"""You are executing a task as part of a larger project.

ROLE: {self.role.value}
TASK: {task.get('title', 'Untitled')}
DESCRIPTION: {task.get('description', 'No description')}

PROJECT CONTEXT:
{context.project_description}
Project Type: {context.project_type}

{f"MEMORY CONTEXT:{chr(10)}{memory_context}" if memory_context else ""}

AVAILABLE TOOLS:
1. read_file(path) - Read a file's contents
2. write_file(path, content) - Write content to a file
3. list_dir(path) - List directory contents
4. run_command(cmd) - Run a terminal command
5. finish() - Mark task as complete

Use <tool_code>function_name(args)</tool_code> to call tools.

Complete the task step by step. When done, call finish().
"""
    
    def _extract_tool_code(self, text: str) -> Optional[str]:
        """Extract tool code from response"""
        if "<tool_code>" in text and "</tool_code>" in text:
            start = text.find("<tool_code>") + 11
            end = text.find("</tool_code>", start)
            return text[start:end].strip()
        return None
    
    def _execute_tool(self, code: str) -> str:
        """Execute a tool call safely"""
        try:
            import ast
            
            # Parse the code
            parsed = ast.parse(code, mode="eval")
            if not isinstance(parsed.body, ast.Call):
                return "Error: Not a valid function call"
            
            func_name = parsed.body.func.id
            if func_name not in self._tools and func_name != "finish":
                return f"Error: Unknown tool '{func_name}'"
            
            if func_name == "finish":
                return "Task completed"
            
            # Extract arguments
            args = []
            for arg in parsed.body.args:
                if isinstance(arg, ast.Constant):
                    args.append(arg.value)
                else:
                    return "Error: Only literal arguments supported"
            
            # Execute
            result = self._tools[func_name](*args)
            return str(result)[:500]
            
        except Exception as e:
            return f"Tool error: {str(e)}"


class ArchitectAgent(SpecialistAgent):
    """Designs system architecture and high-level structure"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.ARCHITECT
    
    def get_expertise_keywords(self) -> List[str]:
        return ["architecture", "design", "structure", "pattern", "schema", 
                "plan", "organize", "layout", "component structure"]
    
    def get_system_prompt(self) -> str:
        return """You are a senior software architect. Your responsibilities:
- Design clean, scalable system architectures
- Define clear component boundaries and interfaces
- Choose appropriate design patterns
- Create folder structures that scale
- Document architectural decisions

When designing:
1. Start with high-level structure
2. Define clear separation of concerns
3. Plan for testability and maintainability
4. Consider security implications
5. Document decisions for future reference

Output well-organized, production-ready structures."""


class BackendAgent(SpecialistAgent):
    """Implements server-side logic, APIs, and databases"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.BACKEND
    
    def get_expertise_keywords(self) -> List[str]:
        return ["api", "server", "database", "endpoint", "model", "controller",
                "auth", "authentication", "route", "middleware", "backend"]
    
    def get_system_prompt(self) -> str:
        return """You are a senior backend engineer. Your responsibilities:
- Implement robust API endpoints
- Design efficient database schemas
- Handle authentication and authorization
- Write secure, performant server code
- Implement proper error handling

Best practices you follow:
1. RESTful API design
2. Input validation and sanitization
3. Proper error responses with status codes
4. Database query optimization
5. Security-first mindset (no hardcoded secrets)

Write production-quality backend code."""


class FrontendAgent(SpecialistAgent):
    """Implements UI components and client-side logic"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.FRONTEND
    
    def get_expertise_keywords(self) -> List[str]:
        return ["ui", "component", "page", "style", "css", "layout", "view",
                "form", "button", "frontend", "react", "vue", "html"]
    
    def get_system_prompt(self) -> str:
        return """You are a senior frontend engineer. Your responsibilities:
- Create beautiful, responsive UI components
- Implement smooth user interactions
- Write accessible, semantic HTML
- Style with modern CSS practices
- Handle state management properly

Best practices you follow:
1. Component-based architecture
2. Responsive design (mobile-first)
3. Accessibility (WCAG compliance)
4. Performance optimization
5. Clean, maintainable CSS

Create polished, user-friendly interfaces."""


class QAAgent(SpecialistAgent):
    """Generates and runs tests, validates functionality"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.QA
    
    def get_expertise_keywords(self) -> List[str]:
        return ["test", "spec", "validate", "verify", "check", "assert",
                "coverage", "unit test", "integration", "e2e"]
    
    def get_system_prompt(self) -> str:
        return """You are a senior QA engineer. Your responsibilities:
- Write comprehensive test suites
- Ensure code coverage targets are met
- Identify edge cases and error scenarios
- Validate business logic correctness
- Create integration and e2e tests

Testing principles you follow:
1. Test behavior, not implementation
2. Arrange-Act-Assert pattern
3. Meaningful test descriptions
4. Mock external dependencies
5. Test error paths too

Write thorough tests that catch bugs before production."""


class SecurityAgent(SpecialistAgent):
    """Reviews code for security issues and runs scans"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.SECURITY
    
    def get_expertise_keywords(self) -> List[str]:
        return ["security", "auth", "permission", "encrypt", "sanitize",
                "validate input", "vulnerability", "owasp", "secret"]
    
    def get_system_prompt(self) -> str:
        return """You are a security engineer. Your responsibilities:
- Review code for security vulnerabilities
- Identify OWASP Top 10 issues
- Check for hardcoded secrets
- Validate authentication/authorization
- Ensure proper input sanitization

Security principles you enforce:
1. Never trust user input
2. Principle of least privilege
3. Defense in depth
4. Secure by default
5. Keep secrets out of code

Find and fix security issues before they become problems."""


class DevOpsAgent(SpecialistAgent):
    """Handles CI/CD, deployment, and infrastructure"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.DEVOPS
    
    def get_expertise_keywords(self) -> List[str]:
        return ["deploy", "ci", "cd", "docker", "pipeline", "build", "config",
                "infrastructure", "kubernetes", "github actions", "environment"]
    
    def get_system_prompt(self) -> str:
        return """You are a DevOps engineer. Your responsibilities:
- Set up CI/CD pipelines
- Configure build and deployment
- Manage infrastructure as code
- Optimize build performance
- Handle environment configuration

DevOps practices you follow:
1. Everything as code (IaC)
2. Automated testing in CI
3. Immutable deployments
4. Environment parity
5. Secure secret management

Create robust, automated deployment workflows."""


class GeneralAgent(SpecialistAgent):
    """General-purpose agent for tasks that don't fit specialists"""
    
    def get_role(self) -> AgentRole:
        return AgentRole.GENERAL
    
    def get_expertise_keywords(self) -> List[str]:
        return []  # Handles anything not claimed by specialists
    
    def can_handle_task(self, task: Dict) -> bool:
        return True  # Fallback for any task
    
    def get_system_prompt(self) -> str:
        return """You are a senior full-stack developer. Your responsibilities:
- Implement features end-to-end
- Write clean, maintainable code
- Follow best practices for the project type
- Handle any development task

Approach:
1. Understand the requirement fully
2. Plan before coding
3. Write clean, documented code
4. Test your work
5. Consider edge cases

Deliver quality work on any task."""


class AgentOrchestrator:
    """
    Coordinates multiple specialist agents.
    
    Assigns tasks to appropriate specialists and manages parallel execution.
    """
    
    def __init__(self, ai_provider, workspace=None, memory=None):
        """
        Args:
            ai_provider: AI provider for agents
            workspace: Shared workspace for file operations
            memory: Shared long-term memory
        """
        self.ai = ai_provider
        self.workspace = workspace
        self.memory = memory
        
        # Initialize all specialist agents
        self.agents: Dict[AgentRole, SpecialistAgent] = {
            AgentRole.ARCHITECT: ArchitectAgent(ai_provider, workspace, memory),
            AgentRole.BACKEND: BackendAgent(ai_provider, workspace, memory),
            AgentRole.FRONTEND: FrontendAgent(ai_provider, workspace, memory),
            AgentRole.QA: QAAgent(ai_provider, workspace, memory),
            AgentRole.SECURITY: SecurityAgent(ai_provider, workspace, memory),
            AgentRole.DEVOPS: DevOpsAgent(ai_provider, workspace, memory),
            AgentRole.GENERAL: GeneralAgent(ai_provider, workspace, memory),
        }
    
    def get_best_agent(self, task: Dict) -> SpecialistAgent:
        """Find the best agent for a task"""
        # Check specialists first (in priority order)
        priority_order = [
            AgentRole.SECURITY,  # Security first
            AgentRole.ARCHITECT,
            AgentRole.BACKEND,
            AgentRole.FRONTEND,
            AgentRole.DEVOPS,
            AgentRole.QA,
        ]
        
        for role in priority_order:
            agent = self.agents[role]
            if agent.can_handle_task(task):
                return agent
        
        # Fallback to general agent
        return self.agents[AgentRole.GENERAL]
    
    def assign_tasks(self, tasks: List[Dict]) -> List[Dict]:
        """
        Assign each task to the appropriate specialist agent.
        
        Returns tasks with assigned_agent field populated.
        """
        assigned = []
        for task in tasks:
            agent = self.get_best_agent(task)
            task["assigned_agent"] = agent.get_role().value
            assigned.append(task)
            logger.info(f"Assigned '{task.get('title')}' to {agent.get_role().value}")
        
        return assigned
    
    def execute_task(self, task: Dict, context: AgentContext) -> AgentResult:
        """Execute a single task with the appropriate agent"""
        role_str = task.get("assigned_agent", "general")
        try:
            role = AgentRole(role_str)
        except ValueError:
            role = AgentRole.GENERAL
        
        agent = self.agents.get(role, self.agents[AgentRole.GENERAL])
        return agent.execute_task(task, context)
    
    async def execute_parallel(self, tasks: List[Dict], 
                                context: AgentContext) -> Dict[str, AgentResult]:
        """
        Execute independent tasks in parallel using appropriate agents.
        
        Args:
            tasks: List of tasks to execute in parallel
            context: Shared context
            
        Returns:
            Dict mapping task_id to AgentResult
        """
        results = {}
        
        # For now, execute sequentially (true async would require async AI calls)
        # This is a foundation for future parallel execution
        for task in tasks:
            task_id = task.get("id", str(id(task)))
            result = self.execute_task(task, context)
            results[task_id] = result
            
            # Update context with new files
            if result.files_created:
                for filename in result.files_created:
                    if self.workspace:
                        try:
                            content = self.workspace.open_file(filename)
                            context.current_files[filename] = content
                        except:
                            pass
        
        return results
    
    def get_agent_summary(self) -> Dict[str, Any]:
        """Get summary of available agents"""
        return {
            "agents": [
                {
                    "role": role.value,
                    "expertise": agent.get_expertise_keywords()[:5]
                }
                for role, agent in self.agents.items()
            ],
            "total_agents": len(self.agents)
        }


__all__ = [
    'AgentRole', 'AgentContext', 'AgentResult', 'SpecialistAgent',
    'ArchitectAgent', 'BackendAgent', 'FrontendAgent', 'QAAgent',
    'SecurityAgent', 'DevOpsAgent', 'GeneralAgent', 'AgentOrchestrator'
]
