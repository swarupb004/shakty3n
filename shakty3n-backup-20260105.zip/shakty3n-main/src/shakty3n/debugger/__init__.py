"""
Debugger Module

Provides automatic debugging and self-healing capabilities.
"""
from .auto_debugger import AutoDebugger
from .self_healer import SelfHealer, ErrorAnalysis, ErrorCategory, HealingAttempt

__all__ = ['AutoDebugger', 'SelfHealer', 'ErrorAnalysis', 'ErrorCategory', 'HealingAttempt']
