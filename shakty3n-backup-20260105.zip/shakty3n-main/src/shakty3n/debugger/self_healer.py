"""
Self-Healing and Auto-Debugging System

Provides automatic error detection, analysis, and healing capabilities.
Integrates with the autonomous executor to recover from failures.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import re
import traceback
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)


class ErrorCategory(Enum):
    """Categories of errors for targeted healing"""
    SYNTAX_ERROR = "syntax_error"
    IMPORT_ERROR = "import_error"
    TYPE_ERROR = "type_error"
    NAME_ERROR = "name_error"
    ATTRIBUTE_ERROR = "attribute_error"
    VALUE_ERROR = "value_error"
    FILE_ERROR = "file_error"
    NETWORK_ERROR = "network_error"
    TIMEOUT_ERROR = "timeout_error"
    PERMISSION_ERROR = "permission_error"
    DEPENDENCY_ERROR = "dependency_error"
    UNKNOWN = "unknown"


@dataclass
class ErrorAnalysis:
    """Analysis of an error for healing"""
    category: ErrorCategory
    message: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    code_snippet: Optional[str] = None
    suggested_fixes: List[str] = field(default_factory=list)
    confidence: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            "category": self.category.value,
            "message": self.message,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "code_snippet": self.code_snippet,
            "suggested_fixes": self.suggested_fixes,
            "confidence": self.confidence
        }


@dataclass
class HealingAttempt:
    """Record of a healing attempt"""
    timestamp: float
    error_analysis: ErrorAnalysis
    fix_applied: str
    success: bool
    result: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "error": self.error_analysis.to_dict(),
            "fix_applied": self.fix_applied,
            "success": self.success,
            "result": self.result
        }


# Common error patterns with regex and fix strategies
ERROR_PATTERNS = {
    ErrorCategory.SYNTAX_ERROR: [
        {
            "pattern": r"SyntaxError: invalid syntax.*line (\d+)",
            "fix_hints": ["Check for missing parentheses, brackets, or colons", 
                         "Verify proper indentation"]
        },
        {
            "pattern": r"SyntaxError: unexpected EOF",
            "fix_hints": ["Check for unclosed strings, parentheses, or brackets",
                         "Look for missing closing delimiters"]
        },
        {
            "pattern": r"IndentationError",
            "fix_hints": ["Fix indentation to use consistent spaces (4 spaces recommended)",
                         "Don't mix tabs and spaces"]
        }
    ],
    ErrorCategory.IMPORT_ERROR: [
        {
            "pattern": r"ModuleNotFoundError: No module named '(\w+)'",
            "fix_hints": ["Install missing module with pip: pip install {0}",
                         "Check if module name is spelled correctly"]
        },
        {
            "pattern": r"ImportError: cannot import name '(\w+)'",
            "fix_hints": ["Check if the name exists in the module",
                         "Verify the import path is correct"]
        }
    ],
    ErrorCategory.TYPE_ERROR: [
        {
            "pattern": r"TypeError: '(\w+)' object is not (callable|subscriptable|iterable)",
            "fix_hints": ["Check variable types before operations",
                         "Ensure proper type conversions"]
        },
        {
            "pattern": r"TypeError: (\w+)\(\) takes (\d+) positional arguments? but (\d+) (?:was|were) given",
            "fix_hints": ["Adjust function arguments to match signature",
                         "Check function definition for correct parameters"]
        }
    ],
    ErrorCategory.NAME_ERROR: [
        {
            "pattern": r"NameError: name '(\w+)' is not defined",
            "fix_hints": ["Define the variable before use",
                         "Check for typos in variable name",
                         "Import the module if it's a module reference"]
        }
    ],
    ErrorCategory.ATTRIBUTE_ERROR: [
        {
            "pattern": r"AttributeError: '(\w+)' object has no attribute '(\w+)'",
            "fix_hints": ["Check if attribute exists on the object type",
                         "Verify object is of expected type"]
        }
    ],
    ErrorCategory.FILE_ERROR: [
        {
            "pattern": r"FileNotFoundError: \[Errno 2\] No such file",
            "fix_hints": ["Create the file or directory",
                         "Check if path is correct"]
        }
    ],
    ErrorCategory.PERMISSION_ERROR: [
        {
            "pattern": r"PermissionError: \[Errno 13\]",
            "fix_hints": ["Check file/directory permissions",
                         "Run with appropriate permissions"]
        }
    ],
    ErrorCategory.DEPENDENCY_ERROR: [
        {
            "pattern": r"pkg_resources.DistributionNotFound|distutils.errors",
            "fix_hints": ["Install missing dependencies",
                         "Update requirements.txt"]
        }
    ]
}

# Common Python syntax fixes
COMMON_FIXES = {
    "missing_colon": (r"(if|else|elif|for|while|def|class|try|except|finally|with)\s+[^:]+$", 
                      lambda m: m.group(0) + ":"),
    "missing_parentheses": (r"print\s+([^(\n]+)$", 
                           lambda m: f"print({m.group(1)})"),
    "f_string_fix": (r'\"([^\"]*)\{([^}]+)\}([^\"]*)\"(?!\s*\.format)',
                    lambda m: f'f"{m.group(1)}{{{m.group(2)}}}{m.group(3)}"'),
}


class SelfHealer:
    """
    Automatic error detection and healing system.
    
    Features:
    - Error pattern matching and categorization
    - AI-powered fix generation
    - Automatic fix application with rollback
    - Learning from successful fixes
    """
    
    MAX_HEALING_ATTEMPTS = 3
    BACKOFF_MULTIPLIER = 1.5
    
    def __init__(self, ai_provider=None, project_dir: Optional[str] = None):
        self.ai_provider = ai_provider
        self.project_dir = project_dir
        self.healing_history: List[HealingAttempt] = []
        self.file_backups: Dict[str, str] = {}  # path -> original content
        
    def analyze_error(self, error: Exception, context: Optional[Dict] = None) -> ErrorAnalysis:
        """
        Analyze an error and determine fix strategy.
        
        Args:
            error: The exception that occurred
            context: Additional context (file being processed, recent actions, etc.)
            
        Returns:
            ErrorAnalysis with categorization and suggested fixes
        """
        error_str = str(error)
        error_type = type(error).__name__
        tb = traceback.format_exception(type(error), error, error.__traceback__)
        full_traceback = "".join(tb)
        
        # Extract file and line info from traceback
        file_path = None
        line_number = None
        code_snippet = None
        
        # Parse traceback for location
        file_line_pattern = r'File "([^"]+)", line (\d+)'
        matches = re.findall(file_line_pattern, full_traceback)
        if matches:
            # Get the last (most relevant) match
            file_path, line_number = matches[-1]
            line_number = int(line_number)
            
            # Try to get code snippet
            try:
                with open(file_path, 'r') as f:
                    lines = f.readlines()
                    if 0 < line_number <= len(lines):
                        start = max(0, line_number - 3)
                        end = min(len(lines), line_number + 2)
                        code_snippet = "".join(lines[start:end])
            except:
                pass
        
        # Categorize error
        category = ErrorCategory.UNKNOWN
        suggested_fixes = []
        confidence = 0.0
        
        for cat, patterns in ERROR_PATTERNS.items():
            for pattern_info in patterns:
                match = re.search(pattern_info["pattern"], error_str + full_traceback, re.IGNORECASE)
                if match:
                    category = cat
                    # Apply captured groups to fix hints
                    for hint in pattern_info["fix_hints"]:
                        try:
                            fixed_hint = hint.format(*match.groups()) if match.groups() else hint
                            suggested_fixes.append(fixed_hint)
                        except:
                            suggested_fixes.append(hint)
                    confidence = 0.8
                    break
            if category != ErrorCategory.UNKNOWN:
                break
        
        # If still unknown, try to categorize by exception type
        if category == ErrorCategory.UNKNOWN:
            type_mapping = {
                "SyntaxError": ErrorCategory.SYNTAX_ERROR,
                "ImportError": ErrorCategory.IMPORT_ERROR,
                "ModuleNotFoundError": ErrorCategory.IMPORT_ERROR,
                "TypeError": ErrorCategory.TYPE_ERROR,
                "NameError": ErrorCategory.NAME_ERROR,
                "AttributeError": ErrorCategory.ATTRIBUTE_ERROR,
                "ValueError": ErrorCategory.VALUE_ERROR,
                "FileNotFoundError": ErrorCategory.FILE_ERROR,
                "PermissionError": ErrorCategory.PERMISSION_ERROR,
                "TimeoutError": ErrorCategory.TIMEOUT_ERROR,
            }
            category = type_mapping.get(error_type, ErrorCategory.UNKNOWN)
            confidence = 0.5
        
        return ErrorAnalysis(
            category=category,
            message=error_str,
            file_path=file_path,
            line_number=line_number,
            code_snippet=code_snippet,
            suggested_fixes=suggested_fixes,
            confidence=confidence
        )
    
    def generate_fix(self, analysis: ErrorAnalysis, context: Optional[Dict] = None) -> Optional[str]:
        """
        Generate a fix for the error using AI.
        
        Args:
            analysis: The error analysis
            context: Additional context
            
        Returns:
            Suggested fix as a string, or None if no fix could be generated
        """
        if not self.ai_provider:
            # Use pattern-based fixes only
            return self._generate_pattern_fix(analysis)
        
        # Build prompt for AI
        prompt = f"""Fix the following error in the code:

Error Type: {analysis.category.value}
Error Message: {analysis.message}
"""
        
        if analysis.file_path:
            prompt += f"File: {analysis.file_path}\n"
        if analysis.line_number:
            prompt += f"Line: {analysis.line_number}\n"
        if analysis.code_snippet:
            prompt += f"\nCode Context:\n```\n{analysis.code_snippet}\n```\n"
        
        if analysis.suggested_fixes:
            prompt += f"\nPossible fixes:\n"
            for fix in analysis.suggested_fixes:
                prompt += f"- {fix}\n"
        
        prompt += """
Provide ONLY the corrected code that should replace the problematic code.
Do not include explanations, just the fixed code.
If the fix requires installing a package, prefix with: # pip install <package>
"""
        
        try:
            response = self.ai_provider.generate(
                prompt=prompt,
                system_prompt="You are a code repair expert. Provide only the corrected code without explanations."
            )
            
            # Clean up response
            fix = response.strip()
            
            # Remove markdown code blocks if present
            if fix.startswith("```"):
                lines = fix.split("\n")
                if len(lines) > 2:
                    fix = "\n".join(lines[1:-1])
            
            return fix
            
        except Exception as e:
            logger.warning(f"AI fix generation failed: {e}")
            return self._generate_pattern_fix(analysis)
    
    def _generate_pattern_fix(self, analysis: ErrorAnalysis) -> Optional[str]:
        """Generate fix using pattern matching only (no AI)"""
        if not analysis.code_snippet:
            return None
        
        fixed_code = analysis.code_snippet
        
        for fix_name, (pattern, replacement) in COMMON_FIXES.items():
            if re.search(pattern, fixed_code):
                fixed_code = re.sub(pattern, replacement, fixed_code)
                return fixed_code
        
        return None
    
    def apply_fix(self, file_path: str, fix: str, line_number: Optional[int] = None) -> bool:
        """
        Apply a fix to a file, with backup for rollback.
        
        Args:
            file_path: Path to the file to fix
            fix: The fix to apply
            line_number: Optional line number to target
            
        Returns:
            True if fix was applied successfully
        """
        try:
            path = Path(file_path)
            if not path.exists():
                logger.error(f"File not found: {file_path}")
                return False
            
            # Backup original content
            original_content = path.read_text()
            self.file_backups[file_path] = original_content
            
            # Check if fix is a pip install command
            if fix.strip().startswith("# pip install"):
                # Don't modify file, just note the dependency
                logger.info(f"Dependency required: {fix}")
                return True
            
            # Apply fix
            if line_number and line_number > 0:
                lines = original_content.split("\n")
                # Replace lines around the problematic line
                fix_lines = fix.split("\n")
                
                # Simple replacement strategy: replace the problematic line
                start = max(0, line_number - 1)
                end = min(len(lines), start + len(fix_lines))
                
                lines[start:end] = fix_lines
                new_content = "\n".join(lines)
            else:
                # Replace entire content
                new_content = fix
            
            path.write_text(new_content)
            logger.info(f"Applied fix to {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to apply fix: {e}")
            return False
    
    def rollback(self, file_path: str) -> bool:
        """
        Rollback a file to its pre-fix state.
        
        Args:
            file_path: Path to the file to rollback
            
        Returns:
            True if rollback was successful
        """
        if file_path not in self.file_backups:
            logger.warning(f"No backup found for {file_path}")
            return False
        
        try:
            path = Path(file_path)
            path.write_text(self.file_backups[file_path])
            del self.file_backups[file_path]
            logger.info(f"Rolled back {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Rollback failed: {e}")
            return False
    
    def heal(self, error: Exception, context: Optional[Dict] = None, 
             validate_fn=None) -> Tuple[bool, Optional[str]]:
        """
        Attempt to heal an error automatically.
        
        Args:
            error: The exception to heal
            context: Additional context
            validate_fn: Optional function to validate the fix works
            
        Returns:
            Tuple of (success, result_message)
        """
        analysis = self.analyze_error(error, context)
        
        if analysis.confidence < 0.3:
            logger.warning(f"Low confidence error analysis: {analysis.confidence}")
            return False, f"Could not confidently analyze error: {analysis.message}"
        
        # Track attempts with exponential backoff
        for attempt in range(self.MAX_HEALING_ATTEMPTS):
            delay = (self.BACKOFF_MULTIPLIER ** attempt) * 0.5
            
            if attempt > 0:
                logger.info(f"Healing attempt {attempt + 1}/{self.MAX_HEALING_ATTEMPTS} (backoff: {delay:.1f}s)")
                time.sleep(delay)
            
            fix = self.generate_fix(analysis, context)
            
            if not fix:
                logger.warning(f"Could not generate fix for: {analysis.category.value}")
                continue
            
            # Apply fix if we know the file
            if analysis.file_path:
                applied = self.apply_fix(analysis.file_path, fix, analysis.line_number)
                
                if not applied:
                    continue
                
                # Validate if function provided
                if validate_fn:
                    try:
                        valid = validate_fn()
                        if valid:
                            self._record_attempt(analysis, fix, True, "Fix validated successfully")
                            return True, "Error healed successfully"
                        else:
                            self.rollback(analysis.file_path)
                    except Exception as ve:
                        logger.warning(f"Validation failed: {ve}")
                        self.rollback(analysis.file_path)
                        # Update analysis with new error for next attempt
                        analysis = self.analyze_error(ve, context)
                else:
                    # No validation, assume success
                    self._record_attempt(analysis, fix, True, "Fix applied (unvalidated)")
                    return True, "Fix applied"
            else:
                # No file to modify, return the fix suggestion
                self._record_attempt(analysis, fix, True, "Fix suggested")
                return True, f"Suggested fix:\n{fix}"
        
        self._record_attempt(analysis, "No fix applied", False, "Max attempts reached")
        return False, f"Could not heal error after {self.MAX_HEALING_ATTEMPTS} attempts"
    
    def _record_attempt(self, analysis: ErrorAnalysis, fix: str, 
                       success: bool, result: str) -> None:
        """Record a healing attempt for history/learning"""
        attempt = HealingAttempt(
            timestamp=time.time(),
            error_analysis=analysis,
            fix_applied=fix,
            success=success,
            result=result
        )
        self.healing_history.append(attempt)
    
    def get_healing_summary(self) -> Dict[str, Any]:
        """Get summary of healing attempts"""
        if not self.healing_history:
            return {"total": 0, "success": 0, "failure": 0, "rate": 0.0}
        
        success_count = sum(1 for a in self.healing_history if a.success)
        total = len(self.healing_history)
        
        return {
            "total": total,
            "success": success_count,
            "failure": total - success_count,
            "rate": success_count / total if total > 0 else 0.0,
            "by_category": self._count_by_category()
        }
    
    def _count_by_category(self) -> Dict[str, int]:
        """Count healing attempts by error category"""
        counts = {}
        for attempt in self.healing_history:
            cat = attempt.error_analysis.category.value
            counts[cat] = counts.get(cat, 0) + 1
        return counts


__all__ = ['SelfHealer', 'ErrorAnalysis', 'ErrorCategory', 'HealingAttempt']
