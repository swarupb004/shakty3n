"""
Autonomous Execution Engine

Provides autonomous project execution with self-healing capabilities.
"""
from typing import Dict, Optional, Any, List
import ast
import os
import time
import logging
from ..planner import TaskPlanner, TaskStatus
from ..generators import (
    WebAppGenerator, AndroidAppGenerator, 
    IOSAppGenerator, DesktopAppGenerator, FlutterAppGenerator,
    StaticHTMLGenerator
)
from ..debugger import AutoDebugger, SelfHealer

logger = logging.getLogger(__name__)


# Keywords that indicate a simple static HTML request
SIMPLE_REQUEST_KEYWORDS = [
    "hello world", "basic page", "plain html", "just html",
    "one file", "single file", "minimal", "test page"
]

# Keywords that indicate a complex/advanced request that needs full planning
COMPLEX_REQUEST_KEYWORDS = [
    "react", "vue", "angular", "svelte", "next", "dashboard", "app",
    "application", "spa", "component", "redux", "state management",
    "authentication", "api", "backend", "database", "crud",
    # New keywords to prevent skipping planning for advanced requests
    "complex", "advanced", "futuristic", "modern", "professional",
    "premium", "stunning", "impressive", "animation", "interactive",
    "full", "complete", "multi-page", "sections", "portfolio",
    "e-commerce", "ecommerce", "store", "shop", "booking"
]


def _is_simple_request(description: str, project_type: str) -> bool:
    """Detect if this is a simple request that doesn't need a full framework"""
    desc_lower = description.lower()
    type_lower = project_type.lower()
    
    # Check for complex keywords first (they take priority)
    for kw in COMPLEX_REQUEST_KEYWORDS:
        if kw in desc_lower or kw in type_lower:
            return False  # Use full planning for complex requests
    
    # Check for simple keywords
    for kw in SIMPLE_REQUEST_KEYWORDS:
        if kw in desc_lower or kw in type_lower:
            return True
    
    # Default to full planning for better quality
    # Only truly simple requests like "html" type get fast mode
    if type_lower == "html" and len(description) < 50:
        return True
    
    return False  # Default to full planning for quality


class AutonomousExecutor:
    """Autonomous execution engine using ReAct loop with multi-model support.
    
    Supports separate AI providers for:
    - Planning (reasoning model like DeepSeek-R1)
    - Coding (code model like DeepSeek-Coder)
    """
    
    def __init__(self, ai_provider, output_dir: str = "./generated_projects",
                 planner_provider=None):
        """
        Initialize the executor.
        
        Args:
            ai_provider: Primary AI provider for code generation
            output_dir: Directory to output generated projects
            planner_provider: Optional separate provider for planning (uses ai_provider if not specified)
        """
        self.ai_provider = ai_provider  # Used for code generation
        self.planner_provider = planner_provider or ai_provider  # Used for planning
        self.output_dir = output_dir
        
        # Use planner_provider for planning tasks
        self.planner = TaskPlanner(self.planner_provider)
        
        # Use ai_provider for debugging/healing (code-focused)
        self.debugger = AutoDebugger(ai_provider)
        self.self_healer = SelfHealer(ai_provider, output_dir)
        self.on_log = None
        
        # Execution metrics
        self.healing_attempts = 0
        self.healed_errors = 0
        
        # Initialize tools
        from .tools import ToolRegistry
        from .tools import ToolRegistry
        self.tools = ToolRegistry(output_dir)
        
        # Initialize Core Modules (Cline Features)
        try:
            from ..modules.context_manager.context_injector import ContextInjector
            from ..modules.terminal_executor.exec_service import ExecService
            from ..modules.editor_integration.file_indexer import FileIndexer
            from ..modules.editor_integration.timeline_store import TimelineStore
            from ..modules.editor_integration.diff_presenter import DiffPresenter
            from ..modules.browser_automation.browser_driver import BrowserService
            from ..modules.mcp_tools.mcp_manager import MCPScaffold, MCPManager
            from ..modules.validator_monitor.linter_runner import LinterRunner, SecurityScanner
            from ..modules.telemetry.usage_tracker import UsageTracker, TaskReporter
            from ..modules.security.security_manager import SecretsDetector, PermissionPolicy
            from ..modules.approval_ui.approval_queue import ApprovalQueue, DiffUI
            
            # Context & IDE
            self.context_injector = ContextInjector(output_dir)
            self.file_indexer = FileIndexer(output_dir)
            self.timeline = TimelineStore(output_dir)
            self.diff_presenter = DiffPresenter()
            
            # Terminal & Browser
            self.exec_service = ExecService(output_dir)
            self.browser_service = BrowserService()
            
            # MCP Tools
            self.mcp_scaffold = MCPScaffold(output_dir)
            self.mcp_manager = MCPManager(output_dir)
            
            # Validation & Security
            self.linter = LinterRunner(output_dir)
            self.security_scanner = SecurityScanner(output_dir)
            self.secrets_detector = SecretsDetector()
            self.permission_policy = PermissionPolicy()
            
            # Telemetry
            self.usage_tracker = UsageTracker()
            self.task_reporter = TaskReporter(output_dir)
            
            # Approval UI
            self.approval_queue = ApprovalQueue()
            self.diff_ui = DiffUI()
            
            logger.info("All Cline modules initialized successfully")
        except ImportError as e:
            logger.warning(f"Could not load Cline modules: {e}")
            # Set all to None for graceful degradation
            self.context_injector = self.file_indexer = self.timeline = None
            self.diff_presenter = self.exec_service = self.browser_service = None
            self.mcp_scaffold = self.mcp_manager = self.linter = None
            self.security_scanner = self.secrets_detector = self.permission_policy = None
            self.usage_tracker = self.task_reporter = self.approval_queue = self.diff_ui = None
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
    def _log(self, message: str):
        print(message)
        if self.on_log:
            self.on_log(message)

    def execute_project(self, description: str, project_type: str, 
                       requirements: Optional[Dict] = None, generate_tests: bool = False,
                       validate_code: bool = False, on_log=None) -> Dict:
        """Execute a project autonomously"""
        self.on_log = on_log
        
        self._log("\n" + "="*60)
        self._log("ANTIGRAVITY AGENT - Starting Execution")
        self._log("="*60 + "\n")
        
        # === FAST PATH: Simple requests bypass planning entirely ===
        if _is_simple_request(description, project_type):
            return self._execute_simple_fast(description, project_type, requirements)
        
        # === NORMAL PATH: Full planning + execution ===
        # Phase 1: Planning
        self._log("📋 Phase 1: Planning...")
        try:
            tasks = self.planner.create_plan(description, project_type)
            self._log(f"✓ Plan created with {len(tasks)} tasks")
            self._log(self.planner.get_plan_summary())
        except Exception as e:
            return self._handle_error("Planning", str(e))
        
        # Phase 2: Execution (ReAct Loop)
        self._log("\n⚡ Phase 2: Autonomous Intent Execution...")
        
        # Initialize workspace (Scaffold if needed)
        self._initialize_workspace(project_type)
        
        max_iterations = 50 
        iteration = 0
        total_tasks = len(tasks)
        completed_tasks = 0
        
        while not self.planner.is_plan_complete() and iteration < max_iterations:
            iteration += 1
            task = self.planner.get_next_task()
            if not task:
                break
            
            # Broadcast progress update
            percentage = int((completed_tasks / total_tasks) * 100) if total_tasks > 0 else 0
            self._log(f"[PROGRESS:{percentage}] Executing Task {task.id}/{total_tasks}: {task.title}")
            
            self.planner.update_task_status(task.id, TaskStatus.IN_PROGRESS)
            
            try:
                # ReAct Loop for single task with self-healing
                success = self._execute_react_task_with_healing(task, description)
                
                if success:
                    self.planner.update_task_status(task.id, TaskStatus.COMPLETED)
                    completed_tasks += 1
                    percentage = int((completed_tasks / total_tasks) * 100) if total_tasks > 0 else 0
                    self._log(f"[PROGRESS:{percentage}] ✓ Task {task.id} completed ({completed_tasks}/{total_tasks})")
                else:
                    self.planner.update_task_status(task.id, TaskStatus.FAILED)
                    self._log(f"✗ Task {task.id} failed")
                    
            except Exception as e:
                # Attempt self-healing on failure
                self._log(f"⚠ Error executing task: {str(e)}")
                healed, result = self._attempt_healing(e, task)
                if healed:
                    self._log(f"🔧 Self-healed: {result}")
                    self.planner.update_task_status(task.id, TaskStatus.COMPLETED)
                    completed_tasks += 1
                else:
                    self.planner.update_task_status(task.id, TaskStatus.FAILED, error=str(e))
                    self._log(f"✗ Could not heal: {result}")
        
        # Final progress update
        final_progress = self.planner.get_progress()
        self._log(f"[PROGRESS:100] Completed {final_progress['completed']}/{final_progress['total']} tasks")
        
        # Phase 3: Finalization
        self._log("\n" + "="*60)
        self._log("EXECUTION COMPLETE")
        self._log("="*60)
        
        return {
            "success": self.planner.is_plan_complete(),
            "plan": [task.to_dict() for task in self.planner.tasks],
            "generation": {"output_dir": self.output_dir, "success": True},
            "progress": final_progress
        }
    
    def _execute_simple_fast(self, description: str, project_type: str, 
                             requirements: Optional[Dict] = None) -> Dict:
        """
        FAST PATH: Generate simple projects without planning or ReAct loops.
        Includes offline fallback if AI fails.
        """
        self._log("[PROGRESS:0] ⚡ FAST MODE: Simple project detected")
        self._log("[PROGRESS:10] Analyzing request...")
        
        start_time = time.time()
        
        try:
            self._log("[PROGRESS:30] Generating code with AI...")
            # Try AI-powered generation first
            generator = StaticHTMLGenerator(self.ai_provider, self.output_dir)
            result = generator.generate_project(description, requirements or {})
            
            elapsed = time.time() - start_time
            
            self._log(f"[PROGRESS:90] Writing files...")
            self._log(f"[PROGRESS:100] ✓ Generated {len(result.get('files', []))} file(s) in {elapsed:.1f}s")
            for f in result.get('files', []):
                self._log(f"  📄 {f}")
            
            self._log("\n" + "="*60)
            self._log("EXECUTION COMPLETE (FAST MODE)")
            self._log("="*60)
            
            return {
                "success": True,
                "fast_mode": True,
                "generation": result,
                "elapsed_seconds": elapsed,
                "plan": [],
                "progress": {"total": 1, "completed": 1, "percentage": 100}
            }
            
        except Exception as e:
            self._log(f"⚠ AI generation failed: {e}")
            self._log("🔄 Using offline template generation...")
            
            # Offline fallback - generate without AI
            return self._generate_offline_html(description, project_type)
    
    def _generate_offline_html(self, description: str, project_type: str) -> Dict:
        """Generate HTML offline without AI - parses description for customization"""
        from pathlib import Path
        
        self._log("[PROGRESS:20] Parsing request details...")
        
        # Parse description for customization
        desc_lower = description.lower()
        
        # Extract company/project name
        company_name = "My Project"
        for word in ["company", "for", "called", "named"]:
            if word in desc_lower:
                idx = desc_lower.find(word)
                after = description[idx:].split()
                if len(after) > 1:
                    company_name = after[-1].strip(".,!?")
                    break
        
        # Default to last capitalized word as company name
        words = description.split()
        for w in reversed(words):
            if w[0].isupper() and len(w) > 2:
                company_name = w.strip(".,!?")
                break
        
        self._log("[PROGRESS:40] Detecting theme and colors...")
        
        # Detect color theme
        primary_color = "#00ff88"  # Default neon green
        if "green" in desc_lower:
            primary_color = "#00ff88"
        elif "blue" in desc_lower:
            primary_color = "#00d4ff"
        elif "red" in desc_lower:
            primary_color = "#ff4444"
        elif "purple" in desc_lower:
            primary_color = "#aa66ff"
        elif "orange" in desc_lower:
            primary_color = "#ff8800"
        
        # Detect industry
        is_car = any(w in desc_lower for w in ["car", "ev", "electric", "vehicle", "auto"])
        is_tech = any(w in desc_lower for w in ["tech", "app", "software", "ai", "startup"])
        
        self._log("[PROGRESS:60] Generating HTML template...")
        
        # Generate appropriate HTML
        if is_car:
            html = self._generate_ev_html(company_name, primary_color, description)
        else:
            html = self._generate_modern_html(company_name, primary_color, description)
        
        self._log("[PROGRESS:80] Writing files...")
        
        # Write file
        output_path = Path(self.output_dir) / "index.html"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html)
        
        self._log(f"[PROGRESS:100] ✓ Generated index.html (offline mode)")
        self._log("\n" + "="*60)
        self._log("EXECUTION COMPLETE (OFFLINE MODE)")
        self._log("="*60)
        
        return {
            "success": True,
            "fast_mode": True,
            "offline_mode": True,
            "generation": {"files": ["index.html"], "output_dir": self.output_dir},
            "plan": [],
            "progress": {"total": 1, "completed": 1, "percentage": 100}
        }
    
    def _generate_ev_html(self, company: str, color: str, description: str) -> str:
        """Generate electric car company HTML"""
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{company} - Electric Vehicles</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: #0a0a0a;
            color: #fff;
            overflow-x: hidden;
        }}
        .hero {{
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #0a0a0a 100%);
            position: relative;
        }}
        .hero::before {{
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(circle at 50% 50%, {color}15, transparent 60%);
        }}
        nav {{
            position: fixed;
            top: 0;
            width: 100%;
            padding: 1.5rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
            background: rgba(10,10,10,0.8);
            backdrop-filter: blur(10px);
        }}
        .logo {{
            font-size: 1.5rem;
            font-weight: 700;
            color: {color};
            text-shadow: 0 0 20px {color}50;
        }}
        .nav-links {{ display: flex; gap: 2rem; }}
        .nav-links a {{
            color: #888;
            text-decoration: none;
            transition: color 0.3s;
        }}
        .nav-links a:hover {{ color: {color}; }}
        h1 {{
            font-size: clamp(3rem, 8vw, 6rem);
            font-weight: 800;
            margin-bottom: 1rem;
            background: linear-gradient(90deg, {color}, #fff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
            z-index: 1;
        }}
        .tagline {{
            font-size: 1.5rem;
            color: #888;
            margin-bottom: 3rem;
            position: relative;
            z-index: 1;
        }}
        .cta-btn {{
            padding: 1rem 3rem;
            font-size: 1.1rem;
            font-weight: 600;
            border: 2px solid {color};
            background: transparent;
            color: {color};
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
            z-index: 1;
        }}
        .cta-btn:hover {{
            background: {color};
            color: #0a0a0a;
            box-shadow: 0 0 40px {color}60;
            transform: scale(1.05);
        }}
        .features {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            padding: 5rem 10%;
            background: #111;
        }}
        .feature {{
            padding: 2rem;
            border-radius: 20px;
            background: linear-gradient(145deg, #1a1a1a, #0d0d0d);
            border: 1px solid #222;
            transition: transform 0.3s, border-color 0.3s;
        }}
        .feature:hover {{
            transform: translateY(-10px);
            border-color: {color}40;
        }}
        .feature-icon {{
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }}
        .feature h3 {{
            color: {color};
            margin-bottom: 0.5rem;
        }}
        .feature p {{ color: #888; line-height: 1.6; }}
        .stats {{
            display: flex;
            justify-content: center;
            gap: 4rem;
            padding: 4rem 5%;
            background: #0a0a0a;
            flex-wrap: wrap;
        }}
        .stat {{ text-align: center; }}
        .stat-value {{
            font-size: 3rem;
            font-weight: 800;
            color: {color};
        }}
        .stat-label {{ color: #666; margin-top: 0.5rem; }}
        footer {{
            text-align: center;
            padding: 3rem;
            background: #050505;
            color: #444;
        }}
    </style>
</head>
<body>
    <nav>
        <div class="logo">⚡ {company}</div>
        <div class="nav-links">
            <a href="#models">Models</a>
            <a href="#features">Features</a>
            <a href="#about">About</a>
            <a href="#contact">Contact</a>
        </div>
    </nav>
    
    <section class="hero">
        <h1>{company}</h1>
        <p class="tagline">The Future of Electric Mobility</p>
        <button class="cta-btn">Explore Models →</button>
    </section>
    
    <section class="features" id="features">
        <div class="feature">
            <div class="feature-icon">🔋</div>
            <h3>Long Range</h3>
            <p>Up to 500+ miles on a single charge with our advanced battery technology.</p>
        </div>
        <div class="feature">
            <div class="feature-icon">⚡</div>
            <h3>Fast Charging</h3>
            <p>0-80% in just 20 minutes with our supercharger network.</p>
        </div>
        <div class="feature">
            <div class="feature-icon">🚀</div>
            <h3>Performance</h3>
            <p>0-60 mph in under 3 seconds with instant electric torque.</p>
        </div>
        <div class="feature">
            <div class="feature-icon">🌍</div>
            <h3>Sustainable</h3>
            <p>Zero emissions driving with eco-friendly materials throughout.</p>
        </div>
    </section>
    
    <section class="stats">
        <div class="stat">
            <div class="stat-value">500+</div>
            <div class="stat-label">Miles Range</div>
        </div>
        <div class="stat">
            <div class="stat-value">2.9s</div>
            <div class="stat-label">0-60 mph</div>
        </div>
        <div class="stat">
            <div class="stat-value">20min</div>
            <div class="stat-label">Fast Charge</div>
        </div>
        <div class="stat">
            <div class="stat-value">0</div>
            <div class="stat-label">Emissions</div>
        </div>
    </section>
    
    <footer>
        <p>&copy; 2024 {company}. Driving the electric revolution.</p>
    </footer>
</body>
</html>'''
    
    def _generate_modern_html(self, company: str, color: str, description: str) -> str:
        """Generate impressive futuristic HTML - high quality offline fallback"""
        
        # Extract key features from description
        desc_lower = description.lower()
        
        # Determine features based on description
        features = []
        if any(w in desc_lower for w in ['ai', 'artificial', 'machine', 'smart']):
            features = [("AI-Powered", "Advanced machine learning algorithms deliver intelligent automation."),
                       ("Real-Time Analytics", "Monitor and analyze data instantly with live dashboards."),
                       ("Seamless Integration", "Connect with your existing tools effortlessly.")]
        elif any(w in desc_lower for w in ['fast', 'speed', 'performance', 'quick']):
            features = [("Lightning Fast", "Optimized for maximum speed and efficiency."),
                       ("Zero Downtime", "99.99% uptime guarantee for reliability."),
                       ("Global CDN", "Content delivered from servers worldwide.")]
        else:
            features = [("Innovation First", "Cutting-edge technology driving tomorrow's solutions."),
                       ("Enterprise Ready", "Scalable infrastructure for any size organization."),
                       ("24/7 Support", "Our team is always here when you need assistance.")]
        
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{company} - Innovation Redefined</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {{
            --primary: {color};
            --primary-glow: {color}40;
            --bg-dark: #050510;
            --bg-card: #0d0d1a;
            --text-main: #ffffff;
            --text-muted: #8888aa;
        }}
        
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        
        html {{ scroll-behavior: smooth; }}
        
        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-dark);
            color: var(--text-main);
            line-height: 1.6;
            overflow-x: hidden;
        }}
        
        /* Animated gradient background */
        .bg-gradient {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: 
                radial-gradient(ellipse at 20% 50%, var(--primary-glow) 0%, transparent 50%),
                radial-gradient(ellipse at 80% 20%, {color}20 0%, transparent 40%),
                radial-gradient(ellipse at 50% 100%, #1a1a3a 0%, transparent 50%);
            z-index: -1;
            animation: gradientShift 15s ease infinite alternate;
        }}
        
        @keyframes gradientShift {{
            0% {{ opacity: 0.8; transform: scale(1); }}
            100% {{ opacity: 1; transform: scale(1.05); }}
        }}
        
        /* Navigation */
        nav {{
            position: fixed;
            top: 0;
            width: 100%;
            padding: 1.5rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 100;
            backdrop-filter: blur(10px);
            background: rgba(5, 5, 16, 0.7);
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }}
        
        .logo {{
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), #fff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: -0.5px;
        }}
        
        .nav-links {{
            display: flex;
            gap: 2rem;
        }}
        
        .nav-links a {{
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.3s;
        }}
        
        .nav-links a:hover {{ color: var(--primary); }}
        
        /* Hero Section */
        .hero {{
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 8rem 2rem 4rem;
            position: relative;
        }}
        
        .hero-badge {{
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: var(--primary-glow);
            border: 1px solid var(--primary);
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--primary);
            margin-bottom: 2rem;
            animation: pulse 2s ease-in-out infinite;
        }}
        
        @keyframes pulse {{
            0%, 100% {{ box-shadow: 0 0 0 0 var(--primary-glow); }}
            50% {{ box-shadow: 0 0 20px 5px var(--primary-glow); }}
        }}
        
        h1 {{
            font-size: clamp(3rem, 10vw, 6rem);
            font-weight: 900;
            line-height: 1.1;
            margin-bottom: 1.5rem;
            background: linear-gradient(135deg, #fff 0%, var(--primary) 50%, #fff 100%);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
        }}
        
        @keyframes shimmer {{
            0% {{ background-position: 0% center; }}
            100% {{ background-position: 200% center; }}
        }}
        
        .hero-subtitle {{
            font-size: 1.25rem;
            color: var(--text-muted);
            max-width: 600px;
            margin-bottom: 3rem;
        }}
        
        .hero-buttons {{
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
            justify-content: center;
        }}
        
        .btn {{
            padding: 1rem 2.5rem;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }}
        
        .btn-primary {{
            background: var(--primary);
            color: var(--bg-dark);
            border: none;
        }}
        
        .btn-primary:hover {{
            transform: translateY(-3px);
            box-shadow: 0 10px 40px var(--primary-glow);
        }}
        
        .btn-secondary {{
            background: transparent;
            color: var(--text-main);
            border: 2px solid rgba(255,255,255,0.2);
        }}
        
        .btn-secondary:hover {{
            border-color: var(--primary);
            color: var(--primary);
        }}
        
        /* Features Section */
        .features {{
            padding: 6rem 5%;
        }}
        
        .section-title {{
            font-size: 2.5rem;
            font-weight: 800;
            text-align: center;
            margin-bottom: 4rem;
        }}
        
        .features-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }}
        
        .feature-card {{
            background: var(--bg-card);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 2.5rem;
            transition: all 0.3s ease;
        }}
        
        .feature-card:hover {{
            transform: translateY(-10px);
            border-color: var(--primary);
            box-shadow: 0 20px 40px rgba(0,0,0,0.3), 0 0 30px var(--primary-glow);
        }}
        
        .feature-icon {{
            width: 60px;
            height: 60px;
            border-radius: 15px;
            background: linear-gradient(135deg, var(--primary), var(--primary-glow));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
        }}
        
        .feature-card h3 {{
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }}
        
        .feature-card p {{
            color: var(--text-muted);
            font-size: 1rem;
        }}
        
        /* Stats Section */
        .stats {{
            padding: 4rem 5%;
            background: linear-gradient(180deg, transparent, rgba(0,0,0,0.5));
        }}
        
        .stats-grid {{
            display: flex;
            justify-content: center;
            gap: 4rem;
            flex-wrap: wrap;
            max-width: 1000px;
            margin: 0 auto;
        }}
        
        .stat-item {{
            text-align: center;
        }}
        
        .stat-value {{
            font-size: 3.5rem;
            font-weight: 900;
            background: linear-gradient(135deg, var(--primary), #fff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        
        .stat-label {{
            color: var(--text-muted);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-top: 0.5rem;
        }}
        
        /* CTA Section */
        .cta {{
            padding: 8rem 5%;
            text-align: center;
        }}
        
        .cta h2 {{
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
        }}
        
        .cta p {{
            color: var(--text-muted);
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto 2rem;
        }}
        
        /* Footer */
        footer {{
            padding: 4rem 5%;
            border-top: 1px solid rgba(255,255,255,0.05);
            text-align: center;
        }}
        
        footer p {{
            color: var(--text-muted);
            font-size: 0.9rem;
        }}
        
        /* Responsive */
        @media (max-width: 768px) {{
            .nav-links {{ display: none; }}
            h1 {{ font-size: 2.5rem; }}
            .stats-grid {{ gap: 2rem; }}
            .stat-value {{ font-size: 2.5rem; }}
        }}
    </style>
</head>
<body>
    <div class="bg-gradient"></div>
    
    <nav>
        <div class="logo">{company}</div>
        <div class="nav-links">
            <a href="#features">Features</a>
            <a href="#stats">About</a>
            <a href="#cta">Contact</a>
        </div>
    </nav>
    
    <section class="hero">
        <div class="hero-badge">✨ Welcome to the Future</div>
        <h1>{company}</h1>
        <p class="hero-subtitle">{description}</p>
        <div class="hero-buttons">
            <a href="#cta" class="btn btn-primary">Get Started</a>
            <a href="#features" class="btn btn-secondary">Learn More</a>
        </div>
    </section>
    
    <section class="features" id="features">
        <h2 class="section-title">Why Choose Us</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">🚀</div>
                <h3>{features[0][0]}</h3>
                <p>{features[0][1]}</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⚡</div>
                <h3>{features[1][0]}</h3>
                <p>{features[1][1]}</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>{features[2][0]}</h3>
                <p>{features[2][1]}</p>
            </div>
        </div>
    </section>
    
    <section class="stats" id="stats">
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-value">10K+</div>
                <div class="stat-label">Users</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">99.9%</div>
                <div class="stat-label">Uptime</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">24/7</div>
                <div class="stat-label">Support</div>
            </div>
            <div class="stat-item">
                <div class="stat-value">50+</div>
                <div class="stat-label">Countries</div>
            </div>
        </div>
    </section>
    
    <section class="cta" id="cta">
        <h2>Ready to Transform Your Business?</h2>
        <p>Join thousands of companies already using {company} to power their future.</p>
        <a href="#" class="btn btn-primary">Start Free Trial</a>
    </section>
    
    <footer>
        <p>&copy; 2024 {company}. All rights reserved. Built with innovation.</p>
    </footer>
</body>
</html>'''

    def _initialize_workspace(self, project_type: str):
        """Setup initial workspace state"""
        js_like = any(
            kw in project_type.lower()
            for kw in ["web", "react", "vue", "angular", "svelte", "next", "electron"]
        )
        if js_like and not os.path.exists(os.path.join(self.output_dir, "package.json")):
            self.tools.run_command("npm init -y")

    def _execute_react_task(self, task, project_context: str) -> bool:
        """Execute a task using ReAct (Reason, Act, Observe) loop - OPTIMIZED"""
        
        # Inject Context (Cline Feature)
        injected_context = ""
        if hasattr(self, 'context_injector') and self.context_injector:
            # Parse task description and project context for @file markers
            ctx_result = self.context_injector.parse_and_inject(task.description + "\n" + project_context)
            injected_context = ctx_result["processed_prompt"]
        else:
            injected_context = f"Task: {task.description}\nContext: {project_context}"

        system_prompt = f"""You are an expert Senior Software Engineer and UI/UX Designer.
Your goal is to produce **World-Class, Production-Ready Code** that impresses the user.

TOOLS AVAILABLE:
{self.tools.get_tool_definitions()}
- search_files(query): Search file contents
- start_process(cmd): Run background process

CURRENT TASK: "{task.title}"
DETAILS: {injected_context}

GUIDELINES:
1. **Quality Over Speed**: Do not take shortcuts. Write complete, robust code.
2. **Modern Standards**: Use modern best practices (e.g. Semantic HTML, CSS Grid/Flexbox, ES6+).
3. **Visual Excellence**: For UI tasks, ensure the design is beautiful, responsive, and polished.
4. **Error Handling**: Include proper error checking and edge case handling.

FILE CREATION:
To write files, use the XML format (preferred for robustness):
<file path="filename.ext">
[Full file content here]
</file>

OR use `write_file("filename.ext", "content")`

EXECUTION:
- Think step-by-step
- Verify your work
- Call `finish()` only when the task is truly complete and verified
"""

        history = []
        max_steps = 10  # Increased for better quality output
        
        for i in range(max_steps):
            # Construct prompt
            prompt = "\n".join(history) + "\nYour turn:\nThought:"
            
            # Generate
            response = self.ai_provider.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                stop=["Observation:"]
            )
            
            # Parse Thought and Action
            # Expected format: "Thought: ... \nAction: <tool_code>...</tool_code>"
            if "Thought:" not in response:
                response = "Thought: " + response
                
            self._log(f"🤖 {response}")
            history.append(response)
            
            # Extract tool usage
            tool_code = self._extract_tool_code(response)
            
            if not tool_code:
                # Agent just thought, didn't act. 
                # If it says "finish", we are done.
                if "finish()" in response or "finished" in response.lower():
                    return True
                continue
                
            if "finish()" in tool_code:
                return True
                
            # Execute tool
            observation = self._execute_tool_code(tool_code)
            self._log(f"👀 Observation: {observation[:200]}..." if len(observation) > 200 else f"👀 Observation: {observation}")
            
            history.append(f"Observation: {observation}")
            
        # If we hit max steps, consider it done (task likely completed)
        return True
    
    def _execute_react_task_with_healing(self, task, project_context: str) -> bool:
        """Execute task with self-healing wrapper - retries on failure"""
        max_attempts = 3
        last_error = None
        
        for attempt in range(max_attempts):
            try:
                return self._execute_react_task(task, project_context)
            except Exception as e:
                last_error = e
                self.healing_attempts += 1
                logger.info(f"Task execution failed (attempt {attempt + 1}/{max_attempts}): {e}")
                
                if attempt < max_attempts - 1:
                    # Try to heal
                    healed, result = self._attempt_healing(e, task)
                    if healed:
                        self.healed_errors += 1
                        self._log(f"🔧 Self-healed on attempt {attempt + 1}: {result}")
                        continue  # Retry the task
        
        # All attempts failed
        if last_error:
            raise last_error
        return False
    
    def _attempt_healing(self, error: Exception, task=None) -> tuple:
        """
        Attempt to heal an error using the SelfHealer.
        
        Args:
            error: The exception that occurred
            task: Optional task context
            
        Returns:
            Tuple of (healed: bool, result: str)
        """
        context = {
            "output_dir": self.output_dir,
            "task": task.to_dict() if task and hasattr(task, 'to_dict') else str(task)
        }
        
        try:
            success, result = self.self_healer.heal(error, context)
            if success:
                self.healed_errors += 1
            return success, result
        except Exception as he:
            logger.warning(f"Healing attempt failed: {he}")
            return False, str(he)
    
    def get_healing_stats(self) -> Dict[str, Any]:
        """Get statistics about self-healing operations"""
        return {
            "healing_attempts": self.healing_attempts,
            "healed_errors": self.healed_errors,
            "success_rate": self.healed_errors / max(1, self.healing_attempts),
            "healer_summary": self.self_healer.get_healing_summary()
        }
    
    def _execute_fallback(self, description: str, project_type: str, 
                          requirements: Optional[Dict] = None) -> Dict:
        """
        Fallback when fast mode fails - creates minimal working output.
        """
        from pathlib import Path
        
        self._log("Using fallback generation...")
        
        # Create a basic HTML file directly
        html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{description[:50]}</title>
</head>
<body>
    <h1>Hello World</h1>
    <p>{description}</p>
</body>
</html>"""
        
        output_path = Path(self.output_dir) / "index.html"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(html_content)
        
        self._log(f"✓ Created fallback: {output_path}")
        
        return {
            "success": True,
            "fallback": True,
            "generation": {"files": ["index.html"]},
            "plan": []
        }

    def _extract_tool_code(self, text: str) -> Optional[str]:
        """
        Extract tool code from response. Supports multiple formats:
        1. <tool_code>...</tool_code> (Original)
        2. <file path="...">...</file> (Cline-style artifact)
        3. ```python\nwrite_file(...)``` (Markdown block)
        4. Action: function(...) (ReAct standard)
        """
        text = text.strip()
        
        # 1. Check for explicit <tool_code> tags
        if "<tool_code>" in text and "</tool_code>" in text:
            start = text.find("<tool_code>") + 11
            end = text.find("</tool_code>", start)
            return text[start:end].strip()
            
        # 2. Check for Cline-style <file path="..."> tags
        # This converts XML file writing to a write_file() tool call
        import re
        file_match = re.search(r'<file\s+path=["\']([^"\']+)["\']>(.*?)</file>', text, re.DOTALL)
        if file_match:
            path = file_match.group(1)
            content = file_match.group(2)
            # Escape content for Python string
            safe_content = content.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
            return f'write_file("{path}", "{safe_content}")'
            
        # 3. Check for Markdown code blocks containing write_file
        code_block = re.search(r'```(?:python)?\s*(.*?)```', text, re.DOTALL)
        if code_block:
            code = code_block.group(1).strip()
            if code.startswith("write_file") or code.startswith("run_command"):
                return code

        # 4. Check for "Action: function()" pattern
        action_match = re.search(r'Action:\s*([a-zA-Z_]\w*\(.*\))', text)
        if action_match:
             return action_match.group(1)
             
        # 5. Last resort: if the text starts with a function call
        if re.match(r'^[a-zA-Z_]\w*\(.*\)', text):
            return text
            
        return None

    def _execute_tool_code(self, code: str) -> str:
        """Safe execution of tool code"""
        try:
            # Create a safe local scope
            local_scope = {
                "read_file": self.tools.read_file,
                "write_file": self.tools.write_file,
                "list_dir": self.tools.list_dir,
                "run_command": self.tools.run_command,
                "search_files": lambda q: self.file_indexer.search_content(q) if getattr(self, 'file_indexer', None) else "Indexer not available",
                "start_process": lambda c: self.exec_service.run_command(c, background=True) if getattr(self, 'exec_service', None) else "Exec service not available",
                "finish": lambda: "Task Completed"
            }
            
            parsed = ast.parse(code, mode="eval")
            if not isinstance(parsed.body, ast.Call) or not isinstance(parsed.body.func, ast.Name):
                raise ValueError("Tool invocations must be simple function calls like run_command(\"ls\")")

            func_name = parsed.body.func.id
            if func_name not in local_scope:
                raise ValueError(f"Tool '{func_name}' not allowed")

            args = []
            for arg in parsed.body.args:
                if isinstance(arg, ast.Constant):
                    args.append(arg.value)
                else:
                    raise ValueError("Only literal arguments are supported")

            kwargs = {}
            for kw in parsed.body.keywords:
                if not isinstance(kw.value, ast.Constant):
                    raise ValueError("Only literal keyword arguments are supported")
                kwargs[kw.arg] = kw.value.value

            return str(local_scope[func_name](*args, **kwargs))
            
        except Exception as e:
            return f"Tool Execution Error: {str(e)}"
    
    def _handle_error(self, phase: str, error: str) -> Dict:
        """Handle execution errors"""
        self._log(f"\n✗ Error in {phase} phase: {error}")
        
        return {
            "success": False,
            "phase": phase,
            "error": error,
            "plan": [],
            "progress": {"total": 0, "completed": 0, "percentage": 0}
        }
    
    def _validate_code(self, project_type: str, project_dir: str) -> Dict:
        """Validate generated code"""
        from ..validation import create_validator
        
        try:
            validator = create_validator(project_type, project_dir)
            result = validator.validate()
            
            # Display validation results
            if result.errors:
                print(f"   Errors found:")
                for error in result.errors[:5]:  # Show first 5 errors
                    print(f"   - {error}")
            
            if result.warnings:
                print(f"   Warnings:")
                for warning in result.warnings[:3]:  # Show first 3 warnings
                    print(f"   - {warning}")
            
            return result.to_dict()
            
        except Exception as e:
            print(f"   Validation error: {str(e)}")
            return {
                "passed": False,
                "errors": [str(e)],
                "warnings": [],
                "suggestions": [],
                "error_count": 1,
                "warning_count": 0
            }
