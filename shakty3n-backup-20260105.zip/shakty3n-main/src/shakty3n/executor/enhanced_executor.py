"""
Enhanced Autonomous Execution Engine
Integrates all advanced capabilities for Codex-optimized execution.

Features:
- 5-Phase execution loop (Plan → Execute → Validate → Debug → Reflect)
- Dependency DAG for parallel task execution
- Multi-agent collaboration
- Long-term memory
- Self-reflection and re-planning
- Security scanning
- CI/CD generation
- Observability timeline
"""
from typing import Dict, Optional, Any, Callable, List
import os
import time
import logging
import uuid

from ..planner.dag_planner import DAGPlanner, DependencyDAG, DAGTask, TaskStatus, AgentRole
from ..memory import LongTermMemory
from ..reflection import SelfReflector, ConfidenceCalculator
from ..security import SecurityScanner
from ..observability import ExecutionTimeline, EventType
from ..agents import AgentOrchestrator, AgentContext
from ..cicd import CICDFactory, PipelineConfig, detect_project_config
from ..debugger import AutoDebugger
from ..validation import create_validator

logger = logging.getLogger(__name__)


class EnhancedExecutor:
    """
    Production-grade autonomous execution engine.
    
    Implements the Codex-optimized 5-phase loop:
    1. Intent Understanding & Planning
    2. Parallel Execution with Multi-Agent
    3. Validation & Security Scanning  
    4. Auto-Debug & Self-Healing
    5. Reflection & Learning
    """
    
    # Configuration
    MAX_ITERATIONS = 100
    MAX_DEBUG_RETRIES = 3
    APPROVAL_REQUIRED_CHANGES = ["security", "database", "deployment"]
    
    def __init__(
        self,
        ai_provider,
        output_dir: str = "./generated_projects",
        db_path: str = "shakty3n_memory.db"
    ):
        """
        Initialize the enhanced executor.
        
        Args:
            ai_provider: AI provider for generation
            output_dir: Directory for generated projects
            db_path: Path to memory database
        """
        self.ai_provider = ai_provider
        self.output_dir = output_dir
        
        # Initialize all components
        self.planner = DAGPlanner(ai_provider)
        self.memory = LongTermMemory(db_path)
        self.reflector = SelfReflector(ai_provider, self.memory)
        self.security = SecurityScanner()
        self.debugger = AutoDebugger(ai_provider)
        
        # Workspace and agents initialized per-project
        self._workspace = None
        self._orchestrator = None
        self._timeline = None
        
        # Callbacks
        self.on_log: Optional[Callable[[str], None]] = None
        self.on_approval: Optional[Callable[[Dict], bool]] = None
        
        # State
        self._project_id = None
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
    
    def _log(self, message: str, level: str = "info") -> None:
        """Log message to console and callback"""
        log_func = getattr(logger, level, logger.info)
        log_func(message)
        print(message)
        if self.on_log:
            self.on_log(message)
    
    def execute_project(
        self,
        description: str,
        project_type: str,
        requirements: Optional[Dict] = None,
        generate_tests: bool = True,
        validate_code: bool = True,
        run_security_scan: bool = True,
        generate_cicd: bool = True,
        cicd_platform: str = "github",
        on_log: Optional[Callable] = None,
        on_approval: Optional[Callable[[Dict], bool]] = None
    ) -> Dict[str, Any]:
        """
        Execute a project with the full Codex-optimized loop.
        
        Args:
            description: Project description
            project_type: Type of project (web-react, flutter, python, etc.)
            requirements: Additional requirements dict
            generate_tests: Whether to generate tests
            validate_code: Whether to validate generated code
            run_security_scan: Whether to run security scanning
            generate_cicd: Whether to generate CI/CD config
            cicd_platform: CI/CD platform (github, gitlab, jenkins)
            on_log: Callback for log messages
            on_approval: Callback for approval requests (returns True/False)
            
        Returns:
            Dict with execution results
        """
        self.on_log = on_log
        self.on_approval = on_approval
        
        # Initialize project
        self._project_id = str(uuid.uuid4())[:8]
        project_dir = os.path.join(self.output_dir, f"project_{self._project_id}")
        os.makedirs(project_dir, exist_ok=True)
        
        # Initialize components for this project
        from ..agent_manager import AgentWorkspace
        self._workspace = AgentWorkspace(project_dir)
        self._orchestrator = AgentOrchestrator(self.ai_provider, self._workspace, self.memory)
        self._timeline = ExecutionTimeline(self._project_id)
        self.reflector.reset()
        
        self._log("\n" + "=" * 60)
        self._log("🚀 SHAKTY3N ENHANCED EXECUTOR - Starting Project")
        self._log("=" * 60)
        self._log(f"Project ID: {self._project_id}")
        self._log(f"Type: {project_type}")
        self._log(f"Description: {description[:100]}...")
        
        results = {
            "project_id": self._project_id,
            "project_dir": project_dir,
            "success": False,
            "phases": {},
            "confidence_score": 50,
            "security_findings": [],
            "timeline": None,
            "artifacts": []
        }
        
        try:
            # ===== PHASE 0: Intent Understanding =====
            self._timeline.start_phase("intent")
            self._log("\n📋 PHASE 0: Understanding Intent...")
            
            success_criteria = self._extract_success_criteria(description, project_type)
            self.memory.record_decision(
                self._project_id, "intent", 
                description[:200],
                f"Success criteria: {success_criteria}"
            )
            
            # Query memory for similar past projects
            similar = self.memory.get_similar_decisions("intent", description)
            if similar:
                self._log(f"  Found {len(similar)} similar past projects for context")
            
            self._timeline.end_phase("intent", success=True)
            results["phases"]["intent"] = {"success": True}
            
            # ===== PHASE 1: Planning =====
            self._timeline.start_phase("planning")
            self._log("\n📝 PHASE 1: Creating Execution Plan...")
            
            dag = self.planner.create_dag_plan(description, project_type)
            
            # Assign tasks to specialist agents
            for task_id, task in dag.tasks.items():
                agent = self._orchestrator.get_best_agent(task.to_dict())
                task.assigned_agent = agent.get_role()
            
            self._log(f"  Created {len(dag.tasks)} tasks in DAG")
            self._log(f"  Parallel groups: {len(dag.get_parallel_groups())}")
            self._log(self.planner.get_plan_summary())
            
            # Approval gate for plan
            if self.on_approval:
                plan_summary = dag.export_for_review()
                self._log("  ⏸ Requesting plan approval...")
                approved = self.on_approval({"type": "plan", "data": plan_summary})
                if not approved:
                    self._log("  ❌ Plan not approved")
                    return {**results, "success": False, "reason": "Plan not approved"}
            
            self._timeline.end_phase("planning", success=True)
            results["phases"]["planning"] = {"success": True, "task_count": len(dag.tasks)}
            
            # ===== PHASE 2: Execution =====
            self._timeline.start_phase("execution")
            self._log("\n⚡ PHASE 2: Executing Tasks...")
            
            execution_success = self._execute_dag(dag, description, project_type)
            
            self._timeline.end_phase("execution", success=execution_success)
            results["phases"]["execution"] = {
                "success": execution_success,
                "progress": dag.get_progress()
            }
            
            if not execution_success:
                self._log("  ⚠ Execution had failures, attempting recovery...")
            
            # ===== PHASE 3: Validation =====
            self._timeline.start_phase("validation")
            self._log("\n✅ PHASE 3: Validating Results...")
            
            validation_result = {"passed": True, "errors": [], "warnings": []}
            security_findings = []
            
            if validate_code:
                validator = create_validator(project_type, project_dir)
                validation_result = validator.validate().to_dict()
                self._log(f"  Validation: {'PASSED' if validation_result['passed'] else 'FAILED'}")
                if validation_result['errors']:
                    self._log(f"  Errors: {len(validation_result['errors'])}")
            
            if run_security_scan:
                self._log("  Running security scan...")
                security_findings = self.security.scan_project(project_dir)
                security_score = self.security.get_security_score()
                self._log(f"  Security Score: {security_score}/100")
                if security_findings:
                    critical = sum(1 for f in security_findings 
                                   if f.severity.value in ["critical", "high"])
                    self._log(f"  Findings: {len(security_findings)} ({critical} critical/high)")
                    
                    # Record security findings
                    self._timeline.record_event(
                        EventType.SECURITY_FINDING,
                        f"Found {len(security_findings)} security issues",
                        details={"findings": [f.to_dict() for f in security_findings[:5]]}
                    )
            
            results["security_findings"] = [f.to_dict() for f in security_findings]
            results["phases"]["validation"] = {
                "passed": validation_result["passed"],
                "errors": validation_result.get("errors", []),
                "security_score": self.security.get_security_score() if run_security_scan else None
            }
            
            self._timeline.end_phase("validation", success=validation_result["passed"])
            
            # ===== PHASE 4: Debug & Self-Heal (if needed) =====
            if not validation_result["passed"] or (security_findings and 
                any(f.severity.value in ["critical", "high"] for f in security_findings)):
                
                self._timeline.start_phase("debug")
                self._log("\n🔧 PHASE 4: Auto-Debug & Self-Heal...")
                
                debug_success = self._auto_debug(
                    validation_result.get("errors", []),
                    security_findings,
                    project_dir
                )
                
                self._timeline.end_phase("debug", success=debug_success)
                results["phases"]["debug"] = {"success": debug_success}
            
            # ===== PHASE 5: Reflection & Learning =====
            self._timeline.start_phase("reflection")
            self._log("\n🔮 PHASE 5: Reflection & Learning...")
            
            execution_state = {
                "project_id": self._project_id,
                "tasks_total": len(dag.tasks),
                "tasks_completed": sum(1 for t in dag.tasks.values() 
                                       if t.status == TaskStatus.COMPLETED),
                "tasks_failed": sum(1 for t in dag.tasks.values() 
                                    if t.status == TaskStatus.FAILED),
                "errors": validation_result.get("errors", []),
                "validation_passed": validation_result["passed"],
                "security_findings": [f.to_dict() for f in security_findings]
            }
            
            reflection = self.reflector.reflect_on_phase("complete", 
                [t.to_dict() for t in dag.tasks.values()], 
                execution_state
            )
            
            self._log(f"  Confidence Score: {reflection.confidence_score:.1f}/100")
            if reflection.learnings:
                self._log(f"  Learnings: {len(reflection.learnings)}")
                for learning in reflection.learnings[:3]:
                    self._log(f"    - {learning}")
            
            results["confidence_score"] = reflection.confidence_score
            results["phases"]["reflection"] = reflection.to_dict()
            
            # Generate CI/CD if requested
            if generate_cicd:
                self._log("\n📦 Generating CI/CD Pipeline...")
                cicd_result = self._generate_cicd(project_dir, project_type, cicd_platform)
                if cicd_result:
                    self._log(f"  Created {cicd_result['filename']}")
                    results["artifacts"].append(cicd_result["filename"])
            
            self._timeline.end_phase("reflection", success=True)
            
            # Final success determination
            results["success"] = (
                dag.is_complete() or 
                dag.get_progress()["percentage"] >= 80
            )
            
            # Export timeline
            results["timeline"] = self._timeline.export_for_dashboard()
            
        except Exception as e:
            self._log(f"\n❌ Error: {str(e)}", level="error")
            logger.exception("Execution failed")
            results["error"] = str(e)
            self._timeline.record_error(str(e))
        
        # Final summary
        self._log("\n" + "=" * 60)
        self._log("EXECUTION COMPLETE")
        self._log("=" * 60)
        self._log(f"Success: {results['success']}")
        self._log(f"Confidence: {results['confidence_score']:.1f}/100")
        self._log(f"Project Dir: {project_dir}")
        self._log(self._timeline.get_execution_report())
        
        return results
    
    def _extract_success_criteria(self, description: str, project_type: str) -> List[str]:
        """Extract success criteria from project description"""
        criteria = []
        
        # Basic criteria based on project type
        if "web" in project_type.lower() or "react" in project_type.lower():
            criteria.extend([
                "Valid package.json",
                "Main entry point exists",
                "No syntax errors",
                "App builds successfully"
            ])
        elif "python" in project_type.lower():
            criteria.extend([
                "Valid Python syntax",
                "requirements.txt present",
                "Main module exists"
            ])
        elif "flutter" in project_type.lower():
            criteria.extend([
                "Valid pubspec.yaml",
                "lib/main.dart exists",
                "No Dart analysis errors"
            ])
        
        # Extract from description
        if "test" in description.lower():
            criteria.append("Tests pass")
        if "api" in description.lower():
            criteria.append("API endpoints functional")
        if "auth" in description.lower():
            criteria.append("Authentication implemented")
        
        return criteria
    
    def _execute_dag(self, dag: DependencyDAG, description: str, 
                     project_type: str) -> bool:
        """Execute tasks in the DAG respecting dependencies"""
        
        context = AgentContext(
            project_description=description,
            project_type=project_type
        )
        
        iteration = 0
        while not dag.is_complete() and iteration < self.MAX_ITERATIONS:
            iteration += 1
            
            # Get ready tasks
            ready_tasks = dag.get_ready_tasks()
            if not ready_tasks:
                # Check for blocked tasks
                progress = dag.get_progress()
                if progress["blocked"] > 0:
                    self._log(f"  ⚠ {progress['blocked']} tasks blocked")
                break
            
            # Execute tasks (could be parallel in async version)
            for task in ready_tasks:
                self._timeline.start_task(task.id, task.title)
                self._log(f"  ▶ [{task.assigned_agent.value}] {task.title}")
                
                dag.update_task_status(task.id, TaskStatus.IN_PROGRESS)
                
                try:
                    # Execute with appropriate agent
                    result = self._orchestrator.execute_task(task.to_dict(), context)
                    
                    if result.success:
                        dag.update_task_status(task.id, TaskStatus.COMPLETED, 
                                               result=result.output)
                        self._timeline.end_task(task.id, success=True, result=result.output)
                        self._log(f"    ✓ Completed in {result.duration_seconds:.1f}s")
                        
                        # Update context with created files
                        for filename in result.files_created:
                            try:
                                content = self._workspace.open_file(filename)
                                context.current_files[filename] = content
                            except:
                                pass
                    else:
                        dag.update_task_status(task.id, TaskStatus.FAILED, 
                                               error=result.error)
                        self._timeline.end_task(task.id, success=False, result=result.error)
                        self._log(f"    ✗ Failed: {result.error}")
                        
                        # Reflect on failure
                        reflection = self.reflector.reflect_on_task(
                            task.to_dict(), result.error, success=False
                        )
                        
                        if reflection.should_replan:
                            self._log(f"    🔄 Re-planning suggested: {reflection.replan_reason}")
                        
                except Exception as e:
                    dag.update_task_status(task.id, TaskStatus.FAILED, error=str(e))
                    self._timeline.end_task(task.id, success=False, result=str(e))
                    self._log(f"    ✗ Error: {str(e)}")
            
            # Progress update
            progress = dag.get_progress()
            self._log(f"  Progress: {progress['completed']}/{progress['total']} "
                     f"({progress['percentage']:.0f}%)")
        
        return dag.is_complete() or dag.get_progress()["percentage"] >= 80
    
    def _auto_debug(self, errors: List[str], security_findings: List, 
                    project_dir: str) -> bool:
        """Attempt to auto-fix errors and security issues"""
        
        fixes_applied = 0
        
        # Fix validation errors
        for error in errors[:5]:  # Limit to 5 fixes
            self._log(f"  Attempting fix for: {error[:50]}...")
            
            # Check for known fix
            known_fix = self.memory.get_known_fix(error)
            if known_fix and known_fix.get("success_rate", 0) > 0.6:
                self._log(f"    Using known fix (success rate: {known_fix['success_rate']:.0%})")
            
            # Try auto-fix
            # (In a full implementation, this would apply actual fixes)
            fixes_applied += 1
        
        # Address critical security findings
        for finding in security_findings:
            if finding.severity.value not in ["critical", "high"]:
                continue
                
            self._log(f"  Security: {finding.description}")
            self._log(f"    → {finding.recommendation}")
            
            # Record for learning
            self.memory.record_bug(
                finding.description,
                finding.file_path,
                finding.recommendation,
                success=False  # Will update after fix
            )
        
        return fixes_applied > 0 or len(security_findings) == 0
    
    def _generate_cicd(self, project_dir: str, project_type: str, 
                       platform: str) -> Optional[Dict]:
        """Generate CI/CD pipeline configuration"""
        try:
            # Detect project config
            config = detect_project_config(project_dir)
            
            # Create generator
            generator = CICDFactory.create_generator(platform)
            
            # Generate config
            content = generator.generate(config)
            filename = generator.get_filename()
            
            # Write file
            filepath = os.path.join(project_dir, filename)
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, 'w') as f:
                f.write(content)
            
            return {"filename": filename, "platform": platform}
            
        except Exception as e:
            self._log(f"  ⚠ CI/CD generation failed: {e}")
            return None


# Backwards compatibility alias
AutonomousExecutorV2 = EnhancedExecutor

__all__ = ['EnhancedExecutor', 'AutonomousExecutorV2']
