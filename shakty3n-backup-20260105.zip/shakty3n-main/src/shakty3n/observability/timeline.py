"""
Observability Module - Execution Timeline and Metrics
Tracks execution events, calculates metrics, and provides dashboard data.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum
import time
import json
import logging

logger = logging.getLogger(__name__)


class EventType(Enum):
    """Types of execution events"""
    PHASE_START = "phase_start"
    PHASE_END = "phase_end"
    TASK_START = "task_start"
    TASK_END = "task_end"
    TASK_FAILED = "task_failed"
    ERROR = "error"
    WARNING = "warning"
    DECISION = "decision"
    APPROVAL_REQUEST = "approval_request"
    APPROVAL_RESPONSE = "approval_response"
    REFLECTION = "reflection"
    REPLAN = "replan"
    TOOL_CALL = "tool_call"
    AI_GENERATION = "ai_generation"
    SECURITY_FINDING = "security_finding"
    VALIDATION = "validation"
    CHECKPOINT = "checkpoint"


@dataclass
class TimelineEvent:
    """A single event in the execution timeline"""
    timestamp: float
    event_type: EventType
    phase: str
    task_id: Optional[str] = None
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    duration_ms: Optional[float] = None
    confidence_delta: float = 0.0  # How this event affected confidence
    
    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "event_type": self.event_type.value,
            "phase": self.phase,
            "task_id": self.task_id,
            "message": self.message,
            "details": self.details,
            "duration_ms": self.duration_ms,
            "confidence_delta": self.confidence_delta,
            "relative_time_ms": None  # Set by timeline
        }


@dataclass
class PhaseMetrics:
    """Metrics for a single phase"""
    phase: str
    start_time: float
    end_time: Optional[float] = None
    tasks_total: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    @property
    def duration_seconds(self) -> Optional[float]:
        if self.end_time and self.start_time:
            return self.end_time - self.start_time
        return None
    
    @property
    def success_rate(self) -> float:
        if self.tasks_total == 0:
            return 1.0
        return self.tasks_completed / self.tasks_total
    
    def to_dict(self) -> Dict:
        return {
            "phase": self.phase,
            "duration_seconds": self.duration_seconds,
            "tasks_total": self.tasks_total,
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "success_rate": self.success_rate,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings)
        }


class ExecutionTimeline:
    """
    Comprehensive execution timeline with metrics tracking.
    
    Features:
    - Event recording and querying
    - Phase-level metrics
    - Confidence tracking over time
    - Dashboard export
    """
    
    def __init__(self, project_id: str = ""):
        self.project_id = project_id
        self.events: List[TimelineEvent] = []
        self.start_time: float = time.time()
        self.current_confidence: float = 50.0
        self.confidence_history: List[tuple] = [(0, 50.0)]  # (relative_time, confidence)
        
        # Phase tracking
        self.phases: Dict[str, PhaseMetrics] = {}
        self.current_phase: Optional[str] = None
        
        # Task timing
        self._task_start_times: Dict[str, float] = {}
    
    def record_event(
        self,
        event_type: EventType,
        message: str = "",
        phase: Optional[str] = None,
        task_id: Optional[str] = None,
        details: Optional[Dict] = None,
        confidence_delta: float = 0.0
    ) -> TimelineEvent:
        """
        Record an execution event.
        
        Args:
            event_type: Type of event
            message: Human-readable description
            phase: Current phase (uses current_phase if not provided)
            task_id: Associated task ID
            details: Additional event details
            confidence_delta: Change to confidence score
            
        Returns:
            The recorded TimelineEvent
        """
        now = time.time()
        
        # Use current phase if not specified
        if phase is None:
            phase = self.current_phase or "unknown"
        
        # Calculate duration for task/phase end events
        duration_ms = None
        if event_type == EventType.TASK_END and task_id in self._task_start_times:
            duration_ms = (now - self._task_start_times[task_id]) * 1000
            del self._task_start_times[task_id]
        elif event_type == EventType.TASK_START and task_id:
            self._task_start_times[task_id] = now
        
        event = TimelineEvent(
            timestamp=now,
            event_type=event_type,
            phase=phase,
            task_id=task_id,
            message=message,
            details=details or {},
            duration_ms=duration_ms,
            confidence_delta=confidence_delta
        )
        
        self.events.append(event)
        
        # Update confidence
        if confidence_delta != 0:
            self.current_confidence = max(0, min(100, self.current_confidence + confidence_delta))
            relative_time = now - self.start_time
            self.confidence_history.append((relative_time, self.current_confidence))
        
        # Update phase metrics
        self._update_phase_metrics(event)
        
        logger.debug(f"Timeline: [{event_type.value}] {message}")
        
        return event
    
    def _update_phase_metrics(self, event: TimelineEvent) -> None:
        """Update phase metrics based on event"""
        phase = event.phase
        
        if phase not in self.phases:
            self.phases[phase] = PhaseMetrics(
                phase=phase,
                start_time=event.timestamp
            )
        
        metrics = self.phases[phase]
        
        if event.event_type == EventType.PHASE_START:
            self.current_phase = phase
            metrics.start_time = event.timestamp
        elif event.event_type == EventType.PHASE_END:
            metrics.end_time = event.timestamp
        elif event.event_type == EventType.TASK_START:
            metrics.tasks_total += 1
        elif event.event_type == EventType.TASK_END:
            metrics.tasks_completed += 1
        elif event.event_type == EventType.TASK_FAILED:
            metrics.tasks_failed += 1
        elif event.event_type == EventType.ERROR:
            metrics.errors.append(event.message)
        elif event.event_type == EventType.WARNING:
            metrics.warnings.append(event.message)
    
    def start_phase(self, phase: str) -> None:
        """Mark the start of a phase"""
        self.record_event(
            EventType.PHASE_START,
            f"Starting {phase} phase",
            phase=phase
        )
    
    def end_phase(self, phase: str, success: bool = True) -> None:
        """Mark the end of a phase"""
        delta = 5 if success else -10
        self.record_event(
            EventType.PHASE_END,
            f"Completed {phase} phase (success={success})",
            phase=phase,
            confidence_delta=delta
        )
    
    def start_task(self, task_id: str, task_title: str) -> None:
        """Mark the start of a task"""
        self.record_event(
            EventType.TASK_START,
            f"Starting: {task_title}",
            task_id=task_id
        )
    
    def end_task(self, task_id: str, success: bool, result: Any = None) -> None:
        """Mark the end of a task"""
        event_type = EventType.TASK_END if success else EventType.TASK_FAILED
        delta = 3 if success else -5
        self.record_event(
            event_type,
            f"Task {'completed' if success else 'failed'}: {task_id}",
            task_id=task_id,
            details={"result": str(result)[:200] if result else None},
            confidence_delta=delta
        )
    
    def record_error(self, message: str, details: Optional[Dict] = None) -> None:
        """Record an error event"""
        self.record_event(
            EventType.ERROR,
            message,
            details=details,
            confidence_delta=-8
        )
    
    def record_warning(self, message: str, details: Optional[Dict] = None) -> None:
        """Record a warning event"""
        self.record_event(
            EventType.WARNING,
            message,
            details=details,
            confidence_delta=-2
        )
    
    def get_phase_duration(self, phase: str) -> Optional[float]:
        """Get duration of a phase in seconds"""
        metrics = self.phases.get(phase)
        return metrics.duration_seconds if metrics else None
    
    def get_current_confidence(self) -> float:
        """Get current confidence score"""
        return self.current_confidence
    
    def get_total_duration(self) -> float:
        """Get total execution duration in seconds"""
        return time.time() - self.start_time
    
    def get_events_by_type(self, event_type: EventType) -> List[TimelineEvent]:
        """Get all events of a specific type"""
        return [e for e in self.events if e.event_type == event_type]
    
    def get_events_by_task(self, task_id: str) -> List[TimelineEvent]:
        """Get all events for a specific task"""
        return [e for e in self.events if e.task_id == task_id]
    
    def get_timeline_summary(self) -> Dict[str, Any]:
        """Get a summary of the execution timeline"""
        total_tasks = sum(p.tasks_total for p in self.phases.values())
        completed_tasks = sum(p.tasks_completed for p in self.phases.values())
        failed_tasks = sum(p.tasks_failed for p in self.phases.values())
        
        return {
            "project_id": self.project_id,
            "total_duration_seconds": self.get_total_duration(),
            "current_confidence": self.current_confidence,
            "total_events": len(self.events),
            "phases": {name: metrics.to_dict() for name, metrics in self.phases.items()},
            "tasks": {
                "total": total_tasks,
                "completed": completed_tasks,
                "failed": failed_tasks,
                "success_rate": completed_tasks / total_tasks if total_tasks > 0 else 1.0
            },
            "errors": sum(len(p.errors) for p in self.phases.values()),
            "warnings": sum(len(p.warnings) for p in self.phases.values())
        }
    
    def export_for_dashboard(self) -> Dict[str, Any]:
        """
        Export timeline data for dashboard visualization.
        
        Returns a structure optimized for frontend rendering.
        """
        # Add relative timestamps
        events_export = []
        for event in self.events:
            event_dict = event.to_dict()
            event_dict["relative_time_ms"] = (event.timestamp - self.start_time) * 1000
            events_export.append(event_dict)
        
        return {
            "summary": self.get_timeline_summary(),
            "events": events_export,
            "confidence_history": [
                {"time_seconds": t, "confidence": c}
                for t, c in self.confidence_history
            ],
            "phases": [
                {
                    "name": name,
                    "start_time_relative": (metrics.start_time - self.start_time) * 1000,
                    "end_time_relative": (metrics.end_time - self.start_time) * 1000 if metrics.end_time else None,
                    **metrics.to_dict()
                }
                for name, metrics in self.phases.items()
            ]
        }
    
    def export_to_json(self) -> str:
        """Export timeline as JSON string"""
        return json.dumps(self.export_for_dashboard(), indent=2)
    
    def get_execution_report(self) -> str:
        """Generate a human-readable execution report"""
        summary = self.get_timeline_summary()
        
        lines = [
            "=" * 60,
            "EXECUTION TIMELINE REPORT",
            "=" * 60,
            "",
            f"Total Duration: {summary['total_duration_seconds']:.1f}s",
            f"Confidence Score: {summary['current_confidence']:.1f}/100",
            f"Total Events: {summary['total_events']}",
            "",
            "PHASES:",
        ]
        
        for phase_name, phase_data in summary["phases"].items():
            status = "✓" if phase_data["success_rate"] >= 0.8 else "⚠" if phase_data["success_rate"] >= 0.5 else "✗"
            duration = phase_data["duration_seconds"]
            duration_str = f"{duration:.1f}s" if duration else "ongoing"
            lines.append(f"  [{status}] {phase_name}: {duration_str}")
            lines.append(f"      Tasks: {phase_data['tasks_completed']}/{phase_data['tasks_total']} completed")
            if phase_data["error_count"] > 0:
                lines.append(f"      Errors: {phase_data['error_count']}")
        
        lines.append("")
        lines.append("TASK SUMMARY:")
        lines.append(f"  Completed: {summary['tasks']['completed']}/{summary['tasks']['total']}")
        lines.append(f"  Failed: {summary['tasks']['failed']}")
        lines.append(f"  Success Rate: {summary['tasks']['success_rate']:.0%}")
        
        if summary["errors"] > 0:
            lines.append("")
            lines.append(f"⚠ Total Errors: {summary['errors']}")
        
        lines.append("")
        lines.append("=" * 60)
        
        return "\n".join(lines)


__all__ = ['ExecutionTimeline', 'TimelineEvent', 'EventType', 'PhaseMetrics']
