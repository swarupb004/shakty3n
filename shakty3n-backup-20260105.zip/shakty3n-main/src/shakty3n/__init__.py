"""
Shakty3n - Autonomous Agentic Coder (Enhanced Edition)

Production-grade agentic coder with:
- 5-phase Codex-optimized execution loop
- Dependency DAG for parallel task execution
- Multi-agent collaboration (Architect, Backend, Frontend, QA, Security, DevOps)
- Long-term memory for learning from experience
- Self-reflection and re-planning
- Security scanning (OWASP, secrets, CVE)
- CI/CD pipeline generation
- Full observability with execution timeline
"""

__version__ = "2.0.0"
__author__ = "Shakty3n Team"
__description__ = "Production-grade Autonomous Agentic Coder"

# Core AI Providers
from .ai_providers import AIProviderFactory

# Planning
from .planner import TaskPlanner, Task, TaskStatus
from .planner import DAGPlanner, DependencyDAG, DAGTask

# Code Generators
from .generators import (
    CodeGenerator,
    WebAppGenerator,
    AndroidAppGenerator,
    IOSAppGenerator,
    DesktopAppGenerator,
    FlutterAppGenerator
)

# Execution
from .debugger import AutoDebugger
from .executor import AutonomousExecutor, EnhancedExecutor

# Agent Management
from .agent_manager import AgentManager, AgentWorkspace, AgentSession

# Utilities
from .utils import Config, VirtualEnvManager, load_env_vars

# New Advanced Modules
from .memory import LongTermMemory
from .reflection import SelfReflector, ConfidenceCalculator
from .security import SecurityScanner, Severity
from .observability import ExecutionTimeline, EventType
from .agents import AgentOrchestrator, AgentContext
from .cicd import CICDFactory, PipelineConfig

__all__ = [
    # Version info
    '__version__',
    
    # AI Providers
    'AIProviderFactory',
    
    # Planning
    'TaskPlanner', 'Task', 'TaskStatus',
    'DAGPlanner', 'DependencyDAG', 'DAGTask',
    
    # Generators
    'CodeGenerator',
    'WebAppGenerator',
    'AndroidAppGenerator',
    'IOSAppGenerator',
    'DesktopAppGenerator',
    'FlutterAppGenerator',
    
    # Debugging
    'AutoDebugger',
    
    # Execution
    'AutonomousExecutor',
    'EnhancedExecutor',  # New production-grade executor
    
    # Configuration
    'Config',
    'VirtualEnvManager',
    'load_env_vars',
    
    # Agent Management
    'AgentManager',
    'AgentWorkspace',
    'AgentSession',
    
    # Advanced Features (v2.0)
    'LongTermMemory',
    'SelfReflector',
    'ConfidenceCalculator',
    'SecurityScanner',
    'Severity',
    'ExecutionTimeline',
    'EventType',
    'AgentOrchestrator',
    'AgentContext',
    'CICDFactory',
    'PipelineConfig',
]
