"""
Ollama Local Model Provider Implementation
"""
from typing import List, Optional
import requests
import logging
from .base import AIProvider

logger = logging.getLogger(__name__)


class OllamaProvider(AIProvider):
    """Ollama local model provider"""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "llama2", 
                 base_url: Optional[str] = None):
        super().__init__(api_key, model)
        import os
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.model = model
    
    def is_available(self) -> bool:
        """Check if Ollama service is running and accessible."""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Ollama not available: {e}")
            return False
    
    def ensure_model_loaded(self) -> bool:
        """Ensure the model is loaded and ready for inference."""
        try:
            # Quick ping to load model if not already loaded
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={"model": self.model, "prompt": "hi", "stream": False},
                timeout=30
            )
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Could not preload model {self.model}: {e}")
            return False
    
    def generate(self, prompt: str, system_prompt: Optional[str] = None,
                 temperature: float = 0.7, max_tokens: int = 2000,
                 stop: Optional[List[str]] = None) -> str:
        """Generate response using Ollama API with optimized settings for M4 Mac"""
        import os
        
        # Get timeout from environment - default 45 minutes for large models on M4
        timeout = int(os.getenv("OLLAMA_TIMEOUT", "2700"))  # 45 minutes (tripled)
        
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n{prompt}"
        
        # Retry with same model (no auto-switching to smaller models)
        max_retries = 3  # Increased retries
        last_error = None
        
        for attempt in range(max_retries):
            try:
                current_timeout = timeout if attempt == 0 else timeout // 2
                logger.info(f"Ollama request attempt {attempt + 1}/{max_retries} with {self.model} (timeout: {current_timeout}s)")
                
                # Optimized options for M4 Mac with 16GB
                # - Reduced context window for faster inference
                # - num_gpu layers set to use Metal acceleration
                # - num_thread optimized for M4 efficiency cores
                response = requests.post(
                    f"{self.base_url}/api/generate",
                    json={
                        "model": self.model,
                        "prompt": full_prompt,
                        "temperature": temperature,
                        "stream": False,
                        "stop": stop or None,
                        "options": {
                            "num_predict": min(max_tokens, 2000),  # Reduced for speed
                            "num_ctx": 4096,  # Reduced context for faster inference
                            "num_gpu": 999,  # Use all available GPU layers (Metal)
                            "num_thread": 4,  # Optimized for M4
                            "low_vram": False,  # M4 has unified memory
                        }
                    },
                    timeout=current_timeout
                )
                response.raise_for_status()
                result = response.json().get("response", "")
                if result:
                    logger.info(f"Ollama generation successful with {self.model}")
                    return result
                    
            except requests.exceptions.Timeout:
                last_error = f"Timeout after {current_timeout}s"
                logger.warning(f"{self.model}: {last_error} (attempt {attempt + 1})")
                # Don't reduce timeout for next attempt, just continue
                continue
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Ollama error: {last_error}")
                continue
        
        # Respect user's model choice - don't silently switch to smaller model
        raise Exception(f"Model '{self.model}' failed after {max_retries} attempts. Last error: {last_error}")
    
    def stream_generate(self, prompt: str, system_prompt: Optional[str] = None,
                        temperature: float = 0.7, max_tokens: int = 2000):
        """Stream generate response using Ollama API"""
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"{system_prompt}\n\n{prompt}"
        
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": full_prompt,
                    "temperature": temperature,
                    "stream": True,
                    "options": {
                        "num_predict": min(max_tokens, 2000),
                        "num_ctx": 4096,
                    }
                },
                stream=True,
                timeout=300
            )
            response.raise_for_status()
            
            for line in response.iter_lines():
                if line:
                    import json
                    data = json.loads(line)
                    if "response" in data:
                        yield data["response"]
        except Exception as e:
            raise Exception(f"Ollama API error: {str(e)}")
    
    def get_available_models(self) -> List[str]:
        """Get available Ollama models"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            response.raise_for_status()
            models = response.json().get("models", [])
            return [model["name"] for model in models]
        except Exception as e:
            logger.warning("Ollama API error while fetching models: %s", e)
            return [
                "deepseek-r1:14b",
                "deepseek-coder:6.7b",
                "codestral:22b",
                "llama3.1:latest",
                "gemma3:1b",
                "deepseek-r1:8b",
            ]

