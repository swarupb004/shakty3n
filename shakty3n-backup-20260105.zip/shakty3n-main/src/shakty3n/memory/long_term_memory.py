"""
Long-Term Memory System
Stores project decisions, bug patterns, and user preferences across sessions.
"""
import sqlite3
import json
import hashlib
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


@dataclass
class Decision:
    """A recorded project decision"""
    id: int
    project_id: str
    decision_type: str
    decision: str
    reasoning: str
    outcome: Optional[str]
    created_at: float
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "project_id": self.project_id,
            "decision_type": self.decision_type,
            "decision": self.decision,
            "reasoning": self.reasoning,
            "outcome": self.outcome,
            "created_at": self.created_at
        }


@dataclass
class BugPattern:
    """A learned bug pattern with fix strategy"""
    id: int
    error_signature: str
    context_hash: str
    fix_strategy: str
    success_rate: float
    occurrences: int
    last_seen: float
    
    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "error_signature": self.error_signature,
            "fix_strategy": self.fix_strategy,
            "success_rate": self.success_rate,
            "occurrences": self.occurrences
        }


@dataclass
class Preference:
    """A user or project preference"""
    key: str
    value: str
    inferred_from: str
    confidence: float
    
    def to_dict(self) -> Dict:
        return {
            "key": self.key,
            "value": self.value,
            "confidence": self.confidence
        }


class LongTermMemory:
    """
    Persistent memory system for the autonomous agent.
    
    Stores:
    - Project decisions (architecture choices, library selections, patterns)
    - Bug patterns (error signatures and successful fix strategies)
    - User preferences (coding style, preferred tools, conventions)
    """
    
    def __init__(self, db_path: str = "shakty3n_memory.db"):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self) -> None:
        """Initialize database schema"""
        with sqlite3.connect(self.db_path) as conn:
            # Project decisions table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS project_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id TEXT NOT NULL,
                    decision_type TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    reasoning TEXT,
                    outcome TEXT,
                    created_at REAL DEFAULT (strftime('%s', 'now')),
                    updated_at REAL
                )
            """)
            
            # Bug patterns table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS bug_patterns (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    error_signature TEXT NOT NULL,
                    context_hash TEXT,
                    fix_strategy TEXT NOT NULL,
                    success_count INTEGER DEFAULT 0,
                    failure_count INTEGER DEFAULT 0,
                    occurrences INTEGER DEFAULT 1,
                    last_seen REAL DEFAULT (strftime('%s', 'now')),
                    UNIQUE(error_signature, context_hash)
                )
            """)
            
            # User preferences table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS user_preferences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    preference_key TEXT NOT NULL UNIQUE,
                    preference_value TEXT,
                    inferred_from TEXT,
                    confidence REAL DEFAULT 0.5,
                    updated_at REAL DEFAULT (strftime('%s', 'now'))
                )
            """)
            
            # Execution history for reflection
            conn.execute("""
                CREATE TABLE IF NOT EXISTS execution_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id TEXT NOT NULL,
                    phase TEXT NOT NULL,
                    task_id TEXT,
                    action TEXT NOT NULL,
                    result TEXT,
                    success INTEGER,
                    duration_seconds REAL,
                    created_at REAL DEFAULT (strftime('%s', 'now'))
                )
            """)
            
            # Indexes
            conn.execute("CREATE INDEX IF NOT EXISTS idx_decisions_project ON project_decisions(project_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_decisions_type ON project_decisions(decision_type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_bugs_signature ON bug_patterns(error_signature)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_exec_project ON execution_history(project_id)")
            
            conn.commit()
    
    # ==================== Decision Methods ====================
    
    def record_decision(self, project_id: str, decision_type: str, 
                        decision: str, reasoning: str = "") -> int:
        """
        Record a project decision.
        
        Args:
            project_id: Project identifier
            decision_type: Type of decision (architecture, library, pattern, config)
            decision: The decision made
            reasoning: Why this decision was made
            
        Returns:
            Decision ID
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO project_decisions 
                (project_id, decision_type, decision, reasoning)
                VALUES (?, ?, ?, ?)
                """,
                (project_id, decision_type, decision, reasoning)
            )
            conn.commit()
            return cursor.lastrowid
    
    def update_decision_outcome(self, decision_id: int, outcome: str) -> None:
        """Update the outcome of a decision (success, partial, failed)"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                UPDATE project_decisions 
                SET outcome = ?, updated_at = strftime('%s', 'now')
                WHERE id = ?
                """,
                (outcome, decision_id)
            )
            conn.commit()
    
    def get_project_decisions(self, project_id: str) -> List[Decision]:
        """Get all decisions for a project"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                """
                SELECT * FROM project_decisions 
                WHERE project_id = ?
                ORDER BY created_at DESC
                """,
                (project_id,)
            )
            rows = cursor.fetchall()
            return [
                Decision(
                    id=row["id"],
                    project_id=row["project_id"],
                    decision_type=row["decision_type"],
                    decision=row["decision"],
                    reasoning=row["reasoning"],
                    outcome=row["outcome"],
                    created_at=row["created_at"]
                )
                for row in rows
            ]
    
    def get_similar_decisions(self, decision_type: str, context: str, 
                               limit: int = 5) -> List[Decision]:
        """
        Find similar past decisions for context-aware suggestions.
        Uses simple keyword matching for now.
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            # Get decisions of the same type that were successful
            cursor = conn.execute(
                """
                SELECT * FROM project_decisions 
                WHERE decision_type = ? AND outcome = 'success'
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (decision_type, limit * 3)  # Get more to filter
            )
            rows = cursor.fetchall()
            
            # Simple relevance scoring
            context_words = set(context.lower().split())
            scored = []
            for row in rows:
                decision_words = set(row["decision"].lower().split())
                overlap = len(context_words & decision_words)
                if overlap > 0:
                    scored.append((overlap, row))
            
            # Sort by relevance and take top N
            scored.sort(key=lambda x: -x[0])
            return [
                Decision(
                    id=row["id"],
                    project_id=row["project_id"],
                    decision_type=row["decision_type"],
                    decision=row["decision"],
                    reasoning=row["reasoning"],
                    outcome=row["outcome"],
                    created_at=row["created_at"]
                )
                for _, row in scored[:limit]
            ]
    
    # ==================== Bug Pattern Methods ====================
    
    def _normalize_error(self, error: str) -> str:
        """Normalize error message to a signature"""
        # Remove line numbers, file paths, variable values
        import re
        normalized = error.lower()
        # Remove specific line numbers
        normalized = re.sub(r'line \d+', 'line N', normalized)
        # Remove file paths
        normalized = re.sub(r'/[^\s]+/', '/', normalized)
        # Remove quoted values
        normalized = re.sub(r"'[^']*'", "'X'", normalized)
        normalized = re.sub(r'"[^"]*"', '"X"', normalized)
        return normalized[:500]  # Truncate
    
    def _hash_context(self, context: str) -> str:
        """Create a hash of the code context"""
        return hashlib.md5(context.encode()).hexdigest()[:16]
    
    def record_bug(self, error: str, context: str, fix_strategy: str, 
                   success: bool) -> None:
        """
        Record a bug pattern and its fix.
        
        Args:
            error: The error message
            context: The code context where error occurred
            fix_strategy: How the bug was fixed
            success: Whether the fix worked
        """
        error_sig = self._normalize_error(error)
        context_hash = self._hash_context(context) if context else ""
        
        with sqlite3.connect(self.db_path) as conn:
            # Try to update existing pattern
            cursor = conn.execute(
                """
                SELECT id, success_count, failure_count, occurrences 
                FROM bug_patterns 
                WHERE error_signature = ? AND context_hash = ?
                """,
                (error_sig, context_hash)
            )
            row = cursor.fetchone()
            
            if row:
                # Update existing
                pattern_id, success_count, failure_count, occurrences = row
                if success:
                    success_count += 1
                else:
                    failure_count += 1
                
                conn.execute(
                    """
                    UPDATE bug_patterns 
                    SET success_count = ?, failure_count = ?, 
                        occurrences = ?, fix_strategy = ?,
                        last_seen = strftime('%s', 'now')
                    WHERE id = ?
                    """,
                    (success_count, failure_count, occurrences + 1, 
                     fix_strategy if success else None, pattern_id)
                )
            else:
                # Insert new pattern
                conn.execute(
                    """
                    INSERT INTO bug_patterns 
                    (error_signature, context_hash, fix_strategy, 
                     success_count, failure_count)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (error_sig, context_hash, fix_strategy,
                     1 if success else 0, 0 if success else 1)
                )
            
            conn.commit()
    
    def get_known_fix(self, error: str, context: str = "") -> Optional[Dict]:
        """
        Look up a known fix for an error.
        
        Returns:
            Dict with fix_strategy and success_rate, or None if unknown
        """
        error_sig = self._normalize_error(error)
        context_hash = self._hash_context(context) if context else ""
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            
            # Try exact match first
            cursor = conn.execute(
                """
                SELECT * FROM bug_patterns 
                WHERE error_signature = ? AND context_hash = ?
                """,
                (error_sig, context_hash)
            )
            row = cursor.fetchone()
            
            if not row:
                # Try just error signature
                cursor = conn.execute(
                    """
                    SELECT * FROM bug_patterns 
                    WHERE error_signature = ?
                    ORDER BY (success_count * 1.0 / (success_count + failure_count + 1)) DESC
                    LIMIT 1
                    """,
                    (error_sig,)
                )
                row = cursor.fetchone()
            
            if row:
                total = row["success_count"] + row["failure_count"]
                success_rate = row["success_count"] / total if total > 0 else 0
                return {
                    "fix_strategy": row["fix_strategy"],
                    "success_rate": success_rate,
                    "occurrences": row["occurrences"]
                }
            
            return None
    
    def get_bug_statistics(self) -> Dict[str, Any]:
        """Get overall bug pattern statistics"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                SELECT 
                    COUNT(*) as total_patterns,
                    SUM(occurrences) as total_occurrences,
                    AVG(success_count * 1.0 / (success_count + failure_count + 1)) as avg_success_rate
                FROM bug_patterns
                """
            )
            row = cursor.fetchone()
            return {
                "total_patterns": row[0] or 0,
                "total_occurrences": row[1] or 0,
                "avg_success_rate": row[2] or 0
            }
    
    # ==================== Preference Methods ====================
    
    def infer_preference(self, key: str, value: str, source: str, 
                         confidence: float = 0.5) -> None:
        """
        Record or update a user preference.
        
        Args:
            key: Preference key (e.g., "code_style", "test_framework")
            value: Preference value
            source: How this preference was inferred
            confidence: Confidence level (0-1)
        """
        with sqlite3.connect(self.db_path) as conn:
            # Check if exists
            cursor = conn.execute(
                "SELECT confidence FROM user_preferences WHERE preference_key = ?",
                (key,)
            )
            row = cursor.fetchone()
            
            if row:
                existing_confidence = row[0]
                # Only update if new confidence is higher
                if confidence > existing_confidence:
                    conn.execute(
                        """
                        UPDATE user_preferences 
                        SET preference_value = ?, inferred_from = ?, 
                            confidence = ?, updated_at = strftime('%s', 'now')
                        WHERE preference_key = ?
                        """,
                        (value, source, confidence, key)
                    )
            else:
                conn.execute(
                    """
                    INSERT INTO user_preferences 
                    (preference_key, preference_value, inferred_from, confidence)
                    VALUES (?, ?, ?, ?)
                    """,
                    (key, value, source, confidence)
                )
            
            conn.commit()
    
    def get_preference(self, key: str, default: str = None) -> Optional[str]:
        """Get a preference value"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT preference_value FROM user_preferences WHERE preference_key = ?",
                (key,)
            )
            row = cursor.fetchone()
            return row[0] if row else default
    
    def get_all_preferences(self) -> Dict[str, str]:
        """Get all preferences as a dictionary"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "SELECT preference_key, preference_value FROM user_preferences"
            )
            return {row[0]: row[1] for row in cursor.fetchall()}
    
    # ==================== Execution History Methods ====================
    
    def record_execution(self, project_id: str, phase: str, task_id: str,
                         action: str, result: str, success: bool,
                         duration: float) -> int:
        """Record an execution step for later reflection"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                """
                INSERT INTO execution_history 
                (project_id, phase, task_id, action, result, success, duration_seconds)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (project_id, phase, task_id, action, result, 1 if success else 0, duration)
            )
            conn.commit()
            return cursor.lastrowid
    
    def get_execution_history(self, project_id: str, limit: int = 100) -> List[Dict]:
        """Get execution history for a project"""
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                """
                SELECT * FROM execution_history 
                WHERE project_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (project_id, limit)
            )
            return [dict(row) for row in cursor.fetchall()]
    
    def get_context_for_prompt(self, project_id: str, max_tokens: int = 2000) -> str:
        """
        Get relevant context from memory for including in AI prompts.
        
        Returns:
            Formatted string with relevant decisions, patterns, and preferences
        """
        parts = []
        
        # Recent decisions
        decisions = self.get_project_decisions(project_id)
        if decisions:
            parts.append("Previous decisions:")
            for d in decisions[:5]:
                parts.append(f"- {d.decision_type}: {d.decision}")
        
        # Preferences
        prefs = self.get_all_preferences()
        if prefs:
            parts.append("\nUser preferences:")
            for k, v in list(prefs.items())[:10]:
                parts.append(f"- {k}: {v}")
        
        # Bug patterns summary
        stats = self.get_bug_statistics()
        if stats["total_patterns"] > 0:
            parts.append(f"\nLearned from {stats['total_patterns']} bug patterns "
                        f"(avg fix success: {stats['avg_success_rate']:.0%})")
        
        context = "\n".join(parts)
        
        # Truncate if too long
        if len(context) > max_tokens * 4:  # Rough char estimate
            context = context[:max_tokens * 4] + "..."
        
        return context


__all__ = ['LongTermMemory', 'Decision', 'BugPattern', 'Preference']
