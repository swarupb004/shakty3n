"""
Autonomous Task Planner
"""
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from enum import Enum
import json
import logging

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class Task:
    """Represents a single task in the plan"""
    id: int
    title: str
    description: str
    dependencies: List[int] = field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    subtasks: List['Task'] = field(default_factory=list)
    result: Optional[str] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """Convert task to dictionary"""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "dependencies": self.dependencies,
            "status": self.status.value,
            "subtasks": [st.to_dict() for st in self.subtasks],
            "result": self.result,
            "error": self.error
        }


class TaskPlanner:
    """Autonomous task planning system"""
    
    def __init__(self, ai_provider):
        self.ai_provider = ai_provider
        self.tasks: List[Task] = []
        self.task_counter = 0
    
    def create_plan(self, project_description: str, project_type: str) -> List[Task]:
        """Create a detailed plan for the project - ENHANCED for reasoning models."""
        
        # Determine project complexity
        desc_lower = project_description.lower()
        is_simple = any(w in desc_lower for w in ["hello", "simple", "basic", "test"])
        is_complex = any(w in desc_lower for w in [
            "dashboard", "e-commerce", "authentication", "api", "backend", "database",
            "multi-page", "sections", "features", "full", "complete",
            "premium", "professional", "showcase", "portfolio", "landing page",
            "complex", "advanced", "clone", "saas", "platform"
        ])
        
        # Enhanced system prompt for reasoning models like DeepSeek-R1
        system_prompt = """You are an expert software architect creating project plans.

THINK STEP BY STEP:
1. First, analyze what the user wants to build
2. Identify the key components/features needed  
3. Break down into sequential, actionable tasks
4. Each task should produce concrete deliverables

OUTPUT RULES:
- Return ONLY valid JSON (no markdown, no explanation)
- Each task has: title, description, files (list of files to create), dependencies (list of task IDs)
- Task IDs start at 0
- Dependencies reference earlier task IDs only

TASK ORDERING:
1. Project setup (structure, config)
2. Core functionality
3. Features/components
4. Styling/polish
5. Testing (if needed)"""

        if is_simple:
            # Simple 2-task plan
            prompt = f"""Create 2 tasks to build this simple project:
"{project_description}"
Type: {project_type}

Return JSON format:
{{"tasks": [{{"title": "...", "description": "...", "files": [], "dependencies": []}}]}}"""
        elif is_complex:
            # Detailed 5-8 task plan for complex projects
            prompt = f"""Create a detailed 5-8 task plan for this project:

PROJECT: {project_description}
TYPE: {project_type}

Think about:
- What files need to be created?
- What's the logical order of development?
- What are the key features to implement?

Return JSON:
{{"reasoning": "Brief analysis", "tasks": [{{"title": "...", "description": "Specific actions", "files": ["path/file.ext"], "dependencies": []}}]}}"""
        else:
            # Standard 3-5 task plan
            prompt = f"""Create 3-5 tasks to build:
"{project_description}"
Type: {project_type}

Each task should be immediately actionable with specific files to create.

Return JSON: {{"tasks": [{{"title": "...", "description": "...", "files": [], "dependencies": []}}]}}"""

        try:
            response = self.ai_provider.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.3
            )
            
            # Extract JSON from response
            plan_data = self._extract_json(response)
            
            # Convert to Task objects
            self.tasks = self._parse_tasks(plan_data.get("tasks", []))
            return self.tasks
            
        except Exception as e:
            raise Exception(f"Failed to create plan: {str(e)}")
    
    def _extract_json(self, text: str) -> Dict:
        """Extract JSON from AI response"""
        # Try to find JSON in markdown code blocks
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            json_str = text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            json_str = text[start:end].strip()
        else:
            try:
                start = text.index("{")
                decoder = json.JSONDecoder()
                obj, idx = decoder.raw_decode(text[start:])
                json_str = text[start:start+idx]
            except (ValueError, json.JSONDecodeError):
                json_str = "{}"
        
        try:
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            logger.debug("Failed to parse planner JSON payload: %s", e)
            # Fallback: create basic plan
            return {
                "tasks": [
                    {
                        "title": "Initialize Project",
                        "description": "Set up project structure and configuration",
                        "dependencies": []
                    },
                    {
                        "title": "Implement Features",
                        "description": "Write code files based on requirements",
                        "dependencies": [0]
                    }
                ]
            }
    
    def _parse_tasks(self, tasks_data: List[Dict]) -> List[Task]:
        """Parse task data into Task objects"""
        tasks = []
        for idx, task_data in enumerate(tasks_data):
            task = Task(
                id=idx,
                title=task_data.get("title", f"Task {idx}"),
                description=task_data.get("description", ""),
                dependencies=task_data.get("dependencies", [])
            )
            
            # Parse subtasks recursively
            if "subtasks" in task_data:
                task.subtasks = self._parse_subtasks(task_data["subtasks"], idx)
            
            tasks.append(task)
        
        return tasks
    
    def _parse_subtasks(self, subtasks_data: List[Dict], parent_id: int) -> List[Task]:
        """Parse subtasks recursively"""
        subtasks = []
        for idx, subtask_data in enumerate(subtasks_data):
            self.task_counter += 1
            subtask = Task(
                id=self.task_counter,
                title=subtask_data.get("title", f"Subtask {idx}"),
                description=subtask_data.get("description", ""),
                dependencies=subtask_data.get("dependencies", [])
            )
            subtasks.append(subtask)
        return subtasks
    
    def get_next_task(self) -> Optional[Task]:
        """Get the next task to execute"""
        for task in self.tasks:
            if task.status == TaskStatus.PENDING:
                # Check if dependencies are met
                if self._are_dependencies_met(task):
                    return task
        return None
    
    def _are_dependencies_met(self, task: Task) -> bool:
        """Check if task dependencies are completed"""
        for dep_id in task.dependencies:
            if dep_id < len(self.tasks):
                dep_task = self.tasks[dep_id]
                if dep_task.status != TaskStatus.COMPLETED:
                    return False
        return True
    
    def update_task_status(self, task_id: int, status: TaskStatus, 
                          result: Optional[str] = None, error: Optional[str] = None):
        """Update task status"""
        if task_id < len(self.tasks):
            task = self.tasks[task_id]
            task.status = status
            if result:
                task.result = result
            if error:
                task.error = error
    
    def get_plan_summary(self) -> str:
        """Get a formatted summary of the plan"""
        lines = ["=" * 60, "PROJECT PLAN", "=" * 60, ""]
        
        for task in self.tasks:
            status_symbol = {
                TaskStatus.PENDING: "⏸",
                TaskStatus.IN_PROGRESS: "▶",
                TaskStatus.COMPLETED: "✓",
                TaskStatus.FAILED: "✗",
                TaskStatus.SKIPPED: "⊘"
            }.get(task.status, "?")
            
            lines.append(f"[{status_symbol}] Task {task.id}: {task.title}")
            lines.append(f"    {task.description}")
            if task.dependencies:
                lines.append(f"    Dependencies: {task.dependencies}")
            if task.subtasks:
                for subtask in task.subtasks:
                    lines.append(f"    - {subtask.title}")
            lines.append("")
        
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def is_plan_complete(self) -> bool:
        """Check if all tasks are completed"""
        return all(task.status == TaskStatus.COMPLETED for task in self.tasks)
    
    def get_progress(self) -> Dict:
        """Get progress statistics"""
        total = len(self.tasks)
        completed = sum(1 for t in self.tasks if t.status == TaskStatus.COMPLETED)
        in_progress = sum(1 for t in self.tasks if t.status == TaskStatus.IN_PROGRESS)
        failed = sum(1 for t in self.tasks if t.status == TaskStatus.FAILED)
        
        return {
            "total": total,
            "completed": completed,
            "in_progress": in_progress,
            "failed": failed,
            "pending": total - completed - in_progress - failed,
            "percentage": (completed / total * 100) if total > 0 else 0
        }
