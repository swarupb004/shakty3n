"""
Dependency DAG Planner
Implements a Directed Acyclic Graph for task decomposition with parallel execution support.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any, Tuple
from enum import Enum
import json
import time
import logging
from collections import deque

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    READY = "ready"  # Dependencies met, can execute
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"  # Dependencies failed


class AgentRole(Enum):
    """Specialist agent roles"""
    ARCHITECT = "architect"
    BACKEND = "backend"
    FRONTEND = "frontend"
    QA = "qa"
    SECURITY = "security"
    DEVOPS = "devops"
    GENERAL = "general"


@dataclass
class DAGTask:
    """A task node in the dependency graph"""
    id: str
    title: str
    description: str
    dependencies: Set[str] = field(default_factory=set)
    assigned_agent: AgentRole = AgentRole.GENERAL
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    retry_count: int = 0
    max_retries: int = 3
    priority: int = 0  # Higher = more important
    estimated_duration: Optional[float] = None  # seconds
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "dependencies": list(self.dependencies),
            "assigned_agent": self.assigned_agent.value,
            "status": self.status.value,
            "result": str(self.result) if self.result else None,
            "error": self.error,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "retry_count": self.retry_count,
            "priority": self.priority,
            "duration": (self.end_time - self.start_time) if self.end_time and self.start_time else None
        }
    
    def duration(self) -> Optional[float]:
        """Get actual duration if completed"""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return None


class DependencyDAG:
    """
    Directed Acyclic Graph for task management with parallel execution support.
    
    Features:
    - Automatic cycle detection
    - Parallel task grouping
    - Critical path calculation
    - Topological ordering
    """
    
    def __init__(self):
        self.tasks: Dict[str, DAGTask] = {}
        self._adjacency: Dict[str, Set[str]] = {}  # task_id -> tasks that depend on it
        self._reverse_adj: Dict[str, Set[str]] = {}  # task_id -> tasks it depends on
        
    def add_task(self, task: DAGTask) -> None:
        """Add a task to the DAG"""
        if task.id in self.tasks:
            raise ValueError(f"Task {task.id} already exists")
        
        self.tasks[task.id] = task
        self._adjacency[task.id] = set()
        self._reverse_adj[task.id] = set(task.dependencies)
        
        # Update adjacency for dependencies
        for dep_id in task.dependencies:
            if dep_id in self._adjacency:
                self._adjacency[dep_id].add(task.id)
                
        # Validate no cycles
        if self._has_cycle():
            del self.tasks[task.id]
            del self._adjacency[task.id]
            del self._reverse_adj[task.id]
            raise ValueError(f"Adding task {task.id} would create a cycle")
    
    def remove_task(self, task_id: str) -> None:
        """Remove a task from the DAG"""
        if task_id not in self.tasks:
            return
            
        # Remove from dependents
        for dep_id in self._reverse_adj[task_id]:
            if dep_id in self._adjacency:
                self._adjacency[dep_id].discard(task_id)
        
        # Remove tasks that depend on this
        for dependent_id in self._adjacency[task_id]:
            if dependent_id in self._reverse_adj:
                self._reverse_adj[dependent_id].discard(task_id)
        
        del self.tasks[task_id]
        del self._adjacency[task_id]
        del self._reverse_adj[task_id]
    
    def _has_cycle(self) -> bool:
        """Detect if the graph has a cycle using DFS"""
        visited = set()
        rec_stack = set()
        
        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            
            for neighbor in self._adjacency.get(node, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True
            
            rec_stack.remove(node)
            return False
        
        for task_id in self.tasks:
            if task_id not in visited:
                if dfs(task_id):
                    return True
        return False
    
    def get_ready_tasks(self) -> List[DAGTask]:
        """Get all tasks that are ready to execute (dependencies met, status pending)"""
        ready = []
        for task in self.tasks.values():
            if task.status != TaskStatus.PENDING:
                continue
            
            # Check all dependencies are completed
            deps_met = all(
                self.tasks[dep_id].status == TaskStatus.COMPLETED
                for dep_id in task.dependencies
                if dep_id in self.tasks
            )
            
            if deps_met:
                task.status = TaskStatus.READY
                ready.append(task)
        
        # Sort by priority (higher first)
        ready.sort(key=lambda t: -t.priority)
        return ready
    
    def get_parallel_groups(self) -> List[List[DAGTask]]:
        """
        Get tasks grouped by dependency levels for parallel execution.
        Each group contains tasks that can run simultaneously.
        """
        groups = []
        remaining = set(self.tasks.keys())
        completed_simulation = set()
        
        while remaining:
            # Find all tasks whose dependencies are in completed_simulation
            current_group = []
            for task_id in remaining:
                task = self.tasks[task_id]
                if task.dependencies.issubset(completed_simulation):
                    current_group.append(task)
            
            if not current_group:
                # No progress possible - remaining tasks have unsatisfied deps
                break
            
            groups.append(current_group)
            for task in current_group:
                remaining.remove(task.id)
                completed_simulation.add(task.id)
        
        return groups
    
    def topological_sort(self) -> List[DAGTask]:
        """Return tasks in topological order (respecting dependencies)"""
        in_degree = {task_id: len(self._reverse_adj[task_id]) for task_id in self.tasks}
        queue = deque([tid for tid, deg in in_degree.items() if deg == 0])
        result = []
        
        while queue:
            task_id = queue.popleft()
            result.append(self.tasks[task_id])
            
            for dependent_id in self._adjacency[task_id]:
                in_degree[dependent_id] -= 1
                if in_degree[dependent_id] == 0:
                    queue.append(dependent_id)
        
        return result
    
    def get_critical_path(self) -> List[DAGTask]:
        """
        Calculate the critical path (longest dependency chain).
        Returns the sequence of tasks on the critical path.
        """
        if not self.tasks:
            return []
        
        # Calculate longest path to each node
        longest_path_to: Dict[str, Tuple[float, List[str]]] = {}
        
        for task in self.topological_sort():
            if not task.dependencies:
                # Root task
                duration = task.estimated_duration or 1.0
                longest_path_to[task.id] = (duration, [task.id])
            else:
                # Find longest path through dependencies
                max_path = (0.0, [])
                for dep_id in task.dependencies:
                    if dep_id in longest_path_to:
                        path_len, path = longest_path_to[dep_id]
                        if path_len > max_path[0]:
                            max_path = (path_len, path.copy())
                
                duration = task.estimated_duration or 1.0
                longest_path_to[task.id] = (
                    max_path[0] + duration,
                    max_path[1] + [task.id]
                )
        
        # Find the longest overall path
        if not longest_path_to:
            return []
        
        max_task_id = max(longest_path_to.keys(), key=lambda x: longest_path_to[x][0])
        critical_path_ids = longest_path_to[max_task_id][1]
        
        return [self.tasks[tid] for tid in critical_path_ids]
    
    def update_task_status(self, task_id: str, status: TaskStatus, 
                           result: Optional[Any] = None, error: Optional[str] = None) -> None:
        """Update task status and handle consequences"""
        if task_id not in self.tasks:
            return
        
        task = self.tasks[task_id]
        task.status = status
        
        if status == TaskStatus.IN_PROGRESS:
            task.start_time = time.time()
        elif status in [TaskStatus.COMPLETED, TaskStatus.FAILED]:
            task.end_time = time.time()
            if result:
                task.result = result
            if error:
                task.error = error
        
        # If task failed, mark dependents as blocked
        if status == TaskStatus.FAILED:
            self._block_dependents(task_id)
    
    def _block_dependents(self, failed_task_id: str) -> None:
        """Mark all tasks depending on a failed task as blocked"""
        for dependent_id in self._adjacency.get(failed_task_id, []):
            dependent = self.tasks.get(dependent_id)
            if dependent and dependent.status == TaskStatus.PENDING:
                dependent.status = TaskStatus.BLOCKED
                self._block_dependents(dependent_id)
    
    def is_complete(self) -> bool:
        """Check if all tasks are completed"""
        return all(
            task.status in [TaskStatus.COMPLETED, TaskStatus.SKIPPED]
            for task in self.tasks.values()
        )
    
    def get_progress(self) -> Dict[str, Any]:
        """Get execution progress statistics"""
        total = len(self.tasks)
        if total == 0:
            return {"total": 0, "percentage": 100}
        
        status_counts = {}
        for task in self.tasks.values():
            status = task.status.value
            status_counts[status] = status_counts.get(status, 0) + 1
        
        completed = status_counts.get("completed", 0)
        
        return {
            "total": total,
            "completed": completed,
            "in_progress": status_counts.get("in_progress", 0),
            "pending": status_counts.get("pending", 0) + status_counts.get("ready", 0),
            "failed": status_counts.get("failed", 0),
            "blocked": status_counts.get("blocked", 0),
            "percentage": (completed / total) * 100
        }
    
    def export_for_review(self) -> Dict[str, Any]:
        """Export DAG for human review (approval gate)"""
        return {
            "task_count": len(self.tasks),
            "parallel_groups": [[t.to_dict() for t in group] for group in self.get_parallel_groups()],
            "critical_path": [t.to_dict() for t in self.get_critical_path()],
            "estimated_duration": sum(t.estimated_duration or 1.0 for t in self.get_critical_path())
        }
    
    def to_dict(self) -> Dict:
        """Serialize entire DAG"""
        return {
            "tasks": {tid: task.to_dict() for tid, task in self.tasks.items()},
            "progress": self.get_progress()
        }


class DAGPlanner:
    """
    AI-powered task planner that creates dependency DAGs.
    """
    
    # Role assignment keywords
    ROLE_KEYWORDS = {
        AgentRole.ARCHITECT: ["architecture", "design", "structure", "pattern", "schema", "plan"],
        AgentRole.BACKEND: ["api", "server", "database", "endpoint", "model", "controller", "auth"],
        AgentRole.FRONTEND: ["ui", "component", "page", "style", "css", "layout", "view", "form"],
        AgentRole.QA: ["test", "spec", "validate", "verify", "check", "assert"],
        AgentRole.SECURITY: ["security", "auth", "permission", "encrypt", "sanitize", "validate input"],
        AgentRole.DEVOPS: ["deploy", "ci", "cd", "docker", "pipeline", "build", "config"],
    }
    
    def __init__(self, ai_provider):
        self.ai_provider = ai_provider
        self.dag = DependencyDAG()
    
    def create_dag_plan(self, description: str, project_type: str) -> DependencyDAG:
        """Create a dependency DAG from project description"""
        
        system_prompt = """You are an expert software architect and project planner.
Create a detailed, parallelizable execution plan with clear dependencies.

Return JSON in this exact format:
{
  "tasks": [
    {
      "id": "task_1",
      "title": "Short task title",
      "description": "Detailed description of what to do",
      "dependencies": [],
      "priority": 10,
      "estimated_minutes": 5
    },
    {
      "id": "task_2", 
      "title": "Another task",
      "description": "This depends on task_1",
      "dependencies": ["task_1"],
      "priority": 8,
      "estimated_minutes": 10
    }
  ]
}

Rules:
1. Use descriptive task IDs like "setup_project", "create_api", "add_tests"
2. Dependencies must reference valid task IDs
3. Maximize parallelization - only add dependencies when truly required
4. Priority: 10=critical, 5=normal, 1=optional
5. Break into 5-15 concrete, executable tasks
6. Each task should be completable in under 15 minutes
"""

        prompt = f"""Create an execution plan for:

Project Type: {project_type}
Description: {description}

Generate tasks that an autonomous agent can execute using file/terminal tools.
Tasks should be specific like "Create src/App.jsx with main component" not vague like "Build frontend".
"""

        try:
            response = self.ai_provider.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=0.3
            )
            
            plan_data = self._extract_json(response)
            self.dag = self._build_dag(plan_data.get("tasks", []))
            return self.dag
            
        except Exception as e:
            logger.error(f"Failed to create DAG plan: {e}")
            # Fallback to basic plan
            return self._create_fallback_plan(description, project_type)
    
    def _extract_json(self, text: str) -> Dict:
        """Extract JSON from AI response"""
        # Try markdown code blocks first
        if "```json" in text:
            start = text.find("```json") + 7
            end = text.find("```", start)
            json_str = text[start:end].strip()
        elif "```" in text:
            start = text.find("```") + 3
            end = text.find("```", start)
            json_str = text[start:end].strip()
        else:
            # Try to find raw JSON
            try:
                start = text.index("{")
                # Find matching closing brace
                brace_count = 0
                for i, char in enumerate(text[start:], start):
                    if char == "{":
                        brace_count += 1
                    elif char == "}":
                        brace_count -= 1
                        if brace_count == 0:
                            json_str = text[start:i+1]
                            break
                else:
                    json_str = "{}"
            except ValueError:
                json_str = "{}"
        
        try:
            return json.loads(json_str)
        except json.JSONDecodeError:
            return {"tasks": []}
    
    def _build_dag(self, tasks_data: List[Dict]) -> DependencyDAG:
        """Build DAG from parsed task data"""
        dag = DependencyDAG()
        
        for task_data in tasks_data:
            task = DAGTask(
                id=task_data.get("id", f"task_{len(dag.tasks)}"),
                title=task_data.get("title", "Untitled Task"),
                description=task_data.get("description", ""),
                dependencies=set(task_data.get("dependencies", [])),
                priority=task_data.get("priority", 5),
                estimated_duration=(task_data.get("estimated_minutes", 5) * 60),
                assigned_agent=self._infer_agent_role(task_data)
            )
            
            try:
                dag.add_task(task)
            except ValueError as e:
                logger.warning(f"Skipping task {task.id}: {e}")
        
        return dag
    
    def _infer_agent_role(self, task_data: Dict) -> AgentRole:
        """Infer which specialist agent should handle this task"""
        text = f"{task_data.get('title', '')} {task_data.get('description', '')}".lower()
        
        for role, keywords in self.ROLE_KEYWORDS.items():
            if any(kw in text for kw in keywords):
                return role
        
        return AgentRole.GENERAL
    
    def _create_fallback_plan(self, description: str, project_type: str) -> DependencyDAG:
        """Create a basic fallback plan if AI fails"""
        dag = DependencyDAG()
        
        fallback_tasks = [
            DAGTask(
                id="setup",
                title="Initialize Project",
                description=f"Set up {project_type} project structure",
                priority=10,
                assigned_agent=AgentRole.DEVOPS
            ),
            DAGTask(
                id="implement",
                title="Implement Core Features",
                description=description,
                dependencies={"setup"},
                priority=8,
                assigned_agent=AgentRole.BACKEND
            ),
            DAGTask(
                id="test",
                title="Add Tests",
                description="Create test files for the implementation",
                dependencies={"implement"},
                priority=5,
                assigned_agent=AgentRole.QA
            ),
        ]
        
        for task in fallback_tasks:
            dag.add_task(task)
        
        return dag
    
    def get_plan_summary(self) -> str:
        """Get formatted summary of the plan"""
        lines = ["=" * 60, "EXECUTION PLAN (DAG)", "=" * 60, ""]
        
        for i, group in enumerate(self.dag.get_parallel_groups()):
            lines.append(f"Phase {i + 1} (Parallel):")
            for task in group:
                status_sym = {
                    TaskStatus.PENDING: "⏸",
                    TaskStatus.READY: "🔵",
                    TaskStatus.IN_PROGRESS: "▶",
                    TaskStatus.COMPLETED: "✓",
                    TaskStatus.FAILED: "✗",
                    TaskStatus.BLOCKED: "🚫",
                }[task.status]
                lines.append(f"  [{status_sym}] {task.id}: {task.title} ({task.assigned_agent.value})")
            lines.append("")
        
        progress = self.dag.get_progress()
        lines.append(f"Progress: {progress['completed']}/{progress['total']} ({progress['percentage']:.1f}%)")
        lines.append("=" * 60)
        
        return "\n".join(lines)


__all__ = ['DAGTask', 'DependencyDAG', 'DAGPlanner', 'TaskStatus', 'AgentRole']
