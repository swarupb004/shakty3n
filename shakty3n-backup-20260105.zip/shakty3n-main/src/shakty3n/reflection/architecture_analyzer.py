"""
Architecture Analyzer Module

Provides proactive code quality analysis and refactoring suggestions.
Detects code smells, anti-patterns, and improvement opportunities.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Set
from enum import Enum
from pathlib import Path
import re
import ast
import logging

logger = logging.getLogger(__name__)


class IssueType(Enum):
    """Types of architecture issues"""
    CODE_SMELL = "code_smell"
    ANTI_PATTERN = "anti_pattern"
    PERFORMANCE = "performance"
    SECURITY = "security"
    MAINTAINABILITY = "maintainability"
    TESTABILITY = "testability"
    COMPLEXITY = "complexity"
    DUPLICATION = "duplication"


class Severity(Enum):
    """Issue severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class ArchitectureIssue:
    """An architecture issue found during analysis"""
    issue_type: IssueType
    severity: Severity
    title: str
    description: str
    file_path: str
    line_number: Optional[int] = None
    recommendation: str = ""
    estimated_effort: str = "low"  # low, medium, high
    code_snippet: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            "issue_type": self.issue_type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "recommendation": self.recommendation,
            "estimated_effort": self.estimated_effort,
            "code_snippet": self.code_snippet
        }


@dataclass
class RefactoringOpportunity:
    """A suggested refactoring"""
    name: str
    file_path: str
    description: str
    before_pattern: str
    suggested_change: str
    benefit: str
    effort: str  # low, medium, high
    
    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "file_path": self.file_path,
            "description": self.description,
            "before_pattern": self.before_pattern,
            "suggested_change": self.suggested_change,
            "benefit": self.benefit,
            "effort": self.effort
        }


# Code smell thresholds
THRESHOLDS = {
    "max_function_lines": 50,
    "max_class_lines": 300,
    "max_file_lines": 500,
    "max_complexity": 10,  # Cyclomatic complexity
    "max_parameters": 5,
    "max_nesting_depth": 4,
    "max_line_length": 120,
    "min_docstring_ratio": 0.3,
}


class PythonAnalyzer(ast.NodeVisitor):
    """AST-based Python code analyzer"""
    
    def __init__(self, file_path: str, source: str):
        self.file_path = file_path
        self.source = source
        self.lines = source.split("\n")
        self.issues: List[ArchitectureIssue] = []
        self.refactorings: List[RefactoringOpportunity] = []
        self.functions: List[Dict] = []
        self.classes: List[Dict] = []
        self._current_class = None
        self._nesting_depth = 0
        
    def _get_source_segment(self, node: ast.AST) -> Optional[str]:
        """Get source code for an AST node"""
        try:
            return ast.get_source_segment(self.source, node)
        except:
            return None
    
    def visit_FunctionDef(self, node: ast.FunctionDef):
        """Analyze function definitions"""
        func_lines = node.end_lineno - node.lineno + 1 if node.end_lineno else 0
        
        # Track function info
        self.functions.append({
            "name": node.name,
            "lines": func_lines,
            "params": len(node.args.args),
            "line_number": node.lineno,
            "has_docstring": ast.get_docstring(node) is not None
        })
        
        # Check for long functions
        if func_lines > THRESHOLDS["max_function_lines"]:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.CODE_SMELL,
                severity=Severity.MEDIUM,
                title="Long function",
                description=f"Function '{node.name}' has {func_lines} lines (max: {THRESHOLDS['max_function_lines']})",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Extract smaller helper functions",
                estimated_effort="medium"
            ))
        
        # Check for too many parameters
        param_count = len(node.args.args)
        if param_count > THRESHOLDS["max_parameters"]:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.CODE_SMELL,
                severity=Severity.LOW,
                title="Too many parameters",
                description=f"Function '{node.name}' has {param_count} parameters (max: {THRESHOLDS['max_parameters']})",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Consider using a configuration object or dataclass",
                estimated_effort="low"
            ))
        
        # Check for missing docstring
        if not ast.get_docstring(node) and not node.name.startswith("_"):
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.MAINTAINABILITY,
                severity=Severity.INFO,
                title="Missing docstring",
                description=f"Public function '{node.name}' lacks a docstring",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Add a docstring explaining purpose and parameters",
                estimated_effort="low"
            ))
        
        # Analyze function body for complexity
        self._analyze_complexity(node)
        
        self.generic_visit(node)
    
    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        """Analyze async function definitions (same rules)"""
        # Reuse FunctionDef analysis
        self.visit_FunctionDef(node)  # type: ignore
    
    def visit_ClassDef(self, node: ast.ClassDef):
        """Analyze class definitions"""
        class_lines = node.end_lineno - node.lineno + 1 if node.end_lineno else 0
        
        # Count methods
        methods = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        
        self.classes.append({
            "name": node.name,
            "lines": class_lines,
            "methods": len(methods),
            "line_number": node.lineno,
            "has_docstring": ast.get_docstring(node) is not None
        })
        
        # Check for large classes
        if class_lines > THRESHOLDS["max_class_lines"]:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.CODE_SMELL,
                severity=Severity.MEDIUM,
                title="Large class",
                description=f"Class '{node.name}' has {class_lines} lines (max: {THRESHOLDS['max_class_lines']})",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Consider splitting into smaller focused classes",
                estimated_effort="high"
            ))
        
        # Check for missing docstring
        if not ast.get_docstring(node):
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.MAINTAINABILITY,
                severity=Severity.INFO,
                title="Missing class docstring",
                description=f"Class '{node.name}' lacks a docstring",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Add a docstring explaining the class purpose",
                estimated_effort="low"
            ))
        
        # Track current class for method analysis
        old_class = self._current_class
        self._current_class = node.name
        self.generic_visit(node)
        self._current_class = old_class
    
    def visit_If(self, node: ast.If):
        """Track nesting depth for if statements"""
        self._nesting_depth += 1
        
        if self._nesting_depth > THRESHOLDS["max_nesting_depth"]:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.COMPLEXITY,
                severity=Severity.MEDIUM,
                title="Deep nesting",
                description=f"Nesting depth {self._nesting_depth} exceeds maximum {THRESHOLDS['max_nesting_depth']}",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Extract nested logic into separate functions or use early returns",
                estimated_effort="medium"
            ))
        
        self.generic_visit(node)
        self._nesting_depth -= 1
    
    def visit_For(self, node: ast.For):
        """Track nesting for for loops"""
        self._nesting_depth += 1
        self.generic_visit(node)
        self._nesting_depth -= 1
    
    def visit_While(self, node: ast.While):
        """Track nesting for while loops"""
        self._nesting_depth += 1
        self.generic_visit(node)
        self._nesting_depth -= 1
    
    def visit_Try(self, node: ast.Try):
        """Analyze try/except blocks"""
        # Check for bare except
        for handler in node.handlers:
            if handler.type is None:
                self.issues.append(ArchitectureIssue(
                    issue_type=IssueType.ANTI_PATTERN,
                    severity=Severity.HIGH,
                    title="Bare except clause",
                    description="Bare 'except:' catches all exceptions including system exceptions",
                    file_path=self.file_path,
                    line_number=handler.lineno,
                    recommendation="Catch specific exception types (e.g., except Exception:)",
                    estimated_effort="low"
                ))
        
        self._nesting_depth += 1
        self.generic_visit(node)
        self._nesting_depth -= 1
    
    def visit_Global(self, node: ast.Global):
        """Flag global variable usage"""
        self.issues.append(ArchitectureIssue(
            issue_type=IssueType.ANTI_PATTERN,
            severity=Severity.MEDIUM,
            title="Global variable usage",
            description=f"Global variables used: {', '.join(node.names)}",
            file_path=self.file_path,
            line_number=node.lineno,
            recommendation="Avoid globals; use class attributes or dependency injection",
            estimated_effort="medium"
        ))
        self.generic_visit(node)
    
    def _analyze_complexity(self, node: ast.FunctionDef):
        """Calculate cyclomatic complexity"""
        complexity = 1  # Base complexity
        
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        
        if complexity > THRESHOLDS["max_complexity"]:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.COMPLEXITY,
                severity=Severity.HIGH if complexity > 15 else Severity.MEDIUM,
                title="High cyclomatic complexity",
                description=f"Function '{node.name}' has complexity {complexity} (max: {THRESHOLDS['max_complexity']})",
                file_path=self.file_path,
                line_number=node.lineno,
                recommendation="Simplify logic, extract helper functions, or use polymorphism",
                estimated_effort="high"
            ))
    
    def analyze(self):
        """Run the analysis"""
        try:
            tree = ast.parse(self.source)
            self.visit(tree)
        except SyntaxError as e:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.CODE_SMELL,
                severity=Severity.CRITICAL,
                title="Syntax error",
                description=f"Cannot parse file: {e.msg}",
                file_path=self.file_path,
                line_number=e.lineno,
                recommendation="Fix syntax error before analysis",
                estimated_effort="low"
            ))


class ArchitectureAnalyzer:
    """
    Proactive architecture and code quality analyzer.
    
    Features:
    - Code smell detection
    - Anti-pattern identification
    - Complexity analysis
    - Refactoring suggestions
    - Performance hints
    """
    
    PYTHON_EXTENSIONS = {".py"}
    JS_EXTENSIONS = {".js", ".jsx", ".ts", ".tsx"}
    
    IGNORE_DIRS = {"node_modules", "venv", ".venv", "__pycache__", ".git", 
                   "build", "dist", ".next", "vendor", "target", ".tox"}
    
    def __init__(self, ai_provider=None):
        self.ai_provider = ai_provider
        self.issues: List[ArchitectureIssue] = []
        self.refactorings: List[RefactoringOpportunity] = []
        self._file_metrics: Dict[str, Dict] = {}
    
    def analyze_project(self, project_dir: str) -> Dict[str, Any]:
        """
        Analyze entire project for architecture issues.
        
        Args:
            project_dir: Path to project directory
            
        Returns:
            Analysis results with issues and suggestions
        """
        self.issues = []
        self.refactorings = []
        self._file_metrics = {}
        
        project_path = Path(project_dir)
        
        if not project_path.exists():
            logger.warning(f"Project directory does not exist: {project_dir}")
            return {"error": "Project directory not found"}
        
        # Analyze each file
        for file_path in project_path.rglob("*"):
            if not file_path.is_file():
                continue
            
            # Skip ignored directories
            if any(part in self.IGNORE_DIRS for part in file_path.parts):
                continue
            
            # Analyze based on file type
            suffix = file_path.suffix.lower()
            
            try:
                if suffix in self.PYTHON_EXTENSIONS:
                    self._analyze_python_file(file_path, project_path)
                elif suffix in self.JS_EXTENSIONS:
                    self._analyze_js_file(file_path, project_path)
            except Exception as e:
                logger.debug(f"Error analyzing {file_path}: {e}")
        
        # Run project-level analysis
        self._analyze_project_structure(project_path)
        
        # Sort issues by severity
        severity_order = {Severity.CRITICAL: 0, Severity.HIGH: 1, 
                        Severity.MEDIUM: 2, Severity.LOW: 3, Severity.INFO: 4}
        self.issues.sort(key=lambda x: severity_order.get(x.severity, 5))
        
        return self.get_results()
    
    def _analyze_python_file(self, file_path: Path, project_path: Path):
        """Analyze a Python file"""
        try:
            source = file_path.read_text(encoding="utf-8")
            relative_path = str(file_path.relative_to(project_path))
            
            # Track file size
            lines = len(source.split("\n"))
            self._file_metrics[relative_path] = {"lines": lines, "type": "python"}
            
            if lines > THRESHOLDS["max_file_lines"]:
                self.issues.append(ArchitectureIssue(
                    issue_type=IssueType.MAINTAINABILITY,
                    severity=Severity.MEDIUM,
                    title="Large file",
                    description=f"File has {lines} lines (max: {THRESHOLDS['max_file_lines']})",
                    file_path=relative_path,
                    recommendation="Consider splitting into multiple modules",
                    estimated_effort="high"
                ))
            
            # Run AST analysis
            analyzer = PythonAnalyzer(relative_path, source)
            analyzer.analyze()
            
            self.issues.extend(analyzer.issues)
            self.refactorings.extend(analyzer.refactorings)
            
            # Update metrics
            self._file_metrics[relative_path].update({
                "functions": len(analyzer.functions),
                "classes": len(analyzer.classes),
                "issues": len(analyzer.issues)
            })
            
            # Check for common anti-patterns via regex
            self._check_python_patterns(relative_path, source)
            
        except UnicodeDecodeError:
            logger.debug(f"Cannot decode file: {file_path}")
    
    def _analyze_js_file(self, file_path: Path, project_path: Path):
        """Analyze a JavaScript/TypeScript file (basic patterns)"""
        try:
            source = file_path.read_text(encoding="utf-8")
            relative_path = str(file_path.relative_to(project_path))
            
            lines = source.split("\n")
            self._file_metrics[relative_path] = {"lines": len(lines), "type": "javascript"}
            
            # Check for common issues
            for i, line in enumerate(lines, 1):
                # var usage
                if re.search(r'\bvar\s+\w+', line):
                    self.issues.append(ArchitectureIssue(
                        issue_type=IssueType.ANTI_PATTERN,
                        severity=Severity.LOW,
                        title="Use of 'var'",
                        description="'var' has function scope issues; prefer 'let' or 'const'",
                        file_path=relative_path,
                        line_number=i,
                        recommendation="Replace 'var' with 'const' or 'let'",
                        estimated_effort="low"
                    ))
                
                # console.log in production
                if re.search(r'console\.(log|debug|info)\(', line) and 'test' not in relative_path.lower():
                    self.issues.append(ArchitectureIssue(
                        issue_type=IssueType.CODE_SMELL,
                        severity=Severity.INFO,
                        title="Console statement",
                        description="console.log statement found in production code",
                        file_path=relative_path,
                        line_number=i,
                        recommendation="Remove or replace with proper logging",
                        estimated_effort="low"
                    ))
                
        except UnicodeDecodeError:
            logger.debug(f"Cannot decode file: {file_path}")
    
    def _check_python_patterns(self, file_path: str, source: str):
        """Check for Python anti-patterns using regex"""
        lines = source.split("\n")
        
        for i, line in enumerate(lines, 1):
            # Hardcoded credentials pattern
            if re.search(r'(password|secret|api_key|token)\s*=\s*["\'][^"\']+["\']', 
                        line, re.IGNORECASE):
                self.issues.append(ArchitectureIssue(
                    issue_type=IssueType.SECURITY,
                    severity=Severity.HIGH,
                    title="Hardcoded credential",
                    description="Potential hardcoded secret detected",
                    file_path=file_path,
                    line_number=i,
                    recommendation="Use environment variables for secrets",
                    estimated_effort="low",
                    code_snippet=line.strip()[:80]
                ))
            
            # TODO/FIXME without issue tracking
            if re.search(r'#\s*(TODO|FIXME|XXX|HACK)(?!\s*\()', line, re.IGNORECASE):
                self.issues.append(ArchitectureIssue(
                    issue_type=IssueType.MAINTAINABILITY,
                    severity=Severity.INFO,
                    title="Untracked TODO",
                    description="TODO comment without issue reference",
                    file_path=file_path,
                    line_number=i,
                    recommendation="Link TODOs to issue tracking system",
                    estimated_effort="low"
                ))
            
            # Print statement (should use logging)
            if re.search(r'^\s*print\s*\(', line) and 'test' not in file_path.lower():
                self.issues.append(ArchitectureIssue(
                    issue_type=IssueType.CODE_SMELL,
                    severity=Severity.LOW,
                    title="Print statement",
                    description="print() used instead of logging",
                    file_path=file_path,
                    line_number=i,
                    recommendation="Use logging module for better control",
                    estimated_effort="low"
                ))
    
    def _analyze_project_structure(self, project_path: Path):
        """Analyze overall project structure"""
        # Check for common project files
        has_tests = (project_path / "tests").exists() or any(
            f.name.startswith("test_") for f in project_path.rglob("*.py")
        )
        
        has_requirements = (project_path / "requirements.txt").exists()
        has_readme = (project_path / "README.md").exists() or (project_path / "README.rst").exists()
        has_gitignore = (project_path / ".gitignore").exists()
        
        if not has_tests:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.TESTABILITY,
                severity=Severity.MEDIUM,
                title="No tests found",
                description="Project lacks a tests directory or test files",
                file_path="project",
                recommendation="Add unit tests to improve code quality",
                estimated_effort="high"
            ))
        
        if not has_readme:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.MAINTAINABILITY,
                severity=Severity.LOW,
                title="Missing README",
                description="No README.md file found",
                file_path="project",
                recommendation="Add README with project description and setup instructions",
                estimated_effort="low"
            ))
        
        if not has_gitignore:
            self.issues.append(ArchitectureIssue(
                issue_type=IssueType.MAINTAINABILITY,
                severity=Severity.LOW,
                title="Missing .gitignore",
                description="No .gitignore file found",
                file_path="project",
                recommendation="Add .gitignore to exclude build artifacts and dependencies",
                estimated_effort="low"
            ))
    
    def get_results(self) -> Dict[str, Any]:
        """Get analysis results"""
        severity_counts = {}
        for issue in self.issues:
            sev = issue.severity.value
            severity_counts[sev] = severity_counts.get(sev, 0) + 1
        
        type_counts = {}
        for issue in self.issues:
            t = issue.issue_type.value
            type_counts[t] = type_counts.get(t, 0) + 1
        
        return {
            "total_issues": len(self.issues),
            "by_severity": severity_counts,
            "by_type": type_counts,
            "issues": [i.to_dict() for i in self.issues],
            "refactorings": [r.to_dict() for r in self.refactorings],
            "files_analyzed": len(self._file_metrics),
            "file_metrics": self._file_metrics,
            "score": self._calculate_score()
        }
    
    def _calculate_score(self) -> int:
        """Calculate architecture health score (0-100)"""
        if not self.issues:
            return 100
        
        deductions = {
            Severity.CRITICAL: 20,
            Severity.HIGH: 10,
            Severity.MEDIUM: 5,
            Severity.LOW: 2,
            Severity.INFO: 0
        }
        
        total_deduction = sum(deductions.get(i.severity, 0) for i in self.issues)
        return max(0, 100 - total_deduction)
    
    def get_report(self) -> str:
        """Generate human-readable report"""
        results = self.get_results()
        
        lines = [
            "=" * 60,
            "ARCHITECTURE ANALYSIS REPORT",
            "=" * 60,
            "",
            f"Health Score: {results['score']}/100",
            f"Files Analyzed: {results['files_analyzed']}",
            f"Total Issues: {results['total_issues']}",
            ""
        ]
        
        if not self.issues:
            lines.append("✓ No significant issues found!")
        else:
            # Group by severity
            for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM]:
                sev_issues = [i for i in self.issues if i.severity == severity]
                if sev_issues:
                    lines.append(f"\n{severity.value.upper()} ({len(sev_issues)}):")
                    for issue in sev_issues[:5]:
                        loc = f"{issue.file_path}:{issue.line_number}" if issue.line_number else issue.file_path
                        lines.append(f"  [{issue.issue_type.value}] {loc}")
                        lines.append(f"    {issue.title}: {issue.description}")
                        lines.append(f"    → {issue.recommendation}")
        
        lines.append("\n" + "=" * 60)
        return "\n".join(lines)


__all__ = ['ArchitectureAnalyzer', 'ArchitectureIssue', 'IssueType', 
           'Severity', 'RefactoringOpportunity']
