"""
Self-Reflection and Re-planning Module
Evaluates execution progress and adjusts strategy when needed.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import time
import logging

logger = logging.getLogger(__name__)


class ReflectionTrigger(Enum):
    """Reasons for triggering reflection"""
    TASK_COMPLETE = "task_complete"
    TASK_FAILED = "task_failed"
    PHASE_COMPLETE = "phase_complete"
    ERROR_THRESHOLD = "error_threshold"
    TIMEOUT = "timeout"
    USER_REQUEST = "user_request"


@dataclass
class ReflectionResult:
    """Result of a reflection operation"""
    confidence_score: float  # 0-100
    issues_found: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    learnings: List[str] = field(default_factory=list)
    should_replan: bool = False
    replan_reason: Optional[str] = None
    suggested_changes: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "confidence_score": self.confidence_score,
            "issues_found": self.issues_found,
            "recommendations": self.recommendations,
            "learnings": self.learnings,
            "should_replan": self.should_replan,
            "replan_reason": self.replan_reason,
            "suggested_changes": self.suggested_changes
        }


class ConfidenceCalculator:
    """
    Calculates confidence scores based on execution state.
    
    Factors considered:
    - Task success rate
    - Error frequency
    - Validation results
    - Test coverage
    - Security findings
    """
    
    # Weight factors
    WEIGHTS = {
        "task_success": 0.30,
        "no_errors": 0.20,
        "validation_pass": 0.20,
        "test_coverage": 0.15,
        "security_clean": 0.15,
    }
    
    @staticmethod
    def calculate(execution_state: Dict) -> float:
        """
        Calculate overall confidence score (0-100).
        
        Args:
            execution_state: Dict with keys:
                - tasks_completed: int
                - tasks_failed: int
                - tasks_total: int
                - errors: List[str]
                - validation_passed: bool
                - test_coverage: float (0-1)
                - security_findings: List  
        """
        scores = {}
        
        # Task success rate
        total = execution_state.get("tasks_total", 1)
        completed = execution_state.get("tasks_completed", 0)
        failed = execution_state.get("tasks_failed", 0)
        
        if total > 0:
            scores["task_success"] = (completed / total) * 100
            # Penalize failures more heavily
            if failed > 0:
                scores["task_success"] *= (1 - (failed / total) * 0.5)
        else:
            scores["task_success"] = 50  # Neutral if no tasks
        
        # Error frequency
        errors = execution_state.get("errors", [])
        if len(errors) == 0:
            scores["no_errors"] = 100
        elif len(errors) <= 2:
            scores["no_errors"] = 70
        elif len(errors) <= 5:
            scores["no_errors"] = 40
        else:
            scores["no_errors"] = 10
        
        # Validation
        if execution_state.get("validation_passed", None) is True:
            scores["validation_pass"] = 100
        elif execution_state.get("validation_passed", None) is False:
            scores["validation_pass"] = 20
        else:
            scores["validation_pass"] = 50  # Not run yet
        
        # Test coverage
        coverage = execution_state.get("test_coverage", 0)
        scores["test_coverage"] = coverage * 100
        
        # Security
        findings = execution_state.get("security_findings", [])
        critical = sum(1 for f in findings if f.get("severity") in ["critical", "high"])
        if critical == 0 and len(findings) == 0:
            scores["security_clean"] = 100
        elif critical == 0:
            scores["security_clean"] = 70
        elif critical <= 2:
            scores["security_clean"] = 30
        else:
            scores["security_clean"] = 10
        
        # Weighted average
        total_score = sum(
            scores.get(key, 50) * weight 
            for key, weight in ConfidenceCalculator.WEIGHTS.items()
        )
        
        return min(100, max(0, total_score))


class SelfReflector:
    """
    Self-reflection engine that evaluates execution and suggests improvements.
    
    Uses AI to analyze execution patterns and extract learnings.
    """
    
    # Thresholds for triggering re-planning
    FAILURE_THRESHOLD = 3  # Consecutive failures before re-plan
    ERROR_THRESHOLD = 5  # Total errors before re-plan
    CONFIDENCE_THRESHOLD = 30  # Below this, re-plan
    
    def __init__(self, ai_provider, memory=None):
        """
        Args:
            ai_provider: AI provider for analysis
            memory: Optional LongTermMemory instance
        """
        self.ai = ai_provider
        self.memory = memory
        self.consecutive_failures = 0
        self.total_errors = 0
        self.reflections: List[ReflectionResult] = []
    
    def reflect_on_task(self, task: Dict, result: Any, 
                        success: bool) -> ReflectionResult:
        """
        Evaluate a single task completion and extract learnings.
        
        Args:
            task: Task dict with id, title, description
            result: Task execution result
            success: Whether task succeeded
            
        Returns:
            ReflectionResult with analysis
        """
        if success:
            self.consecutive_failures = 0
            reflection = ReflectionResult(
                confidence_score=85,
                learnings=[f"Task '{task.get('title')}' completed successfully"]
            )
        else:
            self.consecutive_failures += 1
            self.total_errors += 1
            
            # Analyze failure
            issues = [f"Task '{task.get('title')}' failed"]
            recommendations = []
            should_replan = False
            
            if self.consecutive_failures >= self.FAILURE_THRESHOLD:
                should_replan = True
                recommendations.append(
                    f"Consecutive failures ({self.consecutive_failures}) - consider alternative approach"
                )
            
            if isinstance(result, str) and "error" in result.lower():
                recommendations.append("Review error message for debugging hints")
                
                # Try to get known fix from memory
                if self.memory:
                    known_fix = self.memory.get_known_fix(str(result))
                    if known_fix and known_fix.get("success_rate", 0) > 0.5:
                        recommendations.append(
                            f"Known fix (success rate: {known_fix['success_rate']:.0%}): "
                            f"{known_fix['fix_strategy']}"
                        )
            
            reflection = ReflectionResult(
                confidence_score=max(30, 70 - (self.consecutive_failures * 10)),
                issues_found=issues,
                recommendations=recommendations,
                should_replan=should_replan,
                replan_reason="Consecutive failures exceeded threshold" if should_replan else None
            )
        
        self.reflections.append(reflection)
        return reflection
    
    def reflect_on_phase(self, phase: str, tasks: List[Dict],
                         execution_state: Dict) -> ReflectionResult:
        """
        Evaluate an entire phase completion.
        
        Args:
            phase: Phase name (planning, execution, validation)
            tasks: List of tasks in this phase
            execution_state: Current execution state dict
            
        Returns:
            ReflectionResult with comprehensive analysis
        """
        # Calculate confidence
        confidence = ConfidenceCalculator.calculate(execution_state)
        
        # Analyze results
        issues = []
        recommendations = []
        learnings = []
        should_replan = False
        
        # Count task outcomes
        completed = sum(1 for t in tasks if t.get("status") == "completed")
        failed = sum(1 for t in tasks if t.get("status") == "failed")
        total = len(tasks)
        
        if total > 0:
            success_rate = completed / total
            if success_rate < 0.5:
                issues.append(f"Low success rate: {success_rate:.0%} ({completed}/{total} tasks)")
                should_replan = True
        
        if failed > 0:
            issues.append(f"{failed} task(s) failed")
            failed_tasks = [t.get("title") for t in tasks if t.get("status") == "failed"]
            learnings.append(f"Failed tasks: {', '.join(failed_tasks[:3])}")
        
        # Check confidence threshold
        if confidence < self.CONFIDENCE_THRESHOLD:
            issues.append(f"Low confidence score: {confidence:.1f}")
            should_replan = True
            recommendations.append("Consider simplifying the approach or breaking into smaller tasks")
        
        # Phase-specific analysis
        if phase == "execution":
            if execution_state.get("errors", []):
                error_types = self._categorize_errors(execution_state["errors"])
                for error_type, count in error_types.items():
                    if count > 2:
                        issues.append(f"Repeated {error_type} errors ({count})")
                        recommendations.append(f"Focus on fixing {error_type} issues first")
        
        elif phase == "validation":
            if not execution_state.get("validation_passed", True):
                issues.append("Validation failed")
                recommendations.append("Review validation errors and fix before proceeding")
        
        # Use AI for deeper analysis if significant issues
        if len(issues) > 2 or confidence < 50:
            ai_analysis = self._ai_analyze(phase, tasks, execution_state, issues)
            if ai_analysis:
                recommendations.extend(ai_analysis.get("recommendations", []))
                learnings.extend(ai_analysis.get("learnings", []))
        
        reflection = ReflectionResult(
            confidence_score=confidence,
            issues_found=issues,
            recommendations=recommendations,
            learnings=learnings,
            should_replan=should_replan,
            replan_reason=f"Phase {phase} had critical issues" if should_replan else None
        )
        
        self.reflections.append(reflection)
        
        # Store learnings in memory
        if self.memory and learnings:
            for learning in learnings:
                self.memory.record_decision(
                    execution_state.get("project_id", "unknown"),
                    "learning",
                    learning,
                    f"Reflected after {phase} phase"
                )
        
        return reflection
    
    def _categorize_errors(self, errors: List[str]) -> Dict[str, int]:
        """Categorize errors by type"""
        categories = {}
        for error in errors:
            error_lower = str(error).lower()
            if "syntax" in error_lower:
                category = "syntax"
            elif "import" in error_lower or "module" in error_lower:
                category = "import"
            elif "type" in error_lower:
                category = "type"
            elif "permission" in error_lower or "access" in error_lower:
                category = "permission"
            elif "timeout" in error_lower:
                category = "timeout"
            else:
                category = "other"
            
            categories[category] = categories.get(category, 0) + 1
        
        return categories
    
    def _ai_analyze(self, phase: str, tasks: List[Dict], 
                    execution_state: Dict, issues: List[str]) -> Optional[Dict]:
        """Use AI to analyze execution and provide recommendations"""
        try:
            prompt = f"""Analyze this execution state and provide recommendations:

Phase: {phase}
Tasks: {len(tasks)} total
Issues found: {issues}

Execution state:
- Completed: {execution_state.get('tasks_completed', 0)}
- Failed: {execution_state.get('tasks_failed', 0)}
- Errors: {len(execution_state.get('errors', []))}

Provide:
1. Top 2 recommendations to improve execution
2. Key learnings from this phase

Respond in JSON: {{"recommendations": [...], "learnings": [...]}}
"""
            
            response = self.ai.generate(
                prompt=prompt,
                system_prompt="You are an expert at analyzing software development execution and suggesting improvements. Be concise.",
                temperature=0.3
            )
            
            # Parse response
            import json
            import re
            match = re.search(r'\{[^}]+\}', response, re.DOTALL)
            if match:
                return json.loads(match.group())
            
        except Exception as e:
            logger.warning(f"AI analysis failed: {e}")
        
        return None
    
    def should_replan(self, current_progress: Dict, 
                      failures: List[str]) -> Tuple[bool, str]:
        """
        Determine if re-planning is needed based on execution state.
        
        Returns:
            Tuple of (should_replan, reason)
        """
        # Check failure threshold
        if len(failures) >= self.FAILURE_THRESHOLD:
            return True, f"Too many failures: {len(failures)}"
        
        # Check error threshold
        if self.total_errors >= self.ERROR_THRESHOLD:
            return True, f"Error threshold exceeded: {self.total_errors}"
        
        # Check confidence
        confidence = ConfidenceCalculator.calculate(current_progress)
        if confidence < self.CONFIDENCE_THRESHOLD:
            return True, f"Confidence too low: {confidence:.1f}"
        
        # Check for blocked tasks
        blocked = current_progress.get("tasks_blocked", 0)
        total = current_progress.get("tasks_total", 1)
        if blocked > 0 and blocked / total > 0.3:
            return True, f"Too many blocked tasks: {blocked}/{total}"
        
        return False, ""
    
    def get_reflection_summary(self) -> Dict[str, Any]:
        """Get summary of all reflections"""
        if not self.reflections:
            return {"count": 0, "avg_confidence": 50}
        
        return {
            "count": len(self.reflections),
            "avg_confidence": sum(r.confidence_score for r in self.reflections) / len(self.reflections),
            "total_issues": sum(len(r.issues_found) for r in self.reflections),
            "replans_suggested": sum(1 for r in self.reflections if r.should_replan),
            "learnings": [l for r in self.reflections for l in r.learnings]
        }
    
    def reset(self) -> None:
        """Reset reflection state for new execution"""
        self.consecutive_failures = 0
        self.total_errors = 0
        self.reflections = []


__all__ = ['SelfReflector', 'ReflectionResult', 'ConfidenceCalculator', 'ReflectionTrigger']
