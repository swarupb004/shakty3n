"""
Shakty3n Modules - Cline-like IDE/Agent Features
"""
from .context_manager.context_injector import ContextInjector, ContextPruner
from .terminal_executor.exec_service import ExecService
from .editor_integration.file_indexer import FileIndexer
from .editor_integration.timeline_store import TimelineStore
from .editor_integration.diff_presenter import DiffPresenter
from .browser_automation.browser_driver import BrowserService
from .mcp_tools.mcp_manager import MCPScaffold, MCPManager
from .validator_monitor.linter_runner import LinterRunner, SecurityScanner
from .telemetry.usage_tracker import UsageTracker, TaskReporter
from .security.security_manager import SecretsDetector, PermissionPolicy
from .approval_ui.approval_queue import ApprovalQueue, DiffUI

__all__ = [
    # Context
    "ContextInjector", "ContextPruner",
    # Terminal
    "ExecService",
    # Editor
    "FileIndexer", "TimelineStore", "DiffPresenter",
    # Browser
    "BrowserService",
    # MCP
    "MCPScaffold", "MCPManager",
    # Validator
    "LinterRunner", "SecurityScanner",
    # Telemetry
    "UsageTracker", "TaskReporter",
    # Security
    "SecretsDetector", "PermissionPolicy",
    # Approval
    "ApprovalQueue", "DiffUI"
]
