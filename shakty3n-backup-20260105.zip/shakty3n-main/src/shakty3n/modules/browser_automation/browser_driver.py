import logging
import base64
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class BrowserService:
    """
    Headless browser automation using Playwright.
    """
    def __init__(self):
        self.playwright = None
        self.browser = None
        self.page = None
        self._is_active = False
        
    async def start(self):
        try:
            from playwright.async_api import async_playwright
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=True)
            self.page = await self.browser.new_page()
            self._is_active = True
            return True
        except ImportError:
            logger.error("Playwright not installed. Run `pip install playwright` and `playwright install`.")
            return False
            
    async def navigate(self, url: str) -> str:
        if not self._is_active: await self.start()
        if not self._is_active: return "Browser not available"
        
        try:
            await self.page.goto(url)
            return f"Navigated to {url}. Title: {await self.page.title()}"
        except Exception as e:
            return f"Navigation failed: {e}"

    async def click(self, selector: str) -> str:
        if not self._is_active: return "Browser not active"
        try:
            await self.page.click(selector)
            return f"Clicked {selector}"
        except Exception as e:
            return f"Click failed: {e}"

    async def screenshot(self) -> Dict[str, Any]:
        if not self._is_active: return {"error": "Browser not active"}
        try:
            path = "screenshot.png"
            await self.page.screenshot(path=path)
            # Encode for returning if needed
            return {"path": path, "success": True}
        except Exception as e:
            return {"error": str(e)}
            
    async def close(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        self._is_active = False
