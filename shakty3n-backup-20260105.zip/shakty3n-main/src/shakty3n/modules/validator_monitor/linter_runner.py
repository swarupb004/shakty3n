"""
Validator Monitor - Linter/Compiler Watchers and Security Scanning
"""
import subprocess
import os
import json
from typing import Dict, List, Optional, Any

class LinterRunner:
    """
    Run linters and compilers after file edits.
    Supports multiple languages and tools.
    """
    
    # Linter configurations by file extension
    LINTERS = {
        ".py": {
            "cmd": ["python3", "-m", "py_compile"],
            "name": "Python Syntax Check"
        },
        ".js": {
            "cmd": ["npx", "eslint", "--format", "json"],
            "name": "ESLint"
        },
        ".ts": {
            "cmd": ["npx", "tsc", "--noEmit"],
            "name": "TypeScript"
        },
        ".html": {
            "cmd": None,  # No default HTML linter
            "name": "HTML"
        }
    }
    
    def __init__(self, workspace_root: str):
        self.workspace_root = workspace_root
        self.last_results: Dict[str, Any] = {}
        
    def run_linter(self, filepath: str) -> Dict[str, Any]:
        """Run appropriate linter for a file"""
        ext = os.path.splitext(filepath)[1]
        
        if ext not in self.LINTERS or not self.LINTERS[ext]["cmd"]:
            return {"file": filepath, "status": "skipped", "errors": []}
            
        linter = self.LINTERS[ext]
        cmd = linter["cmd"] + [filepath]
        
        try:
            result = subprocess.run(
                cmd,
                cwd=self.workspace_root,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            errors = []
            if result.returncode != 0:
                errors = self._parse_errors(result.stderr or result.stdout, ext)
                
            return {
                "file": filepath,
                "linter": linter["name"],
                "status": "pass" if result.returncode == 0 else "fail",
                "errors": errors
            }
        except FileNotFoundError:
            return {"file": filepath, "status": "linter_not_found", "errors": []}
        except subprocess.TimeoutExpired:
            return {"file": filepath, "status": "timeout", "errors": []}
            
    def _parse_errors(self, output: str, ext: str) -> List[Dict]:
        """Parse linter output into structured errors"""
        errors = []
        for line in output.strip().split('\n'):
            if line:
                errors.append({"message": line})
        return errors
        
    def run_all(self, files: List[str]) -> List[Dict]:
        """Run linters on multiple files"""
        results = []
        for f in files:
            results.append(self.run_linter(f))
        return results


class SecurityScanner:
    """
    Basic security scanning for dependencies and secrets.
    """
    
    SECRET_PATTERNS = [
        r'(?i)(api[_-]?key|apikey)\s*[:=]\s*["\']?[\w-]{20,}',
        r'(?i)(secret|password|passwd|pwd)\s*[:=]\s*["\']?[\w-]{8,}',
        r'(?i)(aws|azure|gcp)[_-]?(access|secret)[_-]?(key|id)\s*[:=]',
        r'ghp_[a-zA-Z0-9]{36}',  # GitHub token
        r'sk-[a-zA-Z0-9]{48}',  # OpenAI key
    ]
    
    def __init__(self, workspace_root: str):
        self.workspace_root = workspace_root
        
    def scan_for_secrets(self, content: str, filepath: str = "") -> List[Dict]:
        """Scan content for potential secrets"""
        import re
        findings = []
        
        for i, line in enumerate(content.split('\n'), 1):
            for pattern in self.SECRET_PATTERNS:
                if re.search(pattern, line):
                    findings.append({
                        "file": filepath,
                        "line": i,
                        "type": "potential_secret",
                        "preview": line[:50] + "..." if len(line) > 50 else line
                    })
        return findings
        
    def check_dependencies(self) -> Dict[str, Any]:
        """Check for vulnerable dependencies"""
        results = {"vulnerabilities": [], "checked": False}
        
        # Check npm packages
        package_json = os.path.join(self.workspace_root, "package.json")
        if os.path.exists(package_json):
            try:
                result = subprocess.run(
                    ["npm", "audit", "--json"],
                    cwd=self.workspace_root,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                if result.stdout:
                    audit = json.loads(result.stdout)
                    results["vulnerabilities"].extend(
                        audit.get("vulnerabilities", {}).keys()
                    )
                results["checked"] = True
            except:
                pass
                
        # Check pip packages
        requirements = os.path.join(self.workspace_root, "requirements.txt")
        if os.path.exists(requirements):
            try:
                result = subprocess.run(
                    ["pip", "audit"],
                    cwd=self.workspace_root,
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                if "vulnerability" in result.stdout.lower():
                    results["vulnerabilities"].append("pip_audit_warnings")
                results["checked"] = True
            except:
                pass
                
        return results
