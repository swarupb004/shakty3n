"""
Telemetry - Token Usage and Cost Tracking
"""
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

class UsageTracker:
    """
    Track token usage and API costs per task and per request.
    """
    
    # Approximate costs per 1K tokens (USD)
    COST_PER_1K = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "ollama": {"input": 0.0, "output": 0.0},  # Local models are free
        "default": {"input": 0.001, "output": 0.002}
    }
    
    def __init__(self, storage_path: str = None):
        self.storage_path = storage_path or os.path.expanduser("~/.shakty3n/usage.json")
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        self._load()
        
    def _load(self):
        if os.path.exists(self.storage_path):
            with open(self.storage_path, 'r') as f:
                self.data = json.load(f)
        else:
            self.data = {
                "total_tokens": {"input": 0, "output": 0},
                "total_cost": 0.0,
                "sessions": [],
                "current_session": None
            }
            
    def _save(self):
        with open(self.storage_path, 'w') as f:
            json.dump(self.data, f, indent=2)
            
    def start_session(self, task_id: str, model: str = "default"):
        """Start a new tracking session"""
        self.data["current_session"] = {
            "task_id": task_id,
            "model": model,
            "started": datetime.now().isoformat(),
            "requests": [],
            "total_tokens": {"input": 0, "output": 0},
            "total_cost": 0.0
        }
        
    def log_request(self, input_tokens: int, output_tokens: int, model: str = None):
        """Log a single API request"""
        if not self.data["current_session"]:
            self.start_session("unknown")
            
        session = self.data["current_session"]
        model = model or session.get("model", "default")
        
        # Calculate cost
        rates = self.COST_PER_1K.get(model, self.COST_PER_1K["default"])
        cost = (input_tokens / 1000 * rates["input"]) + (output_tokens / 1000 * rates["output"])
        
        request = {
            "timestamp": datetime.now().isoformat(),
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cost": cost
        }
        
        session["requests"].append(request)
        session["total_tokens"]["input"] += input_tokens
        session["total_tokens"]["output"] += output_tokens
        session["total_cost"] += cost
        
        # Update globals
        self.data["total_tokens"]["input"] += input_tokens
        self.data["total_tokens"]["output"] += output_tokens
        self.data["total_cost"] += cost
        
        self._save()
        
    def end_session(self) -> Dict:
        """End current session and return summary"""
        if self.data["current_session"]:
            session = self.data["current_session"]
            session["ended"] = datetime.now().isoformat()
            self.data["sessions"].append(session)
            self.data["current_session"] = None
            self._save()
            return session
        return {}
        
    def get_summary(self) -> Dict:
        """Get overall usage summary"""
        return {
            "total_tokens": self.data["total_tokens"],
            "total_cost": f"${self.data['total_cost']:.4f}",
            "session_count": len(self.data["sessions"]),
            "current_session": self.data["current_session"]
        }


class TaskReporter:
    """
    Generate final reports for completed tasks.
    """
    
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self.reports_dir = os.path.join(output_dir, ".shakty3n", "reports")
        os.makedirs(self.reports_dir, exist_ok=True)
        
    def generate_report(self, task_id: str, task_result: Dict, 
                       usage_data: Dict = None,
                       screenshots: List[str] = None,
                       logs: List[str] = None) -> str:
        """Generate a comprehensive task report"""
        
        report = {
            "task_id": task_id,
            "generated_at": datetime.now().isoformat(),
            "result": task_result,
            "usage": usage_data or {},
            "artifacts": {
                "screenshots": screenshots or [],
                "logs": logs or []
            }
        }
        
        report_path = os.path.join(self.reports_dir, f"{task_id}.json")
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
            
        # Also generate markdown summary
        md_path = os.path.join(self.reports_dir, f"{task_id}.md")
        with open(md_path, 'w') as f:
            f.write(f"# Task Report: {task_id}\n\n")
            f.write(f"**Generated:** {report['generated_at']}\n\n")
            f.write(f"## Result\n```json\n{json.dumps(task_result, indent=2)}\n```\n\n")
            if usage_data:
                f.write(f"## Usage\n")
                f.write(f"- Tokens: {usage_data.get('total_tokens', {})}\n")
                f.write(f"- Cost: {usage_data.get('total_cost', 'N/A')}\n\n")
                
        return report_path
