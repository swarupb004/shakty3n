"""
Timeline Store - Checkpoint/Snapshot Management
Provides per-file history tracking and workspace restore capabilities.
"""
import os
import json
import shutil
import hashlib
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path

class TimelineStore:
    """
    Manages checkpoints (snapshots) for workspace files.
    Supports create, compare, and restore operations.
    """
    
    def __init__(self, workspace_root: str):
        self.workspace_root = workspace_root
        self.checkpoints_dir = os.path.join(workspace_root, ".shakty3n", "checkpoints")
        os.makedirs(self.checkpoints_dir, exist_ok=True)
        self.metadata_file = os.path.join(self.checkpoints_dir, "metadata.json")
        self._load_metadata()
        
    def _load_metadata(self):
        if os.path.exists(self.metadata_file):
            with open(self.metadata_file, 'r') as f:
                self.metadata = json.load(f)
        else:
            self.metadata = {"checkpoints": [], "current_index": -1}
            
    def _save_metadata(self):
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)
            
    def create_checkpoint(self, message: str = "", task_id: str = "") -> str:
        """
        Create a new checkpoint of the current workspace state.
        Returns checkpoint ID.
        """
        checkpoint_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        checkpoint_path = os.path.join(self.checkpoints_dir, checkpoint_id)
        os.makedirs(checkpoint_path, exist_ok=True)
        
        # Snapshot all workspace files (excluding heavy dirs)
        ignore_patterns = ['node_modules', '.git', '__pycache__', 'venv', '.shakty3n']
        files_snapshot = {}
        
        for root, dirs, files in os.walk(self.workspace_root):
            dirs[:] = [d for d in dirs if d not in ignore_patterns]
            for file in files:
                abs_path = os.path.join(root, file)
                rel_path = os.path.relpath(abs_path, self.workspace_root)
                
                try:
                    with open(abs_path, 'rb') as f:
                        content = f.read()
                    
                    # Store file content
                    file_hash = hashlib.md5(content).hexdigest()
                    content_file = os.path.join(checkpoint_path, f"{file_hash}.bin")
                    
                    if not os.path.exists(content_file):
                        with open(content_file, 'wb') as f:
                            f.write(content)
                    
                    files_snapshot[rel_path] = {
                        "hash": file_hash,
                        "size": len(content)
                    }
                except:
                    continue
                    
        # Save manifest
        manifest = {
            "id": checkpoint_id,
            "message": message,
            "task_id": task_id,
            "timestamp": datetime.now().isoformat(),
            "files": files_snapshot
        }
        
        with open(os.path.join(checkpoint_path, "manifest.json"), 'w') as f:
            json.dump(manifest, f, indent=2)
            
        self.metadata["checkpoints"].append({
            "id": checkpoint_id,
            "message": message,
            "timestamp": manifest["timestamp"]
        })
        self.metadata["current_index"] = len(self.metadata["checkpoints"]) - 1
        self._save_metadata()
        
        return checkpoint_id
        
    def list_checkpoints(self) -> List[Dict]:
        """List all available checkpoints"""
        return self.metadata["checkpoints"]
        
    def restore_checkpoint(self, checkpoint_id: str) -> bool:
        """
        Restore workspace to a specific checkpoint.
        Returns True if successful.
        """
        checkpoint_path = os.path.join(self.checkpoints_dir, checkpoint_id)
        manifest_path = os.path.join(checkpoint_path, "manifest.json")
        
        if not os.path.exists(manifest_path):
            return False
            
        with open(manifest_path, 'r') as f:
            manifest = json.load(f)
            
        # Restore each file
        for rel_path, info in manifest["files"].items():
            abs_path = os.path.join(self.workspace_root, rel_path)
            content_file = os.path.join(checkpoint_path, f"{info['hash']}.bin")
            
            if os.path.exists(content_file):
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                shutil.copy2(content_file, abs_path)
                
        return True
        
    def compare_checkpoints(self, id1: str, id2: str) -> Dict[str, Any]:
        """Compare two checkpoints and return diff summary"""
        path1 = os.path.join(self.checkpoints_dir, id1, "manifest.json")
        path2 = os.path.join(self.checkpoints_dir, id2, "manifest.json")
        
        with open(path1) as f:
            m1 = json.load(f)
        with open(path2) as f:
            m2 = json.load(f)
            
        files1 = set(m1["files"].keys())
        files2 = set(m2["files"].keys())
        
        added = files2 - files1
        removed = files1 - files2
        modified = [f for f in files1 & files2 if m1["files"][f]["hash"] != m2["files"][f]["hash"]]
        
        return {
            "added": list(added),
            "removed": list(removed),
            "modified": modified
        }
