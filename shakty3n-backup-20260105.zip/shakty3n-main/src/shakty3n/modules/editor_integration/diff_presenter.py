"""
Diff Presenter - Unified Diff Generation and JSON Patch APIs
"""
import difflib
import json
from typing import Dict, List, Optional, Any

class DiffPresenter:
    """
    Generates unified diffs and JSON patches for file changes.
    Supports human-readable and machine-parseable formats.
    """
    
    def __init__(self):
        self.pending_changes: List[Dict] = []
        
    def generate_unified_diff(self, old_content: str, new_content: str, 
                               filename: str = "file") -> str:
        """Generate unified diff format"""
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}"
        )
        return ''.join(diff)
        
    def generate_json_patch(self, old_content: str, new_content: str) -> List[Dict]:
        """Generate JSON patch format (RFC 6902 style)"""
        old_lines = old_content.splitlines()
        new_lines = new_content.splitlines()
        
        patches = []
        matcher = difflib.SequenceMatcher(None, old_lines, new_lines)
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'replace':
                patches.append({
                    "op": "replace",
                    "lines": f"{i1+1}-{i2}",
                    "old": old_lines[i1:i2],
                    "new": new_lines[j1:j2]
                })
            elif tag == 'delete':
                patches.append({
                    "op": "remove",
                    "lines": f"{i1+1}-{i2}",
                    "content": old_lines[i1:i2]
                })
            elif tag == 'insert':
                patches.append({
                    "op": "add",
                    "after_line": i1,
                    "content": new_lines[j1:j2]
                })
        return patches
        
    def queue_change(self, filepath: str, old_content: str, new_content: str,
                     description: str = "") -> str:
        """
        Queue a change for human approval.
        Returns change ID.
        """
        change_id = f"change_{len(self.pending_changes)}"
        
        self.pending_changes.append({
            "id": change_id,
            "filepath": filepath,
            "old_content": old_content,
            "new_content": new_content,
            "diff": self.generate_unified_diff(old_content, new_content, filepath),
            "description": description,
            "status": "pending"  # pending, approved, rejected
        })
        return change_id
        
    def get_pending_changes(self) -> List[Dict]:
        """Get all pending changes awaiting approval"""
        return [c for c in self.pending_changes if c["status"] == "pending"]
        
    def approve_change(self, change_id: str) -> bool:
        """Approve a pending change"""
        for change in self.pending_changes:
            if change["id"] == change_id:
                change["status"] = "approved"
                return True
        return False
        
    def reject_change(self, change_id: str) -> bool:
        """Reject a pending change"""
        for change in self.pending_changes:
            if change["id"] == change_id:
                change["status"] = "rejected"
                return True
        return False
        
    def apply_approved_changes(self) -> List[str]:
        """Apply all approved changes to filesystem"""
        applied = []
        for change in self.pending_changes:
            if change["status"] == "approved":
                try:
                    with open(change["filepath"], 'w') as f:
                        f.write(change["new_content"])
                    applied.append(change["filepath"])
                except Exception as e:
                    pass
        return applied
