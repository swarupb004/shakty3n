import os
import re
from typing import List, Dict

class FileIndexer:
    """
    Indexes workspace files for fast searching and analysis.
    """
    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self.ignore_patterns = [
            'node_modules', '.git', '__pycache__', 'venv', '.env', 
            'dist', 'build', '.DS_Store'
        ]
        
    def get_file_tree(self) -> List[str]:
        """Get recursive file list"""
        files_list = []
        for root, dirs, files in os.walk(self.root_dir):
            # Prune ignored dirs
            dirs[:] = [d for d in dirs if d not in self.ignore_patterns]
            
            for file in files:
                if any(file.endswith(ext) for ext in ['.pyc', '.o']):
                    continue
                path = os.path.relpath(os.path.join(root, file), self.root_dir)
                files_list.append(path)
        return files_list
        
    def search_content(self, query: str, regex: bool = False) -> List[Dict]:
        """Search file contents"""
        results = []
        pattern = re.compile(query) if regex else None
        
        for filepath in self.get_file_tree():
            abs_path = os.path.join(self.root_dir, filepath)
            try:
                with open(abs_path, 'r', errors='ignore') as f:
                    for i, line in enumerate(f, 1):
                        if regex:
                            if pattern.search(line):
                                results.append({"file": filepath, "line": i, "content": line.strip()})
                        else:
                            if query in line:
                                results.append({"file": filepath, "line": i, "content": line.strip()})
            except:
                continue
        return results
