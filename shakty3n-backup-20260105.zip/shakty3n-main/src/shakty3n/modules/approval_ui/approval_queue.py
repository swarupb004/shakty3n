"""
Approval UI - Diff Review and Command Approval APIs
"""
import os
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

@dataclass
class PendingAction:
    """Represents an action awaiting approval"""
    id: str
    action_type: str  # file_write, terminal_command, browser_action
    description: str
    details: Dict
    created_at: str
    status: str = "pending"  # pending, approved, rejected
    cost_estimate: Optional[float] = None
    token_estimate: Optional[int] = None

class ApprovalQueue:
    """
    Manages the queue of pending actions for human approval.
    Provides APIs for the frontend to display and interact.
    """
    
    def __init__(self, storage_dir: str = None):
        self.storage_dir = storage_dir or os.path.expanduser("~/.shakty3n/approvals")
        os.makedirs(self.storage_dir, exist_ok=True)
        self.pending: Dict[str, PendingAction] = {}
        self._load()
        
    def _load(self):
        queue_file = os.path.join(self.storage_dir, "queue.json")
        if os.path.exists(queue_file):
            with open(queue_file, 'r') as f:
                data = json.load(f)
                for item in data:
                    self.pending[item["id"]] = PendingAction(**item)
                    
    def _save(self):
        queue_file = os.path.join(self.storage_dir, "queue.json")
        with open(queue_file, 'w') as f:
            json.dump([asdict(a) for a in self.pending.values()], f, indent=2)
            
    def queue_file_change(self, filepath: str, old_content: str, 
                          new_content: str, diff: str) -> str:
        """Queue a file change for approval"""
        action_id = f"file_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        
        action = PendingAction(
            id=action_id,
            action_type="file_write",
            description=f"Write to {filepath}",
            details={
                "filepath": filepath,
                "old_content": old_content[:500] if old_content else None,
                "new_content": new_content[:500],
                "diff": diff,
                "lines_changed": diff.count('\n')
            },
            created_at=datetime.now().isoformat()
        )
        
        self.pending[action_id] = action
        self._save()
        return action_id
        
    def queue_command(self, command: str, reason: str = "") -> str:
        """Queue a terminal command for approval"""
        action_id = f"cmd_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
        
        action = PendingAction(
            id=action_id,
            action_type="terminal_command",
            description=f"Execute: {command[:50]}...",
            details={
                "command": command,
                "reason": reason
            },
            created_at=datetime.now().isoformat()
        )
        
        self.pending[action_id] = action
        self._save()
        return action_id
        
    def get_pending(self) -> List[Dict]:
        """Get all pending actions"""
        return [asdict(a) for a in self.pending.values() if a.status == "pending"]
        
    def approve(self, action_id: str) -> bool:
        """Approve an action"""
        if action_id in self.pending:
            self.pending[action_id].status = "approved"
            self._save()
            return True
        return False
        
    def reject(self, action_id: str) -> bool:
        """Reject an action"""
        if action_id in self.pending:
            self.pending[action_id].status = "rejected"
            self._save()
            return True
        return False
        
    def approve_all(self) -> int:
        """Approve all pending actions"""
        count = 0
        for action in self.pending.values():
            if action.status == "pending":
                action.status = "approved"
                count += 1
        self._save()
        return count
        
    def get_approved(self) -> List[Dict]:
        """Get all approved actions ready to execute"""
        return [asdict(a) for a in self.pending.values() if a.status == "approved"]
        
    def clear_completed(self):
        """Remove completed (approved/rejected) actions"""
        self.pending = {k: v for k, v in self.pending.items() if v.status == "pending"}
        self._save()


class DiffUI:
    """
    Generate diff visualization for frontend display.
    """
    
    def format_for_display(self, diff: str) -> Dict:
        """Format diff for frontend rendering"""
        lines = []
        for line in diff.split('\n'):
            if line.startswith('+++') or line.startswith('---'):
                lines.append({"type": "header", "content": line})
            elif line.startswith('+'):
                lines.append({"type": "add", "content": line[1:]})
            elif line.startswith('-'):
                lines.append({"type": "remove", "content": line[1:]})
            elif line.startswith('@@'):
                lines.append({"type": "hunk", "content": line})
            else:
                lines.append({"type": "context", "content": line})
                
        return {
            "lines": lines,
            "stats": {
                "additions": len([l for l in lines if l["type"] == "add"]),
                "deletions": len([l for l in lines if l["type"] == "remove"])
            }
        }
