import subprocess
import threading
import time
import os
import signal
from typing import Dict, Any, Optional, List

class ExecService:
    """
    Handles shell command execution with support for streaming output
    and background processes.
    """
    
    def __init__(self, work_dir: str):
        self.work_dir = work_dir
        self.background_processes: Dict[str, subprocess.Popen] = {}
        self.process_outputs: Dict[str, List[str]] = {}
        
    def run_command(self, command: str, background: bool = False, timeout: int = 30) -> Dict[str, Any]:
        """
        Run a shell command.
        
        Args:
            command: The shell command
            background: If True, returns immediately with process ID (Proceed While Running)
            timeout: Timeout for synchronous commands
        """
        try:
            if background:
                return self._start_background_process(command)
            else:
                return self._run_foreground(command, timeout)
        except Exception as e:
            return {"success": False, "error": str(e), "output": ""}

    def _run_foreground(self, command: str, timeout: int) -> Dict[str, Any]:
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.work_dir,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return {
                "success": result.returncode == 0,
                "output": result.stdout + result.stderr,
                "returncode": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Command timed out", "output": ""}

    def _start_background_process(self, command: str) -> Dict[str, Any]:
        process_id = f"proc_{int(time.time()*1000)}"
        
        process = subprocess.Popen(
            command,
            shell=True,
            cwd=self.work_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            preexec_fn=os.setsid  # New session for easier kill
        )
        
        self.background_processes[process_id] = process
        self.process_outputs[process_id] = []
        
        # Start monitoring thread
        t = threading.Thread(target=self._monitor_process, args=(process_id, process))
        t.daemon = True
        t.start()
        
        return {
            "success": True,
            "background": True,
            "process_id": process_id,
            "message": f"Process started in background. ID: {process_id}"
        }

    def _monitor_process(self, pid: str, process: subprocess.Popen):
        """Read output stream"""
        for line in iter(process.stdout.readline, ''):
            self.process_outputs[pid].append(line)
        process.stdout.close()

    def get_process_output(self, pid: str, lines: int = 50) -> str:
        """Get recent output from a background process"""
        if pid not in self.process_outputs:
            return "Process not found"
        return "".join(self.process_outputs[pid][-lines:])

    def kill_process(self, pid: str):
        if pid in self.background_processes:
            proc = self.background_processes[pid]
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except:
                proc.terminate()
            del self.background_processes[pid]
            return True
        return False
