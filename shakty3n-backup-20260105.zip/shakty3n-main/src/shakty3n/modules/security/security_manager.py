"""
Security Module - Secrets Detection and Permission Policy
"""
import re
import os
import json
from typing import Dict, List, Optional, Any

class SecretsDetector:
    """
    Scan diffs and files for accidental secrets before committing.
    """
    
    PATTERNS = [
        # API Keys
        (r'(?i)(api[_-]?key|apikey)\s*[:=]\s*["\']?([a-zA-Z0-9_\-]{20,})', "API Key"),
        (r'sk-[a-zA-Z0-9]{48,}', "OpenAI API Key"),
        (r'ghp_[a-zA-Z0-9]{36}', "GitHub Personal Access Token"),
        (r'gho_[a-zA-Z0-9]{36}', "GitHub OAuth Token"),
        (r'github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}', "GitHub Fine-grained PAT"),
        
        # Cloud Providers
        (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID"),
        (r'(?i)aws[_-]?secret[_-]?access[_-]?key\s*[:=]\s*["\']?([a-zA-Z0-9+/]{40})', "AWS Secret Key"),
        (r'(?i)(azure|az)[_-]?(client|tenant|subscription)[_-]?(id|secret)', "Azure Credential"),
        
        # Database
        (r'(?i)(password|passwd|pwd)\s*[:=]\s*["\']?([^\s"\']{8,})', "Password"),
        (r'(?i)mongodb(\+srv)?://[^\s]+', "MongoDB URI"),
        (r'(?i)postgres(ql)?://[^\s]+', "PostgreSQL URI"),
        
        # Private Keys
        (r'-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----', "Private Key"),
        (r'-----BEGIN PGP PRIVATE KEY BLOCK-----', "PGP Private Key"),
    ]
    
    def __init__(self):
        self.findings: List[Dict] = []
        
    def scan_content(self, content: str, source: str = "unknown") -> List[Dict]:
        """Scan content for secrets"""
        findings = []
        
        for line_num, line in enumerate(content.split('\n'), 1):
            for pattern, secret_type in self.PATTERNS:
                if re.search(pattern, line):
                    findings.append({
                        "type": secret_type,
                        "source": source,
                        "line": line_num,
                        "severity": "high",
                        "preview": self._mask_secret(line)
                    })
                    
        self.findings.extend(findings)
        return findings
        
    def scan_diff(self, diff: str, filepath: str = "") -> List[Dict]:
        """Scan a unified diff for secrets in added lines"""
        findings = []
        
        for line in diff.split('\n'):
            if line.startswith('+') and not line.startswith('+++'):
                added_content = line[1:]
                for pattern, secret_type in self.PATTERNS:
                    if re.search(pattern, added_content):
                        findings.append({
                            "type": secret_type,
                            "source": filepath,
                            "in_diff": True,
                            "severity": "critical",
                            "preview": self._mask_secret(added_content)
                        })
                        
        return findings
        
    def _mask_secret(self, line: str, show_chars: int = 4) -> str:
        """Mask sensitive parts of a line"""
        # Simple masking - show first few chars then ****
        if len(line) > 20:
            return line[:show_chars] + "****" + line[-show_chars:]
        return "****"
        
    def get_summary(self) -> Dict:
        """Get summary of all findings"""
        return {
            "total_findings": len(self.findings),
            "by_type": self._group_by_type(),
            "critical": len([f for f in self.findings if f.get("severity") == "critical"])
        }
        
    def _group_by_type(self) -> Dict[str, int]:
        groups = {}
        for f in self.findings:
            t = f["type"]
            groups[t] = groups.get(t, 0) + 1
        return groups


class PermissionPolicy:
    """
    Manage auto-approval rules and required approvals for actions.
    """
    
    DEFAULT_POLICY = {
        "auto_approve": {
            "file_read": True,
            "file_write": False,
            "terminal_read_only": True,
            "terminal_execute": False,
            "browser_navigate": True,
            "browser_interact": False,
        },
        "always_require_approval": [
            "rm -rf",
            "sudo",
            "chmod 777",
            "curl | bash",
            "wget | bash"
        ],
        "whitelisted_commands": [
            "npm install",
            "pip install",
            "git status",
            "git diff",
            "ls",
            "cat",
            "pwd"
        ]
    }
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or os.path.expanduser("~/.shakty3n/permissions.json")
        self._load()
        
    def _load(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                self.policy = json.load(f)
        else:
            self.policy = self.DEFAULT_POLICY
            self._save()
            
    def _save(self):
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(self.policy, f, indent=2)
            
    def check_action(self, action_type: str, details: str = "") -> Dict:
        """
        Check if an action is allowed.
        Returns: {allowed: bool, requires_approval: bool, reason: str}
        """
        # Check blacklist first
        for blocked in self.policy.get("always_require_approval", []):
            if blocked in details.lower():
                return {
                    "allowed": True,
                    "requires_approval": True,
                    "reason": f"Command matches blocked pattern: {blocked}"
                }
                
        # Check auto-approve rules
        auto_approve = self.policy.get("auto_approve", {})
        if action_type in auto_approve:
            if auto_approve[action_type]:
                return {"allowed": True, "requires_approval": False, "reason": "Auto-approved by policy"}
            else:
                return {"allowed": True, "requires_approval": True, "reason": "Requires manual approval"}
                
        # Check whitelist for commands
        if action_type == "terminal_execute":
            for whitelisted in self.policy.get("whitelisted_commands", []):
                if details.strip().startswith(whitelisted):
                    return {"allowed": True, "requires_approval": False, "reason": "Whitelisted command"}
                    
        # Default: require approval
        return {"allowed": True, "requires_approval": True, "reason": "Default policy"}
        
    def update_policy(self, updates: Dict) -> bool:
        """Update policy configuration"""
        self.policy.update(updates)
        self._save()
        return True
