import os
import re
from typing import List, Dict, Any, Optional
import glob

class ContextInjector:
    """
    Handles interpolation of context markers like @file, @folder, @url in prompts.
    """
    
    def __init__(self, workspace_root: str):
        self.workspace_root = workspace_root
        
    def parse_and_inject(self, prompt: str) -> Dict[str, Any]:
        """
        Parse prompt for context markers and inject content.
        Returns:
            Dict containing:
            - 'processed_prompt': The prompt with markers replaced (or stripped)
            - 'context_files': List of files loaded
            - 'context_content': Actual content blocks to append
        """
        processed_prompt = prompt
        context_files = []
        context_content = []
        
        # Match @file:path/to/file or @file("path/to/file")
        # Simple regex for now
        file_matches = re.finditer(r'@file(?::|\s+)(["\']?)([^"\s\']+)\1', prompt)
        
        for match in file_matches:
            marker = match.group(0)
            filepath = match.group(2)
            
            # Resolve path
            abs_path = os.path.join(self.workspace_root, filepath)
            
            if os.path.exists(abs_path) and os.path.isfile(abs_path):
                try:
                    with open(abs_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    context_files.append(abs_path)
                    
                    # Add to context content block
                    block = f"\n--- Start of Context: {filepath} ---\n{content}\n--- End of Context ---\n"
                    context_content.append(block)
                    
                    # Remove marker from prompt to avoid duplication if we append full content later
                    # Or keep it as a reference? Cline usually replaces it or appends.
                    # We'll replace with a reference note.
                    processed_prompt = processed_prompt.replace(marker, f"[Context Loaded: {filepath}]")
                    
                except Exception as e:
                    processed_prompt = processed_prompt.replace(marker, f"[Error processing {filepath}: {e}]")
            else:
                processed_prompt = processed_prompt.replace(marker, f"[File not found: {filepath}]")
                
        return {
            "processed_prompt": processed_prompt + "\n" + "\n".join(context_content),
            "files": context_files
        }

class ContextPruner:
    """
    Manages token limits for context window.
    """
    def __init__(self, max_tokens: int = 100000):
        self.max_tokens = max_tokens
        
    def prune(self, content: str) -> str:
        # Basic character limit for now (approx 4 chars/token)
        limit_chars = self.max_tokens * 4
        if len(content) > limit_chars:
            return content[:limit_chars] + "\n...[Context Truncated]..."
        return content
