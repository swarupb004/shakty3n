"""
Tests for the Architecture Analyzer module
"""
import sys
import os
import pytest
import tempfile
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from shakty3n.reflection.architecture_analyzer import (
    ArchitectureAnalyzer,
    ArchitectureIssue,
    IssueType,
    Severity,
    PythonAnalyzer,
    THRESHOLDS
)


class TestPythonAnalyzer:
    """Tests for Python AST analyzer"""
    
    def test_detect_long_function(self):
        """Test detection of long functions"""
        # Create a function with many lines
        lines = ["def long_function():"]
        lines.extend([f"    x = {i}" for i in range(60)])
        lines.append("    return x")
        
        source = "\n".join(lines)
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        long_func_issues = [i for i in analyzer.issues 
                          if "long function" in i.title.lower()]
        assert len(long_func_issues) >= 1
    
    def test_detect_too_many_parameters(self):
        """Test detection of functions with too many parameters"""
        source = """
def too_many_params(a, b, c, d, e, f, g, h):
    return a + b + c + d + e + f + g + h
"""
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        param_issues = [i for i in analyzer.issues 
                       if "parameter" in i.title.lower()]
        assert len(param_issues) >= 1
    
    def test_detect_missing_docstring(self):
        """Test detection of missing docstrings"""
        source = """
def public_function():
    return 42

def _private_function():
    return 0
"""
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        # Should flag public function, not private
        docstring_issues = [i for i in analyzer.issues 
                          if "docstring" in i.title.lower()]
        assert len(docstring_issues) >= 1
        assert any("public_function" in i.description for i in docstring_issues)
    
    def test_detect_bare_except(self):
        """Test detection of bare except clauses"""
        source = """
def risky():
    try:
        something()
    except:
        pass
"""
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        except_issues = [i for i in analyzer.issues 
                        if "bare except" in i.title.lower()]
        assert len(except_issues) >= 1
    
    def test_detect_global_usage(self):
        """Test detection of global variable usage"""
        source = """
counter = 0

def increment():
    global counter
    counter += 1
"""
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        global_issues = [i for i in analyzer.issues 
                        if "global" in i.title.lower()]
        assert len(global_issues) >= 1
    
    def test_detect_deep_nesting(self):
        """Test detection of deeply nested code"""
        source = """
def deeply_nested(x):
    if x > 0:
        if x > 10:
            if x > 100:
                if x > 1000:
                    if x > 10000:
                        return True
    return False
"""
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        nesting_issues = [i for i in analyzer.issues 
                         if "nesting" in i.title.lower()]
        assert len(nesting_issues) >= 1
    
    def test_handle_syntax_error(self):
        """Test handling of files with syntax errors"""
        source = "def broken("
        
        analyzer = PythonAnalyzer("test.py", source)
        analyzer.analyze()
        
        syntax_issues = [i for i in analyzer.issues 
                        if "syntax" in i.title.lower()]
        assert len(syntax_issues) >= 1


class TestArchitectureAnalyzer:
    """Tests for the main ArchitectureAnalyzer class"""
    
    def test_analyze_empty_directory(self):
        """Test analyzing an empty directory"""
        with tempfile.TemporaryDirectory() as temp_dir:
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            assert results["files_analyzed"] == 0
            # May have project-level issues (missing README, etc)
            assert "total_issues" in results
    
    def test_analyze_nonexistent_directory(self):
        """Test analyzing a nonexistent directory"""
        analyzer = ArchitectureAnalyzer()
        results = analyzer.analyze_project("/nonexistent/path")
        
        assert "error" in results
    
    def test_analyze_python_file(self):
        """Test analyzing a Python file"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create a test Python file
            test_file = Path(temp_dir) / "test.py"
            test_file.write_text("""
# Test file
def good_function():
    '''This has a docstring'''
    return 42
""")
            
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            assert results["files_analyzed"] >= 1
            assert "score" in results
    
    def test_detect_hardcoded_secrets(self):
        """Test detection of hardcoded secrets"""
        with tempfile.TemporaryDirectory() as temp_dir:
            test_file = Path(temp_dir) / "config.py"
            test_file.write_text("""
password = "supersecret123"
api_key = "abc123xyz"
""")
            
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            security_issues = [i for i in results.get("issues", [])
                              if i.get("issue_type") == "security"]
            assert len(security_issues) >= 1
    
    def test_detect_print_statements(self):
        """Test detection of print statements in non-test files"""
        with tempfile.TemporaryDirectory() as temp_dir:
            test_file = Path(temp_dir) / "main.py"
            test_file.write_text("""
def process():
    print("Debug output")
    return 42
""")
            
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            print_issues = [i for i in results.get("issues", [])
                           if "print" in i.get("title", "").lower()]
            assert len(print_issues) >= 1
    
    def test_ignore_node_modules(self):
        """Test that node_modules is ignored"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create node_modules directory with a file
            node_modules = Path(temp_dir) / "node_modules"
            node_modules.mkdir()
            
            test_file = node_modules / "bad_code.js"
            test_file.write_text("var x = 1;")
            
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            # Should not analyze files in node_modules
            # No JS issues should be found
            js_issues = [i for i in results.get("issues", [])
                        if "node_modules" in i.get("file_path", "")]
            assert len(js_issues) == 0
    
    def test_score_calculation(self):
        """Test health score calculation"""
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create a clean file
            test_file = Path(temp_dir) / "clean.py"
            test_file.write_text('''
"""Module docstring"""

def good_function():
    """Function docstring"""
    return 42
''')
            
            # Also create README to avoid project-level issues
            readme = Path(temp_dir) / "README.md"
            readme.write_text("# Test Project")
            
            gitignore = Path(temp_dir) / ".gitignore"
            gitignore.write_text("*.pyc")
            
            tests_dir = Path(temp_dir) / "tests"
            tests_dir.mkdir()
            (tests_dir / "test_clean.py").write_text("def test_pass(): pass")
            
            analyzer = ArchitectureAnalyzer()
            results = analyzer.analyze_project(temp_dir)
            
            # Score should be relatively high for clean code
            assert results["score"] >= 80
    
    def test_get_report(self):
        """Test human-readable report generation"""
        with tempfile.TemporaryDirectory() as temp_dir:
            analyzer = ArchitectureAnalyzer()
            analyzer.analyze_project(temp_dir)
            
            report = analyzer.get_report()
            
            assert "ARCHITECTURE ANALYSIS REPORT" in report
            assert "Health Score" in report


class TestIssueTypes:
    """Tests for issue type categorization"""
    
    def test_issue_to_dict(self):
        """Test issue serialization"""
        issue = ArchitectureIssue(
            issue_type=IssueType.CODE_SMELL,
            severity=Severity.MEDIUM,
            title="Test Issue",
            description="Test description",
            file_path="test.py",
            line_number=10,
            recommendation="Fix it"
        )
        
        d = issue.to_dict()
        
        assert d["issue_type"] == "code_smell"
        assert d["severity"] == "medium"
        assert d["title"] == "Test Issue"
        assert d["line_number"] == 10
    
    def test_all_issue_types_defined(self):
        """Verify all expected issue types exist"""
        expected_types = [
            "code_smell", "anti_pattern", "performance",
            "security", "maintainability", "testability",
            "complexity", "duplication"
        ]
        
        actual_types = [t.value for t in IssueType]
        
        for expected in expected_types:
            assert expected in actual_types


class TestThresholds:
    """Tests for configurable thresholds"""
    
    def test_thresholds_are_reasonable(self):
        """Verify threshold values are reasonable"""
        assert THRESHOLDS["max_function_lines"] > 10
        assert THRESHOLDS["max_function_lines"] < 200
        
        assert THRESHOLDS["max_parameters"] >= 3
        assert THRESHOLDS["max_parameters"] <= 10
        
        assert THRESHOLDS["max_complexity"] >= 5
        assert THRESHOLDS["max_complexity"] <= 25


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
