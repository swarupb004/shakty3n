"""
Tests for the Self-Healer module
"""
import sys
import os
import pytest
import tempfile
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from shakty3n.debugger.self_healer import (
    SelfHealer, 
    ErrorAnalysis, 
    ErrorCategory,
    HealingAttempt,
    ERROR_PATTERNS
)


class TestErrorAnalysis:
    """Tests for error analysis functionality"""
    
    def test_analyze_syntax_error(self):
        """Test analysis of syntax errors"""
        healer = SelfHealer()
        
        try:
            exec("def broken(")
        except SyntaxError as e:
            analysis = healer.analyze_error(e)
            
            assert analysis.category == ErrorCategory.SYNTAX_ERROR
            assert analysis.confidence > 0
            assert len(analysis.suggested_fixes) >= 0
    
    def test_analyze_name_error(self):
        """Test analysis of name errors"""
        healer = SelfHealer()
        
        try:
            eval("undefined_variable")
        except NameError as e:
            analysis = healer.analyze_error(e)
            
            assert analysis.category == ErrorCategory.NAME_ERROR
            assert "undefined_variable" in analysis.message
    
    def test_analyze_import_error(self):
        """Test analysis of import errors"""
        healer = SelfHealer()
        
        try:
            import nonexistent_module_xyz123
        except ModuleNotFoundError as e:
            analysis = healer.analyze_error(e)
            
            assert analysis.category == ErrorCategory.IMPORT_ERROR
    
    def test_analyze_type_error(self):
        """Test analysis of type errors"""
        healer = SelfHealer()
        
        try:
            "string"()  # TypeError: 'str' object is not callable
        except TypeError as e:
            analysis = healer.analyze_error(e)
            
            assert analysis.category == ErrorCategory.TYPE_ERROR
    
    def test_analyze_with_context(self):
        """Test analysis with additional context"""
        healer = SelfHealer()
        
        try:
            1 / 0
        except ZeroDivisionError as e:
            context = {"file": "test.py", "function": "divide"}
            analysis = healer.analyze_error(e, context)
            
            # Should still produce an analysis even for unknown error types
            assert analysis.message is not None


class TestPatternFixGeneration:
    """Tests for pattern-based fix generation"""
    
    def test_generate_pattern_fix_with_code(self):
        """Test pattern fix generation with code snippet"""
        healer = SelfHealer()
        
        analysis = ErrorAnalysis(
            category=ErrorCategory.SYNTAX_ERROR,
            message="SyntaxError: invalid syntax",
            code_snippet="if True\n    print('hello')"
        )
        
        # Should attempt to generate a fix based on patterns
        fix = healer._generate_pattern_fix(analysis)
        # May or may not find a fix depending on patterns
        # Just verify no exception is raised
        assert fix is None or isinstance(fix, str)
    
    def test_generate_pattern_fix_without_code(self):
        """Test pattern fix generation without code snippet"""
        healer = SelfHealer()
        
        analysis = ErrorAnalysis(
            category=ErrorCategory.SYNTAX_ERROR,
            message="SyntaxError: invalid syntax",
            code_snippet=None
        )
        
        fix = healer._generate_pattern_fix(analysis)
        assert fix is None  # Can't fix without code


class TestFileOperations:
    """Tests for file backup and rollback"""
    
    def test_apply_fix_and_rollback(self):
        """Test applying a fix and rolling back"""
        healer = SelfHealer()
        
        # Create a temporary file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
            f.write("original content")
            temp_path = f.name
        
        try:
            # Apply a fix
            success = healer.apply_fix(temp_path, "fixed content")
            assert success
            
            # Verify fix was applied
            with open(temp_path, 'r') as f:
                assert f.read() == "fixed content"
            
            # Rollback
            rolled_back = healer.rollback(temp_path)
            assert rolled_back
            
            # Verify rollback worked
            with open(temp_path, 'r') as f:
                assert f.read() == "original content"
        finally:
            os.unlink(temp_path)
    
    def test_apply_fix_nonexistent_file(self):
        """Test applying fix to nonexistent file"""
        healer = SelfHealer()
        success = healer.apply_fix("/nonexistent/path/file.py", "content")
        assert not success
    
    def test_rollback_without_backup(self):
        """Test rolling back without a backup"""
        healer = SelfHealer()
        result = healer.rollback("/some/path/file.py")
        assert not result


class TestHealingHistory:
    """Tests for healing history tracking"""
    
    def test_healing_summary_empty(self):
        """Test summary with no healing attempts"""
        healer = SelfHealer()
        summary = healer.get_healing_summary()
        
        assert summary["total"] == 0
        assert summary["success"] == 0
        assert summary["rate"] == 0.0
    
    def test_healing_summary_after_attempts(self):
        """Test summary after healing attempts"""
        healer = SelfHealer()
        
        # Manually add some healing history
        analysis = ErrorAnalysis(
            category=ErrorCategory.SYNTAX_ERROR,
            message="Test error"
        )
        
        healer._record_attempt(analysis, "fix1", True, "Success")
        healer._record_attempt(analysis, "fix2", False, "Failed")
        healer._record_attempt(analysis, "fix3", True, "Success")
        
        summary = healer.get_healing_summary()
        
        assert summary["total"] == 3
        assert summary["success"] == 2
        assert summary["failure"] == 1
        assert summary["rate"] == pytest.approx(2/3)


class TestErrorPatterns:
    """Tests for error pattern definitions"""
    
    def test_all_patterns_have_required_fields(self):
        """Verify all patterns have required fields"""
        for category, patterns in ERROR_PATTERNS.items():
            for pattern_info in patterns:
                assert "pattern" in pattern_info
                assert "fix_hints" in pattern_info
                assert isinstance(pattern_info["fix_hints"], list)
    
    def test_patterns_are_valid_regex(self):
        """Verify all patterns are valid regex"""
        import re
        
        for category, patterns in ERROR_PATTERNS.items():
            for pattern_info in patterns:
                try:
                    re.compile(pattern_info["pattern"])
                except re.error as e:
                    pytest.fail(f"Invalid regex for {category}: {e}")


class TestHealingAttemptDataclass:
    """Tests for HealingAttempt dataclass"""
    
    def test_to_dict(self):
        """Test conversion to dictionary"""
        analysis = ErrorAnalysis(
            category=ErrorCategory.SYNTAX_ERROR,
            message="Test error",
            file_path="test.py",
            line_number=10
        )
        
        attempt = HealingAttempt(
            timestamp=1234567890.0,
            error_analysis=analysis,
            fix_applied="fixed code",
            success=True,
            result="Fixed successfully"
        )
        
        d = attempt.to_dict()
        
        assert d["timestamp"] == 1234567890.0
        assert d["fix_applied"] == "fixed code"
        assert d["success"] is True
        assert d["error"]["category"] == "syntax_error"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
