"""
Tests for Cline Feature Modules
"""
import pytest
import os
import tempfile
import shutil

class TestContextInjector:
    """Tests for @file context injection"""
    
    def test_parse_file_marker(self):
        from src.shakty3n.modules.context_manager.context_injector import ContextInjector
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = os.path.join(tmpdir, "test.py")
            with open(test_file, 'w') as f:
                f.write("def hello():\n    print('world')")
            
            injector = ContextInjector(tmpdir)
            result = injector.parse_and_inject("Review @file:test.py")
            
            assert "Context Loaded: test.py" in result["processed_prompt"]
            assert "def hello():" in result["processed_prompt"]
            assert test_file in result["files"]
            
    def test_missing_file(self):
        from src.shakty3n.modules.context_manager.context_injector import ContextInjector
        
        with tempfile.TemporaryDirectory() as tmpdir:
            injector = ContextInjector(tmpdir)
            result = injector.parse_and_inject("Review @file:nonexistent.py")
            
            assert "File not found" in result["processed_prompt"]


class TestTimelineStore:
    """Tests for checkpoint/snapshot functionality"""
    
    def test_create_checkpoint(self):
        from src.shakty3n.modules.editor_integration.timeline_store import TimelineStore
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files
            with open(os.path.join(tmpdir, "app.py"), 'w') as f:
                f.write("print('hello')")
                
            timeline = TimelineStore(tmpdir)
            checkpoint_id = timeline.create_checkpoint("Initial version")
            
            assert checkpoint_id is not None
            checkpoints = timeline.list_checkpoints()
            assert len(checkpoints) >= 1
            assert checkpoints[-1]["message"] == "Initial version"
            
    def test_restore_checkpoint(self):
        from src.shakty3n.modules.editor_integration.timeline_store import TimelineStore
        
        with tempfile.TemporaryDirectory() as tmpdir:
            app_file = os.path.join(tmpdir, "app.py")
            
            # Create initial file
            with open(app_file, 'w') as f:
                f.write("version1")
                
            timeline = TimelineStore(tmpdir)
            checkpoint_id = timeline.create_checkpoint("v1")
            
            # Modify file
            with open(app_file, 'w') as f:
                f.write("version2")
                
            # Restore
            success = timeline.restore_checkpoint(checkpoint_id)
            assert success
            
            with open(app_file, 'r') as f:
                content = f.read()
            assert content == "version1"


class TestExecService:
    """Tests for terminal execution"""
    
    def test_run_foreground_command(self):
        from src.shakty3n.modules.terminal_executor.exec_service import ExecService
        
        with tempfile.TemporaryDirectory() as tmpdir:
            exec_service = ExecService(tmpdir)
            result = exec_service.run_command("echo 'hello'")
            
            assert result["success"] == True
            assert "hello" in result["output"]
            
    def test_run_background_process(self):
        from src.shakty3n.modules.terminal_executor.exec_service import ExecService
        import time
        
        with tempfile.TemporaryDirectory() as tmpdir:
            exec_service = ExecService(tmpdir)
            result = exec_service.run_command("sleep 1 && echo done", background=True)
            
            assert result["background"] == True
            assert "process_id" in result
            
            # Clean up
            exec_service.kill_process(result["process_id"])


class TestDiffPresenter:
    """Tests for diff generation"""
    
    def test_unified_diff(self):
        from src.shakty3n.modules.editor_integration.diff_presenter import DiffPresenter
        
        presenter = DiffPresenter()
        old = "line1\nline2\nline3"
        new = "line1\nmodified\nline3"
        
        diff = presenter.generate_unified_diff(old, new, "test.txt")
        
        assert "-line2" in diff
        assert "+modified" in diff
        
    def test_queue_change(self):
        from src.shakty3n.modules.editor_integration.diff_presenter import DiffPresenter
        
        presenter = DiffPresenter()
        change_id = presenter.queue_change("/test.py", "old", "new", "Test change")
        
        pending = presenter.get_pending_changes()
        assert len(pending) == 1
        assert pending[0]["id"] == change_id
        
        presenter.approve_change(change_id)
        pending = presenter.get_pending_changes()
        assert len(pending) == 0


class TestSecretsDetector:
    """Tests for secrets detection"""
    
    def test_detect_api_key(self):
        from src.shakty3n.modules.security.security_manager import SecretsDetector
        
        detector = SecretsDetector()
        content = """
        API_KEY = "sk-1234567890abcdefghijklmnopqrstuvwxyz12345678901234"
        password = "mysecretpassword123"
        """
        
        findings = detector.scan_content(content, "test.py")
        assert len(findings) >= 1
        
    def test_detect_aws_key(self):
        from src.shakty3n.modules.security.security_manager import SecretsDetector
        
        detector = SecretsDetector()
        content = "aws_access_key_id = AKIAIOSFODNN7EXAMPLE"
        
        findings = detector.scan_content(content, "config.py")
        assert any("AWS" in f["type"] for f in findings)


class TestUsageTracker:
    """Tests for telemetry"""
    
    def test_track_usage(self):
        from src.shakty3n.modules.telemetry.usage_tracker import UsageTracker
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tracker = UsageTracker(os.path.join(tmpdir, "usage.json"))
            
            tracker.start_session("test-task", "ollama")
            tracker.log_request(1000, 500)
            tracker.log_request(500, 250)
            session = tracker.end_session()
            
            assert session["total_tokens"]["input"] == 1500
            assert session["total_tokens"]["output"] == 750


class TestFileIndexer:
    """Tests for file indexing"""
    
    def test_get_file_tree(self):
        from src.shakty3n.modules.editor_integration.file_indexer import FileIndexer
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create test structure
            os.makedirs(os.path.join(tmpdir, "src"))
            with open(os.path.join(tmpdir, "src", "main.py"), 'w') as f:
                f.write("print('main')")
            with open(os.path.join(tmpdir, "README.md"), 'w') as f:
                f.write("# Test")
                
            indexer = FileIndexer(tmpdir)
            files = indexer.get_file_tree()
            
            assert "src/main.py" in files
            assert "README.md" in files
            
    def test_search_content(self):
        from src.shakty3n.modules.editor_integration.file_indexer import FileIndexer
        
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "app.py"), 'w') as f:
                f.write("def hello_world():\n    pass")
                
            indexer = FileIndexer(tmpdir)
            results = indexer.search_content("hello_world")
            
            assert len(results) >= 1
            assert results[0]["file"] == "app.py"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
