
document.addEventListener('DOMContentLoaded', function() {
    // Smooth Scroll functionality
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Mobile menu toggle
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const navbar = document.querySelector('.navbar nav');

    hamburgerMenu.addEventListener('click', function() {
        this.classList.toggle('active');
        navbar.classList.toggle('show-mobile-menu');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.hamburger-menu') && 
            !event.target.closest('.navbar nav') &&
            window.innerWidth < 768) {
            hamburgerMenu.classList.remove('active');
            navbar.classList.remove('show-mobile-menu');
        }
    });

    // Form handling
    const driveForm = document.querySelector('.drive-form');
    
    function handleFormSubmit(event) {
        event.preventDefault();
        
        // Get form values
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const preferredModel = document.getElementById('preferred-model').value;

        if (!name || !email || !phone || !preferredModel) {
            alert('Please fill in all required fields');
            return;
        }

        // Simulate form submission
        alert(`Thank you for your interest! We'll contact you soon.\nName: ${name}\nEmail: ${email}\nPhone: ${phone}`);
        
        // Reset form and show success message
        driveForm.reset();
        const ctaButton = document.querySelector('.cta-button');
        ctaButton.style.transform = 'scale(1.05)';
        setTimeout(() => {
            ctaButton.style.transform = 'scale(1)';
        }, 200);
    }

    // Add event listener to form
    driveForm.addEventListener('submit', handleFormSubmit);

    // Initialize mobile menu state
    function initMobileMenu() {
        if (window.innerWidth < 768) {
            hamburgerMenu.style.display = 'block';
            navbar.classList.remove('show-mobile-menu');
        } else {
            hamburgerMenu.style.display = 'none';
        }
    }

    // Handle window resize
    window.addEventListener('resize', function() {
        initMobileMenu();
    });

    // Initial check for mobile menu
    initMobileMenu();
});
