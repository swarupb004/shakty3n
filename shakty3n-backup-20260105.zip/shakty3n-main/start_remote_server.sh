#!/bin/bash
# Shakty3n Remote Server Startup Script
# Run this to start the server for remote access

cd "$(dirname "$0")"

echo "=========================================="
echo "  SHAKTY3N REMOTE SERVER"
echo "=========================================="

# Check if Ollama is running
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "⚠️  Ollama not running. Starting..."
    open -a Ollama
    sleep 5
fi

# Check environment
if [ ! -f .env ]; then
    echo "⚠️  No .env file found. Creating default..."
    cat > .env << 'EOF'
DEFAULT_AI_PROVIDER=ollama
DEFAULT_MODEL=codestral:22b
OLLAMA_TIMEOUT=2700
SHAKTY_API_KEY=change-this-to-a-secure-key
EOF
fi

# Load environment
source .env 2>/dev/null

echo ""
echo "Configuration:"
echo "  Provider: ${DEFAULT_AI_PROVIDER:-ollama}"
echo "  Model: ${DEFAULT_MODEL:-codestral:22b}"
echo "  Timeout: ${OLLAMA_TIMEOUT:-2700} seconds"
echo ""

# Start the server on all interfaces
echo "Starting server on 0.0.0.0:8000..."
echo "Access locally: http://localhost:8000"
echo "Access remotely: http://$(ipconfig getifaddr en0):8000"
echo ""
echo "Press Ctrl+C to stop"
echo "=========================================="

python3 -m uvicorn platform_api.main:app --host 0.0.0.0 --port 8000 --reload
