# Shakty3n Architecture

## System Overview

Shakty3n is an autonomous AI coding agent platform that generates complete projects from natural language descriptions.

```mermaid
flowchart TB
    subgraph Frontend["Web Frontend (Next.js)"]
        UI[Chat UI]
        Editor[Code Editor]
        FileExplorer[File Explorer]
    end
    
    subgraph API["Platform API (FastAPI)"]
        Endpoints[REST + WebSocket]
        AgentMgr[AgentManager]
    end
    
    subgraph Core["Core Engine"]
        Executor[AutonomousExecutor]
        Planner[TaskPlanner + DAGPlanner]
        Healer[SelfHealer]
        Generators[Code Generators]
    end
    
    subgraph Quality["Quality Assurance"]
        Security[SecurityScanner]
        Arch[ArchitectureAnalyzer]
        Debug[AutoDebugger]
    end
    
    subgraph Providers["AI Providers"]
        Ollama[Ollama]
        OpenAI[OpenAI]
        Anthropic[Anthropic]
        Google[Google]
        Docker[Docker Model Runner]
    end
    
    UI --> Endpoints
    Endpoints --> AgentMgr
    AgentMgr --> Executor
    Executor --> Planner
    Executor --> Generators
    Executor --> Healer
    Generators --> Providers
    Executor --> Quality
```

## Core Components

### AutonomousExecutor
- **Location**: `src/shakty3n/executor/autonomous_executor.py`
- **Purpose**: Main execution engine using ReAct (Reason, Act, Observe) loop
- **Features**:
  - Fast path for simple HTML projects
  - Full planning path for complex projects
  - Self-healing with automatic retry

### TaskPlanner & DAGPlanner
- **Location**: `src/shakty3n/planner/`
- **Purpose**: Break down projects into executable tasks
- **Features**:
  - Dependency DAG for parallel execution
  - Critical path calculation
  - Agent role assignment

### SelfHealer
- **Location**: `src/shakty3n/debugger/self_healer.py`
- **Purpose**: Automatic error detection and recovery
- **Features**:
  - Error pattern matching
  - AI-powered fix generation
  - File backup and rollback

### ArchitectureAnalyzer
- **Location**: `src/shakty3n/reflection/architecture_analyzer.py`
- **Purpose**: Proactive code quality analysis
- **Features**:
  - AST-based Python analysis
  - Code smell detection
  - Health score calculation

### SecurityScanner
- **Location**: `src/shakty3n/security/scanner.py`
- **Purpose**: Security vulnerability scanning
- **Features**:
  - OWASP Top 10 patterns
  - Secret detection
  - Dependency vulnerability checks

## Data Flow

1. **User Request** → Chat UI → Platform API
2. **Intent Classification** → Determine project type
3. **Planning** → Create task DAG
4. **Execution** → ReAct loop per task
5. **Self-Healing** → Retry with fixes on failure
6. **Validation** → Security + architecture scan
7. **Output** → Generated project in workspace

## Extension Points

### Adding AI Providers
1. Create new class in `src/shakty3n/ai_providers/`
2. Inherit from `AIProvider` base class
3. Implement `generate()` and `get_available_models()`
4. Register in `AIProviderFactory`

### Adding Code Generators
1. Create new generator in `src/shakty3n/generators/`
2. Implement `generate_project()` method
3. Add to generator imports in `__init__.py`

### Adding Security Rules
1. Add pattern to `OWASP_RULES` or `SECRET_PATTERNS`
2. Include regex, severity, description, and CWE ID
