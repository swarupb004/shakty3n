# Agentic Ollama Orchestrator

A lightweight, extensible agentic framework that runs on Ollama and can hand off tasks to external agents (like OpenClaw). It includes a planner, a coder, memory storage, and a router for multi-agent orchestration.

## Quick Start

1. Install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

2. Run a task:

```bash
python -m agentic --task "Design a caching layer and outline steps."
```

## Configuration

Set environment variables (or create a `.env` file; it will be auto-loaded) to customize:

- `OLLAMA_BASE_URL` (default: `http://localhost:11434`)
- `OLLAMA_MODEL` (default: `llama3.1`)
- `OPENCLAW_CLI` (optional, preferred if set; e.g. `openclaw` or `node /path/to/openclaw.mjs`)
- `OPENCLAW_AGENT_ID` (optional; defaults to `main`)
- `OPENCLAW_LOCAL` (optional; `true/1` to force local agent execution)
- `OPENCLAW_TIMEOUT` (optional; seconds)
- `OPENCLAW_CHANNEL` (optional; set to `webchat` for WebChat UI)
- `OPENCLAW_AUTOPOST` (optional; `true/1` to inject plan+code into WebChat)
- `OPENCLAW_SESSION_KEY` (optional; defaults to `agent:<agent_id>:main`)
- `OPENCLAW_BASE_URL` (optional HTTP mode)
- `OPENCLAW_ENDPOINT` (default: `/run`, HTTP mode)
- `OPENCLAW_API_KEY` (optional, HTTP mode)

## Layout

- `agentic/agents`: planner, coder, external agents
- `agentic/llm`: LLM client implementations
- `agentic/memory`: memory backends
- `agentic/tools`: tool routing scaffolding

## Notes

This is intentionally small and hackable. Add more tools, memory backends, and model adapters as needed.

WebChat: if you're using OpenClaw's WebChat UI, open the `main` session to see replies from the OpenClaw integration.
