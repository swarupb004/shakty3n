import os
from pathlib import Path
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class AppConfig:
    ollama_base_url: str
    ollama_model: str
    openclaw_base_url: Optional[str]
    openclaw_endpoint: str
    openclaw_api_key: Optional[str]
    openclaw_cli_command: Optional[str]
    openclaw_agent_id: Optional[str]
    openclaw_local: bool
    openclaw_timeout_s: Optional[int]
    openclaw_channel: Optional[str]
    openclaw_autopost: bool
    openclaw_session_key: Optional[str]


def load_config() -> AppConfig:
    _load_dotenv()
    return AppConfig(
        ollama_base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
        ollama_model=os.getenv("OLLAMA_MODEL", "llama3.1"),
        openclaw_base_url=os.getenv("OPENCLAW_BASE_URL"),
        openclaw_endpoint=os.getenv("OPENCLAW_ENDPOINT", "/run"),
        openclaw_api_key=os.getenv("OPENCLAW_API_KEY"),
        openclaw_cli_command=os.getenv("OPENCLAW_CLI"),
        openclaw_agent_id=os.getenv("OPENCLAW_AGENT_ID"),
        openclaw_local=os.getenv("OPENCLAW_LOCAL", "").lower() in {"1", "true", "yes"},
        openclaw_timeout_s=_parse_int(os.getenv("OPENCLAW_TIMEOUT")),
        openclaw_channel=os.getenv("OPENCLAW_CHANNEL"),
        openclaw_autopost=os.getenv("OPENCLAW_AUTOPOST", "").lower() in {"1", "true", "yes"},
        openclaw_session_key=os.getenv("OPENCLAW_SESSION_KEY"),
    )


def _parse_int(value: Optional[str]) -> Optional[int]:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _load_dotenv() -> None:
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value
