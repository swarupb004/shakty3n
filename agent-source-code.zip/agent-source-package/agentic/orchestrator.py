from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Optional

from .agents.base import AgentResult
from .agents.coder import CoderAgent
from .agents.planner import PlannerAgent
from .agents.openclaw_agent import OpenClawAgent
from .agents.openclaw_cli_agent import OpenClawCliAgent
from .config import AppConfig
from .llm.registry import build_llm
from .memory.jsonl import JsonlMemory
from .memory.base import MemoryItem


@dataclass
class Orchestrator:
    config: AppConfig

    def run(self, task: str) -> dict[str, AgentResult]:
        llm = build_llm(self.config)
        planner = PlannerAgent(llm=llm)
        coder = CoderAgent(llm=llm)

        memory = JsonlMemory(path=self._memory_path())
        memory.add(MemoryItem(role="user", content=task))

        plan = planner.run(task)
        memory.add(MemoryItem(role="planner", content=plan.output))

        code = coder.run(task, context=plan.output)
        memory.add(MemoryItem(role="coder", content=code.output))

        results: dict[str, AgentResult] = {
            "plan": plan,
            "code": code,
        }

        openclaw_result = self._maybe_run_openclaw(task, plan.output)
        if openclaw_result is not None:
            memory.add(MemoryItem(role="openclaw", content=openclaw_result.output))
            results["openclaw"] = openclaw_result

        self._maybe_autopost(plan=plan, code=code)

        return results

    def _memory_path(self):
        return (self._project_root() / "memory" / "session.jsonl")

    def _project_root(self):
        return __import__("pathlib").Path(__file__).resolve().parent.parent

    def _maybe_run_openclaw(self, task: str, context: str) -> Optional[AgentResult]:
        if self.config.openclaw_cli_command:
            openclaw = OpenClawCliAgent(
                cli_command=self.config.openclaw_cli_command,
                agent_id=self.config.openclaw_agent_id,
                local=self.config.openclaw_local,
                timeout_s=self.config.openclaw_timeout_s,
                channel=self.config.openclaw_channel,
            )
            return openclaw.run(task, context=context)

        if self.config.openclaw_base_url:
            openclaw = OpenClawAgent(
                base_url=self.config.openclaw_base_url,
                endpoint=self.config.openclaw_endpoint,
                api_key=self.config.openclaw_api_key,
            )
            return openclaw.run(task, context=context)

        return None

    def _maybe_autopost(self, plan: AgentResult, code: AgentResult) -> None:
        if not self.config.openclaw_autopost:
            return
        if not self.config.openclaw_cli_command:
            print("OpenClaw autopost skipped: OPENCLAW_CLI not set.", file=sys.stderr)
            return

        agent_id = (self.config.openclaw_agent_id or "main").strip() or "main"
        session_key = (self.config.openclaw_session_key or f"agent:{agent_id}:main").strip()
        message = self._format_webchat_message(plan=plan.output, code=code.output)
        openclaw = OpenClawCliAgent(
            cli_command=self.config.openclaw_cli_command,
            agent_id=self.config.openclaw_agent_id,
            local=self.config.openclaw_local,
            timeout_s=self.config.openclaw_timeout_s,
            channel=self.config.openclaw_channel,
        )
        try:
            openclaw.inject(session_key=session_key, message=message, label="Agentic")
        except Exception as exc:  # best-effort; do not fail the run
            print(f"OpenClaw autopost failed: {exc}", file=sys.stderr)

    def _format_webchat_message(self, plan: str, code: str) -> str:
        return f"=== PLAN ===\n{plan}\n\n=== CODE ===\n{code}"
