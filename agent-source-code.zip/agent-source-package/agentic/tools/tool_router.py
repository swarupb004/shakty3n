from __future__ import annotations

from dataclasses import dataclass

from .base import Tool


@dataclass
class ToolRouter:
    tools: dict[str, Tool]

    def run(self, tool_name: str, payload: str) -> str:
        if tool_name not in self.tools:
            raise KeyError(f"Unknown tool: {tool_name}")
        return self.tools[tool_name].run(payload)
