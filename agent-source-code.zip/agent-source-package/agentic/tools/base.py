from __future__ import annotations

from typing import Protocol


class Tool(Protocol):
    name: str

    def run(self, payload: str) -> str:
        ...
