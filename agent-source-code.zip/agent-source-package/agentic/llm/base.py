from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass
class ChatMessage:
    role: str
    content: str


class LLMClient:
    def chat(self, messages: Iterable[ChatMessage]) -> str:
        raise NotImplementedError
