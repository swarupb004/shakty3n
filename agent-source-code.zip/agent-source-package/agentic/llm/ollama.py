from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Iterable

import requests

from .base import ChatMessage, LLMClient


@dataclass
class OllamaClient(LLMClient):
    base_url: str
    model: str
    timeout_s: int = 120

    def chat(self, messages: Iterable[ChatMessage]) -> str:
        payload = {
            "model": self.model,
            "stream": False,
            "messages": [m.__dict__ for m in messages],
        }
        url = self._build_url("api/chat")
        resp = requests.post(url, json=payload, timeout=self.timeout_s)
        if resp.status_code == 404:
            self._maybe_raise_model_not_found(resp)
            return self._fallback_generate(messages)
        resp.raise_for_status()
        data = resp.json()
        if "message" not in data or "content" not in data["message"]:
            raise ValueError(f"Unexpected Ollama response: {json.dumps(data)[:500]}")
        return data["message"]["content"].strip()

    def _fallback_generate(self, messages: Iterable[ChatMessage]) -> str:
        prompt = self._build_prompt(messages)
        payload = {
            "model": self.model,
            "stream": False,
            "prompt": prompt,
        }
        url = self._build_url("api/generate")
        resp = requests.post(url, json=payload, timeout=self.timeout_s)
        if resp.status_code == 404:
            self._maybe_raise_model_not_found(resp)
        resp.raise_for_status()
        data = resp.json()
        if "response" not in data:
            raise ValueError(f"Unexpected Ollama response: {json.dumps(data)[:500]}")
        return str(data["response"]).strip()

    def _build_prompt(self, messages: Iterable[ChatMessage]) -> str:
        lines = []
        for message in messages:
            role = (message.role or "user").strip().capitalize()
            lines.append(f"{role}: {message.content}")
        lines.append("Assistant:")
        return "\n\n".join(lines)

    def _build_url(self, path: str) -> str:
        base = self.base_url.rstrip("/")
        if base.endswith("/api") and path.startswith("api/"):
            path = path[len("api/"):]
        return f"{base}/{path.lstrip('/')}"

    def _maybe_raise_model_not_found(self, resp: requests.Response) -> None:
        try:
            data = resp.json()
        except ValueError:
            return
        error = str(data.get("error") or data.get("message") or "").lower()
        if "model" in error and "not found" in error:
            models = self._list_models()
            hint = f" Available models: {', '.join(models)}." if models else ""
            raise ValueError(
                f"Ollama model '{self.model}' not found.{hint} "
                f"Set OLLAMA_MODEL to one of the installed models."
            )

    def _list_models(self) -> list[str]:
        try:
            url = self._build_url("api/tags")
            resp = requests.get(url, timeout=self.timeout_s)
            resp.raise_for_status()
            data = resp.json()
            return [m.get("name") for m in data.get("models", []) if m.get("name")]
        except Exception:
            return []
