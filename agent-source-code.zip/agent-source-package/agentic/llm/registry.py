from __future__ import annotations

from .ollama import OllamaClient
from ..config import AppConfig


def build_llm(config: AppConfig) -> OllamaClient:
    return OllamaClient(base_url=config.ollama_base_url, model=config.ollama_model)
