from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass
class MemoryItem:
    role: str
    content: str


class Memory(Protocol):
    def add(self, item: MemoryItem) -> None:
        ...

    def load(self) -> list[MemoryItem]:
        ...
