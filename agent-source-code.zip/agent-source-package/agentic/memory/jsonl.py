from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .base import Memory, MemoryItem


@dataclass
class JsonlMemory(Memory):
    path: Path

    def add(self, item: MemoryItem) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(item.__dict__) + "\n")

    def load(self) -> list[MemoryItem]:
        if not self.path.exists():
            return []
        items: list[MemoryItem] = []
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                data = json.loads(line)
                items.append(MemoryItem(**data))
        return items
