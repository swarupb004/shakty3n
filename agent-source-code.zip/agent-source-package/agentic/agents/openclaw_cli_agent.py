from __future__ import annotations

import json
import json
import shlex
import subprocess
from dataclasses import dataclass
from typing import Iterable, Optional

from .base import AgentResult


@dataclass
class OpenClawCliAgent:
    cli_command: str
    agent_id: Optional[str] = None
    local: bool = False
    timeout_s: Optional[int] = None
    channel: Optional[str] = None
    name: str = "openclaw"

    def run(self, task: str, context: Optional[str] = None) -> AgentResult:
        message = self._build_message(task, context)
        base_cmd = shlex.split(self.cli_command)
        cmd = base_cmd + ["agent", "--message", message, "--json"]
        agent_id = (self.agent_id or "main").strip() or "main"
        cmd.extend(["--agent", agent_id])
        if self.channel:
            cmd.extend(["--channel", self.channel])
        if self.local:
            cmd.append("--local")
        if self.timeout_s:
            cmd.extend(["--timeout", str(self.timeout_s)])

        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
        )
        output = self._parse_output(result.stdout)
        return AgentResult(output=output)

    def _build_message(self, task: str, context: Optional[str]) -> str:
        if context:
            return f"Task: {task}\nContext: {context}"
        return task

    def _parse_output(self, stdout: str) -> str:
        stdout = stdout.strip()
        if not stdout:
            return ""
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            return stdout

        for key in ("output", "text", "message", "reply"):
            if key in data and isinstance(data[key], str):
                return data[key].strip()
        return json.dumps(data)

    def inject(self, session_key: str, message: str, label: Optional[str] = None) -> None:
        params = {"sessionKey": session_key, "message": message}
        if label:
            params["label"] = label
        base_cmd = shlex.split(self.cli_command)
        cmd = base_cmd + ["gateway", "call", "chat.inject", "--params", json.dumps(params)]
        subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True,
        )
