from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, Optional


@dataclass
class AgentResult:
    output: str


class Agent(Protocol):
    name: str

    def run(self, task: str, context: Optional[str] = None) -> AgentResult:
        ...
