from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..llm.base import ChatMessage, LLMClient
from .base import AgentResult


@dataclass
class PlannerAgent:
    llm: LLMClient
    name: str = "planner"

    def run(self, task: str, context: Optional[str] = None) -> AgentResult:
        system = (
            "You are a planning agent. Produce a concise, step-by-step plan "
            "for the given task. Keep it to 5-8 steps."
        )
        user = f"Task: {task}\nContext: {context or 'N/A'}"
        messages = [ChatMessage("system", system), ChatMessage("user", user)]
        output = self.llm.chat(messages)
        return AgentResult(output=output)
