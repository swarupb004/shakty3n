from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Optional

import requests

from .base import AgentResult


@dataclass
class OpenClawAgent:
    base_url: str
    endpoint: str
    api_key: Optional[str] = None
    name: str = "openclaw"
    timeout_s: int = 120

    def run(self, task: str, context: Optional[str] = None) -> AgentResult:
        url = f"{self.base_url.rstrip('/')}/{self.endpoint.lstrip('/')}"
        payload = {"task": task, "context": context}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        resp = requests.post(url, data=json.dumps(payload), headers=headers, timeout=self.timeout_s)
        resp.raise_for_status()
        data = resp.json()
        output = data.get("output") or data.get("result") or str(data)
        return AgentResult(output=str(output).strip())
