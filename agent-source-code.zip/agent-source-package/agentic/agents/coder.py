from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..llm.base import ChatMessage, LLMClient
from .base import AgentResult


@dataclass
class CoderAgent:
    llm: LLMClient
    name: str = "coder"

    def run(self, task: str, context: Optional[str] = None) -> AgentResult:
        system = (
            "You are a coding agent. Provide implementation guidance or code "
            "snippets to accomplish the task. Be concise and practical."
        )
        user = f"Task: {task}\nContext: {context or 'N/A'}"
        messages = [ChatMessage("system", system), ChatMessage("user", user)]
        output = self.llm.chat(messages)
        return AgentResult(output=output)
