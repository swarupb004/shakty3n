from __future__ import annotations

import argparse

from .config import load_config
from .orchestrator import Orchestrator


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Agentic Ollama Orchestrator")
    parser.add_argument("--task", required=True, help="Task to execute")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    config = load_config()
    orchestrator = Orchestrator(config=config)
    results = orchestrator.run(args.task)

    print("\n=== PLAN ===\n")
    print(results["plan"].output)

    print("\n=== CODE ===\n")
    print(results["code"].output)

    if "openclaw" in results:
        print("\n=== OPENCLAW ===\n")
        print(results["openclaw"].output)


if __name__ == "__main__":
    main()
