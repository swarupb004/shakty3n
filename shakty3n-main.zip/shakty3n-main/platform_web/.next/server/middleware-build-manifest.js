globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ee8d81b941c2a798.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/a0e9039376638b5f.js",
    "static/chunks/17bb38bff44521fb.js",
    "static/chunks/turbopack-3e16d19e794d3651.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];