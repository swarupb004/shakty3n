# Shakty3n - Autonomous Agentic Coder 🤖

An advanced autonomous AI-powered coder that builds complete applications across multiple platforms. Shakty3n plans, codes, debugs, and delivers fully functional Web, Android, iOS, and Desktop applications autonomously.

## ✨ Features

### 🎯 Autonomous Operation
- **Intelligent Planning**: Creates comprehensive project plans with task breakdown
- **Self-Execution**: Executes tasks autonomously until completion
- **Auto-Debugging**: Automatically detects and fixes errors
- **Progress Tracking**: Real-time progress monitoring and reporting

### 🌐 Multi-Platform Support
- **Web Applications**: React, Vue, Angular, Svelte, Next.js
- **Mobile Apps**: Android (Kotlin, Java), iOS (Swift, SwiftUI), Flutter (Cross-platform)
- **Desktop Apps**: Electron, Python (tkinter) with macOS DMG installer script

### 🤖 AI Model Integration
Connect with multiple AI providers:
- **OpenAI**: GPT-4, GPT-3.5, GPT-4-Turbo
- **Anthropic**: Claude 3 (Opus, Sonnet, Haiku)
- **Google**: Gemini Pro, Gemini 3.0 Pro
- **Ollama**: Local models (Llama 2, CodeLlama, Mistral, Mixtral, Qwen Coder, DeepSeek Coder)

### 🛠️ Capabilities
- Complete project scaffolding and structure generation
- Intelligent code generation with best practices
- Automatic dependency management
- Error detection and fixing
- **Agent Manager & IDE Workspace**: VS Code–style editor/terminal/browser access, dashboard to spawn/coordinate multiple agents, artifact tracking, and human-in-the-loop approvals
- **Persistent Chat History (NEW)**: Conversations are saved to SQLite and persist across sessions
- **Open Existing Projects (NEW)**: Resume work on previously created projects
- **Automatic Test Generation**: Unit and integration tests
- **Code Validation**: Syntax, structure, and dependency checks
- **Sandbox Testing**: Spin up a virtual environment and run tests
- Testing framework setup
- Documentation generation

---

## 📦 Installation

### Prerequisites
- **Python 3.8** or higher
- **Node.js 18+** (for the Web UI)
- **pip** package manager
- **npm** or **yarn** (for the Web UI)

### Install from Source

```bash
# Clone the repository
git clone https://github.com/swarupb004/shakty3n.git
cd shakty3n

# Install Python dependencies (includes API server dependencies)
pip install -r requirements.txt

# Install the package
pip install -e .
```

---

## 🚀 Quick Start

### 1. Configure API Keys

First, set up your AI provider API keys:

```bash
# Interactive configuration
# macOS/Linux:
python3 server.py configure

# Windows:
python server.py configure
```

Or manually create a `.env` file (copy from `.env.example`):

```env
# AI Model API Keys
OPENAI_API_KEY=your_openai_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
GOOGLE_API_KEY=your_google_api_key_here

# Default Model Settings
DEFAULT_AI_PROVIDER=openai
DEFAULT_MODEL=gpt-4

# Application Settings
AUTO_DEBUG=true
MAX_RETRIES=3
VERBOSE=true

# API Server Settings (for Web UI)
API_AUTH_TOKEN=
DB_PATH=shakty3n_projects.db

# Ollama Configuration (for local models)
OLLAMA_BASE_URL=http://localhost:11434
```

### 2. Test Your Connection

```bash
# macOS/Linux:
python3 server.py test --provider openai

# Windows:
python server.py test --provider openai
```

### 3. Create Your First Project

#### Interactive Mode (Recommended)
```bash
# macOS/Linux:
python3 server.py create --interactive

# Windows:
python server.py create --interactive
```

#### Command Line Mode
```bash
# Create a React web app (macOS/Linux)
python3 server.py create \
  --description "A todo list application with user authentication" \
  --type web-react \
  --provider openai \
  --output ./my_project

# Create an Android app
python3 server.py create \
  --description "A weather app showing current conditions" \
  --type android \
  --provider anthropic

# Create an iOS app
python3 server.py create \
  --description "A notes app with cloud sync" \
  --type ios \
  --provider google

# Create a Desktop app
python3 server.py create \
  --description "A task manager with reminders" \
  --type desktop-electron \
  --provider openai

# Create a Flutter cross-platform app with tests
python3 server.py create \
  --description "A fitness tracker with charts" \
  --type flutter \
  --provider openai \
  --with-tests

# Create a Next.js app with validation
python3 server.py create \
  --description "A blog platform with CMS" \
  --type web-nextjs \
  --provider anthropic \
  --with-tests \
  --validate

# Windows: Use python instead of python3 and ^ for line continuation
```

---

## 🌐 Web UI

Shakty3n includes a modern graphical web interface for project orchestration with a VS Code-style agent workspace!

### Features

- **📋 Agent Dashboard**: Spawn and manage multiple autonomous agents
- **➕ Create Agents**: Visual form to create new coding agents with AI provider selection
- **📂 Open Existing Projects**: Resume work on previously generated projects
- **💬 Persistent Chat History**: Conversations saved across sessions
- **🖥️ IDE-Style Workspace**: Monaco editor, file explorer, and integrated terminal
- **📊 Real-time Monitoring**: Watch agent progress and logs in real-time
- **⬇️ Download Artifacts**: Download generated projects as ZIP files
- **🌓 Dark Mode**: Beautiful dark theme built-in

---

## 🏃 How to Run

### Option 1: Using Docker Compose (Recommended)

This is the easiest way to get everything running:

```bash
# 1. Make sure you have Docker Desktop installed and running

# 2. Create your .env file with API keys
cp .env.example .env
# Edit .env and add your API keys

# 3. Start all services (API, Web UI, and Ollama)
docker-compose up

# Or run in detached mode
docker-compose up -d
```

**Services will be available at:**
- 🌐 **Web UI**: http://localhost:3000
- 📡 **API Server**: http://localhost:8000
- 📖 **API Documentation**: http://localhost:8000/docs
- 🤖 **Ollama (local models)**: http://localhost:11434

### Option 2: Running Manually (Development Mode)

**Step 1: Start the API Server**
```bash
# From the project root directory
# macOS/Linux:
python3 server.py serve --host 0.0.0.0 --port 8000 --reload

# Windows:
python server.py serve --host 0.0.0.0 --port 8000 --reload
```

**Step 2: Start the Web UI (in a new terminal)**
```bash
# Navigate to the web UI directory
cd platform_web

# Install dependencies (first time only)
npm install

# Start the development server
npm run dev
```

**Access the application:**
- 🌐 **Web UI**: http://localhost:3000
- 📡 **API Server**: http://localhost:8000

### Option 3: Using Ollama for Local Models

**If you want to use local AI models with Ollama:**

```bash
# 1. Install Ollama (if not already installed)
# macOS/Linux: curl -fsSL https://ollama.com/install.sh | sh
# Or download from: https://ollama.com/download

# 2. Pull a coding model
ollama pull deepseek-coder:6.7b
# Or
ollama pull qwen2.5-coder:7b

# 3. Start Ollama service
ollama serve

# 4. Update your .env file
OLLAMA_BASE_URL=http://localhost:11434

# 5. Start Shakty3n (API + Web UI as described above)
```

---

## 📖 Usage Guide

### Command Reference

```bash
# Show help
python3 server.py --help

# Create a new project
python3 server.py create [OPTIONS]

# Configure settings
python3 server.py configure

# Test AI provider connection
python3 server.py test [--provider PROVIDER]

# Start the API server for web UI
python3 server.py serve [--host 0.0.0.0] [--port 8000] [--reload]

# Create a sandboxed virtual environment and run tests
python3 server.py sandbox [--env-dir .shakty3n_venv] [--test-command "-m pytest tests/test_basic.py"]

# Show information
python3 server.py info
```

### Project Types

| Type | Description | Technologies |
|------|-------------|--------------|
| `web-react` | React web application | React, JavaScript, HTML/CSS |
| `web-vue` | Vue web application | Vue.js, JavaScript, HTML/CSS |
| `web-angular` | Angular web application | Angular, TypeScript, HTML/CSS |
| `web-svelte` | Svelte web application | Svelte, JavaScript, HTML/CSS |
| `web-nextjs` | Next.js web application | Next.js, React, TypeScript |
| `android` | Android application | Kotlin/Java, Android SDK |
| `android-kotlin` | Android app (Kotlin) | Kotlin, Android SDK |
| `android-java` | Android app (Java) | Java, Android SDK |
| `ios` | iOS application | Swift, SwiftUI |
| `flutter` | Cross-platform mobile app | Flutter, Dart |
| `desktop-electron` | Electron desktop app | Electron, JavaScript, HTML/CSS |
| `desktop-python` | Python desktop app | Python, tkinter |

### AI Providers

| Provider | Models | Requirements |
|----------|--------|--------------|
| OpenAI | GPT-4, GPT-3.5-Turbo, GPT-4-Turbo | API Key |
| Anthropic | Claude 3 Opus, Sonnet, Haiku | API Key |
| Google | Gemini Pro, Gemini 3.0 Pro | API Key |
| Ollama | DeepSeek Coder, Qwen Coder, Llama, CodeLlama, Mistral | Local installation |

**Dynamic Model Fetching (Ollama):**
When using the Web UI, selecting "Ollama" as your provider will automatically fetch the list of models installed on your local Ollama instance.

---

## 🖥️ Web UI Walkthrough

### Dashboard
![Dashboard Overview](docs/screenshots/dashboard.png)

The main dashboard shows:
- All active agents with their status
- Quick access to create new agents
- Option to open existing projects

### Creating a New Agent

1. Click **"New Agent"** button
2. Enter an agent name (e.g., "React Todo App Builder")
3. Select your AI provider (OpenAI, Anthropic, Google, or Ollama)
4. Choose a model from the dropdown
5. Click **"Spawn Agent"**

### Opening an Existing Project

1. Click **"Open Existing"** button
2. Select a project from the list of generated projects
3. Click **"Open Project"**
4. The agent workspace loads with the project files

### Agent Workspace

The workspace provides a VS Code-style IDE experience:

| Panel | Description |
|-------|-------------|
| **File Explorer** (Left) | Browse and select files in the project |
| **Editor** (Center) | Monaco editor with syntax highlighting |
| **Terminal** (Bottom) | View command outputs and logs |
| **Chat** (Right) | Persistent conversation with the AI agent |

---

## 🔌 API Endpoints

The REST API is available at `http://localhost:8000`:

### Project Management
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/projects` | POST | Create and start a new project |
| `/api/projects` | GET | List all projects |
| `/api/projects/{id}` | GET | Get project details |
| `/api/projects/{id}/logs` | GET | Stream logs via SSE |
| `/api/projects/{id}/artifact` | GET | Download project artifact |
| `/api/projects/{id}/retry` | POST | Retry a failed project |
| `/api/projects/{id}` | DELETE | Delete a project |

### Agent Management
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/dashboard` | GET | Get all agents and their status |
| `/api/agents` | POST | Create a new agent |
| `/api/agents/resume` | POST | Resume an existing project |
| `/api/agents/{id}/workflow` | POST | Start a build workflow |
| `/api/agents/{id}/workspace/files` | GET | List files in workspace |
| `/api/agents/{id}/workspace/content` | GET | Read file content |
| `/api/agents/{id}/workspace/content` | POST | Save file content |

### Chat History (NEW)
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/agents/{id}/chat` | GET | Get chat history for an agent |
| `/api/agents/{id}/chat` | POST | Add a message to chat history |
| `/api/agents/{id}/chat` | DELETE | Clear chat history |

### Providers
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/providers/{provider}/models` | GET | Get available models for a provider |
| `/api/local-projects` | GET | List locally generated projects |

📖 **Full API Documentation**: http://localhost:8000/docs

---

## 🐳 Docker Configuration

### Docker Compose Services

```yaml
services:
  ollama:    # Local AI model server (port 11434)
  api:       # Python FastAPI backend (port 8000)
  web:       # Next.js frontend (port 3000)
```

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `OPENAI_API_KEY` | OpenAI API key | - |
| `ANTHROPIC_API_KEY` | Anthropic API key | - |
| `GOOGLE_API_KEY` | Google API key | - |
| `DEFAULT_AI_PROVIDER` | Default provider | `openai` |
| `DEFAULT_MODEL` | Default model | `gpt-4` |
| `OLLAMA_BASE_URL` | Ollama server URL | `http://localhost:11434` |
| `DB_PATH` | SQLite database path | `shakty3n_projects.db` |
| `API_AUTH_TOKEN` | Optional auth token | - |
| `NEXT_PUBLIC_API_URL` | API URL for frontend | `http://localhost:8000` |

---

## 🏗️ Architecture

### Project Structure

```
shakty3n/
├── shakty3n.py              # CLI entry point
├── src/shakty3n/            # Core Python package
│   ├── ai_providers/        # AI provider implementations
│   ├── agent_manager.py     # Agent coordination
│   ├── debugger/            # Auto-debugging module
│   ├── executor/            # Autonomous executor
│   ├── generators/          # Code generators (React, Android, iOS, etc.)
│   ├── planner/             # Task planning
│   ├── testing/             # Test generation
│   ├── utils/               # Utilities
│   └── validation/          # Code validation
├── platform_api/            # FastAPI backend
│   ├── main.py              # API routes
│   ├── database.py          # SQLite persistence (projects + chat)
│   └── projects.py          # Project management
├── platform_web/            # Next.js frontend
│   ├── app/                 # App router pages
│   │   ├── page.tsx         # Dashboard
│   │   └── agent/[id]/      # Agent workspace
│   ├── components/          # React components
│   │   ├── comp_chat.tsx    # Chat panel
│   │   └── comp_terminal.tsx # Terminal emulator
│   └── lib/                 # Utilities
├── generated_projects/      # Output directory for created projects
├── docker-compose.yml       # Docker orchestration
└── requirements.txt         # Python dependencies
```

### Core Modules

1. **AI Providers** (`ai_providers/`)
   - Abstract provider interface
   - OpenAI, Anthropic, Google, Ollama implementations
   - Dynamic model fetching for Ollama

2. **Agent Manager** (`agent_manager.py`)
   - Spawn and coordinate multiple agents
   - Workspace management (files, terminal, artifacts)
   - Human-in-the-loop approvals

3. **Task Planner** (`planner/`)
   - Intelligent project planning
   - Task dependency management
   - Progress tracking

4. **Code Generators** (`generators/`)
   - Web: React, Vue, Angular, Svelte, Next.js
   - Mobile: Android (Kotlin/Java), iOS, Flutter
   - Desktop: Electron, Python

5. **Auto Debugger** (`debugger/`)
   - Error detection and analysis
   - Automatic fix generation
   - Code validation

---

## 🧪 Testing & Validation

### Automatic Test Generation

```bash
# Generate project with tests
python3 server.py create \
  --description "Your project description" \
  --type web-react \
  --with-tests
```

**Supported Test Frameworks:**
- **React/Next.js**: Jest + React Testing Library
- **Vue**: Vitest + Vue Test Utils
- **Flutter**: Flutter Test + Integration Test
- **Angular/Svelte**: Jest

### Code Validation

```bash
# Generate and validate project
python3 server.py create \
  --description "Your project description" \
  --type flutter \
  --validate
```

### Sandboxed Test Runs

```bash
# Create virtual environment and run tests
python3 server.py sandbox --test-command "-m pytest tests/test_basic.py"

# Skip installation if already set up
python3 server.py sandbox --skip-install
```

---

## 🔧 Advanced Usage

### Programmatic Usage

```python
from shakty3n import AutonomousExecutor, AIProviderFactory, load_env_vars

# Load environment
load_env_vars()

# Create AI provider
ai_provider = AIProviderFactory.create_provider(
    "openai", 
    api_key="your-key",
    model="gpt-4"
)

# Create executor
executor = AutonomousExecutor(ai_provider, output_dir="./output")

# Execute with custom requirements
result = executor.execute_project(
    description="E-commerce platform with payment integration",
    project_type="web-react",
    requirements={
        "features": ["user-auth", "payments", "shopping-cart"],
        "styling": "tailwindcss",
        "database": "firebase"
    }
)

print(f"Success: {result['success']}")
print(f"Output: {result['generation']['output_dir']}")
```

### Agent Manager API

```python
import asyncio
from shakty3n import AgentManager

async def main():
    manager = AgentManager(base_output_dir="./generated_projects")
    
    # Spawn an agent
    agent = manager.spawn_agent(
        "builder",
        provider_name="ollama",
        model="deepseek-coder:6.7b"
    )

    # Run a workflow
    await manager.run_workflow(
        agent=agent,
        description="Create a dashboard app with charts",
        project_type="web-react",
        requirements={"features": ["charts", "status-board"]},
        generate_tests=True,
        validate_code=True,
    )

    # Get dashboard snapshot
    dashboard = manager.get_dashboard_snapshot()
    print("Artifacts:", dashboard["agents"][0]["artifacts"])

asyncio.run(main())
```

---

## 🔒 Security & Privacy

- API keys are stored locally in `.env` file
- Never commits sensitive data to version control
- Uses secure HTTPS connections for all API calls
- Local execution - your code stays on your machine
- Chat history stored in local SQLite database

---

## 🛣️ Roadmap

### Completed ✅
- [x] Support for more frameworks (Svelte, Next.js, Flutter)
- [x] Built-in testing and validation
- [x] Graphical UI for project orchestration
- [x] Agent workspace with IDE-style interface
- [x] Persistent chat history
- [x] Open existing project functionality
- [x] Docker Compose setup for easy deployment
- [x] Dynamic Ollama model fetching
- [x] Cloud deployment integration (Dockerfiles, CI templates)
- [x] Team collaboration features (shareable plans, progress logging)
- [x] Custom template support
- [x] Plugin system for extensibility

### In Progress 🚧
- [ ] Installer generation for iOS apps (IPA/TestFlight)
- [ ] Windows desktop installers (MSI/EXE) for Electron/Python

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request. See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

Built with powerful AI models from:
- OpenAI
- Anthropic
- Google
- Meta (Llama via Ollama)

---

## 📞 Support

For issues, questions, or suggestions:
- Create an issue on GitHub
- Check existing documentation
- Review examples and guides

---

**Shakty3n** - Build anything, autonomously. 🚀
